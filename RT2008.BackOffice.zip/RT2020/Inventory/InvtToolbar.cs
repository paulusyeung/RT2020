﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Xml.Linq;

using Gizmox.WebGUI.Forms;
using Gizmox.WebGUI.Common.Resources;
using RT2008.DAL;

namespace RT2008.Inventory
{
    public class InvtToolbar
    {
        private Control atsPaneCtrl;
        private FormType fType;

        public enum FormType
        {
            GoodsReceive,
            GoodsReturn,
            Transfer,
            Adjustment,
            Replenishment,
            StockTake,
            All
        }

        public InvtToolbar(Control toolBar, ref ToolBar tbInvt, FormType formType)
        {
            atsPaneCtrl = toolBar;
            fType = formType;
            ClearToolBar();
            AddItemToToolBar(tbInvt);
        }

        private void ClearToolBar()
        {
            if (atsPaneCtrl != null)
            {
                atsPaneCtrl.Controls.Clear();
            }
        }

        private ContextMenu BuildGoodsReceiveContextMenu()
        {
            ContextMenu menu = new ContextMenu();
            menu.MenuItems.Add(new MenuItem(RT2008.Controls.Utility.Dictionary.GetWord("Goods Receive"), string.Empty, "Goods_Receive"));

            MenuItem rec = new MenuItem(RT2008.Controls.Utility.Dictionary.GetWord("Goods Receive (Authorization)"), string.Empty, "Goods_Receive_Authorization");
            rec.Enabled = RT2008.Controls.UserUtility.IsAccessAllowed(Common.Enums.Permission.Posting);

            menu.MenuItems.Add(rec);

            return menu;
        }

        private ContextMenu BuildGoodsReturnContextMenu()
        {
            ContextMenu menu = new ContextMenu();
            menu.MenuItems.Add(new MenuItem(RT2008.Controls.Utility.Dictionary.GetWord("Goods Return"), string.Empty, "Goods_Return"));

            MenuItem rej = new MenuItem(RT2008.Controls.Utility.Dictionary.GetWord("Goods Return (Authorization)"), string.Empty, "Goods_Return_Authorization");
            rej.Enabled = RT2008.Controls.UserUtility.IsAccessAllowed(Common.Enums.Permission.Posting);

            menu.MenuItems.Add(rej);
            return menu;
        }

        private ContextMenu BuildGoodsTransferContextMenu()
        {
            ContextMenu menu = new ContextMenu();
            menu.MenuItems.Add(new MenuItem(RT2008.Controls.Utility.Dictionary.GetWord("Transfer"), string.Empty, "Transfer"));
            menu.MenuItems.Add(new MenuItem(RT2008.Controls.Utility.Dictionary.GetWord("Transfer - Picking Note"), string.Empty, "Transfer_Picking_Note"));
            menu.MenuItems.Add(new MenuItem(RT2008.Controls.Utility.Dictionary.GetWord("Transfer - Picking Note (Fast)"), string.Empty, "Transfer_Picking_Note_Fast"));
            return menu;
        }

        private ContextMenu BuildGoodsAdjustmentContextMenu()
        {
            ContextMenu menu = new ContextMenu();
            menu.MenuItems.Add(new MenuItem(RT2008.Controls.Utility.Dictionary.GetWord("Adjustment"), string.Empty, "Adjustment"));

            MenuItem adj = new MenuItem(RT2008.Controls.Utility.Dictionary.GetWord("Adjustment (Authorization)"), string.Empty, "Adjustment_Authorization");
            adj.Enabled = RT2008.Controls.UserUtility.IsAccessAllowed(Common.Enums.Permission.Posting);
            menu.MenuItems.Add(adj);
            return menu;
        }

        private ContextMenu BuildGoodsReplenishmentContextMenu()
        {
            ContextMenu menu = new ContextMenu();
            menu.MenuItems.Add(new MenuItem(RT2008.Controls.Utility.Dictionary.GetWord("Prepare Replenishment"), string.Empty, "Prepare_Replenishment"));
            //menu.MenuItems.Add(new MenuItem("Replenishment", string.Empty, "Replenishment"));
            //menu.MenuItems.Add(new MenuItem("Replenishment (Advance)", string.Empty, "Replenishment_Advance"));

            MenuItem confirm = new MenuItem(RT2008.Controls.Utility.Dictionary.GetWord("Replenishment (Confirmation)"), string.Empty, "Replenishment_Confirmation");
            confirm.Enabled = RT2008.Controls.UserUtility.IsAccessAllowed(Common.Enums.Permission.Posting);
            menu.MenuItems.Add(confirm);

            MenuItem auth = new MenuItem(RT2008.Controls.Utility.Dictionary.GetWord("Replenishment (Authorization)"), string.Empty, "Replenishment_Authorization");
            auth.Enabled = RT2008.Controls.UserUtility.IsAccessAllowed(Common.Enums.Permission.Posting);
            menu.MenuItems.Add(auth);
            return menu;
        }

        private ContextMenu BuildGoodsStockTakeContextMenu()
        {
            ContextMenu menu = new ContextMenu();
            menu.MenuItems.Add(new MenuItem(RT2008.Controls.Utility.Dictionary.GetWord("Stock Take - All Items"), string.Empty, "StockTake_AllItems"));
            menu.MenuItems.Add(new MenuItem(RT2008.Controls.Utility.Dictionary.GetWord("Stock Take - Partial"), string.Empty, "StockTake_Partial"));
            //menu.MenuItems.Add(new MenuItem("Stock Take", string.Empty, "StockTake"));
            menu.MenuItems.Add(new MenuItem(RT2008.Controls.Utility.Dictionary.GetWord("Re-Capture On-Hand Quantity"), string.Empty, "Recapture_OnHand_Quantity"));

            MenuItem approval = new MenuItem(RT2008.Controls.Utility.Dictionary.GetWord("Stock Take - Approval"), string.Empty, "StockTake_Approval");
            approval.Enabled = RT2008.Controls.UserUtility.IsAccessAllowed(Common.Enums.Permission.Posting);
            menu.MenuItems.Add(approval);

            MenuItem auth = new MenuItem(RT2008.Controls.Utility.Dictionary.GetWord("Stock Take (Authorization)"), string.Empty, "StockTake_Authorization");
            auth.Enabled = RT2008.Controls.UserUtility.IsAccessAllowed(Common.Enums.Permission.Posting);
            menu.MenuItems.Add(auth);
            return menu;
        }

        private void AddItemToToolBar(ToolBar atsInvt)
        {
            atsInvt.MenuHandle = false;
            atsInvt.DragHandle = false;
            atsInvt.TextAlign = ToolBarTextAlign.Right;
            atsInvt.Controls.Clear();

            #region cmdNew
            ContextMenu ddlNew = new ContextMenu();

            switch (fType)
            {
                case FormType.GoodsReceive:
                    ddlNew = BuildGoodsReceiveContextMenu();
                    break;
                case FormType.GoodsReturn:
                    ddlNew = BuildGoodsReturnContextMenu();
                    break;
                case FormType.Transfer:
                    ddlNew = BuildGoodsTransferContextMenu();
                    break;
                case FormType.Adjustment:
                    ddlNew = BuildGoodsAdjustmentContextMenu();
                    break;
                case FormType.Replenishment:
                    ddlNew = BuildGoodsReplenishmentContextMenu();
                    break;
                case FormType.StockTake:
                    ddlNew = BuildGoodsStockTakeContextMenu();
                    break;
                case FormType.All:
                    switch (RT2008.Controls.UserUtility.SecurityLevel())
                    {
                        case "1":
                            ddlNew.MenuItems.AddRange(BuildGoodsTransferContextMenu().MenuItems.Cast<MenuItem>().ToArray<MenuItem>());
                            break;
                        default:
                            ddlNew.MenuItems.AddRange(BuildGoodsReceiveContextMenu().MenuItems.Cast<MenuItem>().ToArray<MenuItem>());
                            ddlNew.MenuItems.Add(new MenuItem("-"));
                            ddlNew.MenuItems.AddRange(BuildGoodsReturnContextMenu().MenuItems.Cast<MenuItem>().ToArray<MenuItem>());
                            ddlNew.MenuItems.Add(new MenuItem("-"));
                            ddlNew.MenuItems.AddRange(BuildGoodsTransferContextMenu().MenuItems.Cast<MenuItem>().ToArray<MenuItem>());
                            ddlNew.MenuItems.Add(new MenuItem("-"));
                            ddlNew.MenuItems.AddRange(BuildGoodsAdjustmentContextMenu().MenuItems.Cast<MenuItem>().ToArray<MenuItem>());
                            ddlNew.MenuItems.Add(new MenuItem("-"));
                            ddlNew.MenuItems.AddRange(BuildGoodsReplenishmentContextMenu().MenuItems.Cast<MenuItem>().ToArray<MenuItem>());
                            ddlNew.MenuItems.Add(new MenuItem("-"));
                            ddlNew.MenuItems.AddRange(BuildGoodsStockTakeContextMenu().MenuItems.Cast<MenuItem>().ToArray<MenuItem>());
                            break;
                    }
                    break;
            }

            ToolBarButton cmdNew = new ToolBarButton("New", RT2008.Controls.Utility.Dictionary.GetWord("New"));
            cmdNew.Style = ToolBarButtonStyle.DropDownButton;
            cmdNew.Image = new IconResourceHandle("16x16.ico_16_3.gif");
            cmdNew.DropDownMenu = ddlNew;
            cmdNew.Enabled = RT2008.Controls.UserUtility.IsAccessAllowed(Common.Enums.Permission.Write);

            atsInvt.Buttons.Add(cmdNew);
            cmdNew.MenuClick += new MenuEventHandler(cmdMenuClick);
            #endregion

            #region cmdImport
            ContextMenu ddlImport = new ContextMenu();

            switch (RT2008.Controls.UserUtility.SecurityLevel())
            {
                case "1":
                    ddlImport.MenuItems.Add(new MenuItem(RT2008.Controls.Utility.Dictionary.GetWord("Transfer"), string.Empty, "Transfer_Import"));
                    ddlImport.MenuItems.Add(new MenuItem(RT2008.Controls.Utility.Dictionary.GetWord("Transfer (Advance)"), string.Empty, "Transfer_Import_Advance"));
                    break;
                default:
                    ddlImport.MenuItems.Add(new MenuItem(RT2008.Controls.Utility.Dictionary.GetWord("Goods Receive") + " (Excel)", string.Empty, "Goods_Receive_Import_Xls"));
                    ddlImport.MenuItems.Add(new MenuItem(RT2008.Controls.Utility.Dictionary.GetWord("Goods Receive") + " (Txt file)", string.Empty, "Goods_Receive_Import_Txt"));
                    ddlImport.MenuItems.Add(new MenuItem("-"));
                    ddlImport.MenuItems.Add(new MenuItem(RT2008.Controls.Utility.Dictionary.GetWord("Goods Return"), string.Empty, "Goods_Return_Import"));
                    ddlImport.MenuItems.Add(new MenuItem("-"));
                    ddlImport.MenuItems.Add(new MenuItem(RT2008.Controls.Utility.Dictionary.GetWord("Transfer"), string.Empty, "Transfer_Import"));
                    ddlImport.MenuItems.Add(new MenuItem(RT2008.Controls.Utility.Dictionary.GetWord("Transfer (Advance)"), string.Empty, "Transfer_Import_Advance"));
                    ddlImport.MenuItems.Add(new MenuItem("-"));
                    ddlImport.MenuItems.Add(new MenuItem(RT2008.Controls.Utility.Dictionary.GetWord("Adjustment"), string.Empty, "Adjustment_Import"));
                    break;
            }

            ToolBarButton cmdImport = new ToolBarButton("Import", RT2008.Controls.Utility.Dictionary.GetWord("Import"));
            cmdImport.Style = ToolBarButtonStyle.DropDownButton;
            cmdImport.Image = new IconResourceHandle("16x16.ico_16_4407.gif");
            cmdImport.Enabled = RT2008.Controls.UserUtility.IsAccessAllowed(Common.Enums.Permission.Write);
            cmdImport.DropDownMenu = ddlImport;

            atsInvt.Buttons.Add(cmdImport);
            cmdImport.MenuClick += new MenuEventHandler(cmdMenuClick);
            #endregion

            #region cmdExport
            ContextMenu ddlExport = new ContextMenu();

            switch (RT2008.Controls.UserUtility.SecurityLevel())
            {
                case "1":
                    ddlExport.MenuItems.Add(new MenuItem(RT2008.Controls.Utility.Dictionary.GetWord("Transfer"), string.Empty, "Transfer_Export"));
                    break;
                default:
                    ddlExport.MenuItems.Add(new MenuItem(RT2008.Controls.Utility.Dictionary.GetWord("Goods Receive"), string.Empty, "Goods_Receive_Export"));
                    ddlExport.MenuItems.Add(new MenuItem(RT2008.Controls.Utility.Dictionary.GetWord("Goods Return"), string.Empty, "Goods_Return_Export"));
                    ddlExport.MenuItems[ddlExport.MenuItems.Count - 1].Enabled = false;
                    ddlExport.MenuItems.Add(new MenuItem(RT2008.Controls.Utility.Dictionary.GetWord("Transfer"), string.Empty, "Transfer_Export"));
                    ddlExport.MenuItems.Add(new MenuItem(RT2008.Controls.Utility.Dictionary.GetWord("Adjustment"), string.Empty, "Adjustment_Export"));
                    ddlExport.MenuItems[ddlExport.MenuItems.Count - 1].Enabled = false;
                    break;
            }

            ToolBarButton cmdExport = new ToolBarButton("Export", RT2008.Controls.Utility.Dictionary.GetWord("Export"));
            cmdExport.Style = ToolBarButtonStyle.DropDownButton;
            cmdExport.Image = new IconResourceHandle("16x16.ico_16_4407_up.gif");
            cmdExport.Enabled = RT2008.Controls.UserUtility.IsAccessAllowed(Common.Enums.Permission.Write);
            cmdExport.DropDownMenu = ddlExport;

            atsInvt.Buttons.Add(cmdExport);
            cmdExport.MenuClick += new MenuEventHandler(cmdMenuClick);

            ToolBarButton sep = new ToolBarButton();
            sep.Style = ToolBarButtonStyle.Separator;
            atsInvt.Buttons.Add(sep);
            #endregion

            #region Stock Status
            switch (RT2008.Controls.UserUtility.SecurityLevel())
            {
                case "1":
                    break;
                default:
                    ContextMenu ddlStockStatus = new ContextMenu();
                    ddlStockStatus.MenuItems.Add(new MenuItem(RT2008.Controls.Utility.Dictionary.GetWord("Monthly"), string.Empty, "StockStatus_Monthly"));
                    ddlStockStatus.MenuItems.Add(new MenuItem(RT2008.Controls.Utility.Dictionary.GetWord("Stock Value"), string.Empty, "StockStatus_StockValue"));
                    ddlStockStatus.MenuItems.Add(new MenuItem(RT2008.Controls.Utility.Dictionary.GetWord("Retail Value"), string.Empty, "StockStatus_RetailValue"));

                    ToolBarButton cmdStockStatus = new ToolBarButton("StockStatus", RT2008.Controls.Utility.Dictionary.GetWord("Stock Status"));
                    cmdStockStatus.Style = ToolBarButtonStyle.DropDownButton;
                    cmdStockStatus.Image = new IconResourceHandle("16x16.16_reports.gif");
                    cmdStockStatus.DropDownMenu = ddlStockStatus;
                    cmdStockStatus.Enabled = RT2008.Controls.UserUtility.IsAccessAllowed(Common.Enums.Permission.Write);

                    atsInvt.Buttons.Add(cmdStockStatus);
                    cmdStockStatus.MenuClick += new MenuEventHandler(cmdMenuClick);
                    break;
            }
            #endregion

            if (atsPaneCtrl != null)
            {
                atsPaneCtrl.Controls.Add(atsInvt);
            }
        }

        void cmdMenuClick(object sender, MenuItemEventArgs e)
        {
            if (!(e.MenuItem.Tag == null))
            {
                switch (e.MenuItem.Tag.ToString().ToLower())
                {
                    case "goods_receive":
                        RT2008.Inventory.GoodsReceive.Wizard wizCAP = new RT2008.Inventory.GoodsReceive.Wizard();
                        wizCAP.ShowDialog();
                        break;
                    case "goods_receive_authorization":
                        RT2008.Inventory.GoodsReceive.Authorization wizAuthRecv = new RT2008.Inventory.GoodsReceive.Authorization();
                        wizAuthRecv.ShowDialog();
                        break;
                    case "goods_return":
                        RT2008.Inventory.GoodsReturn.Wizard wizRej = new RT2008.Inventory.GoodsReturn.Wizard();
                        wizRej.ShowDialog();
                        break;
                    case "goods_return_authorization":
                        RT2008.Inventory.GoodsReturn.Authorization wizAuthRej = new RT2008.Inventory.GoodsReturn.Authorization();
                        wizAuthRej.ShowDialog();
                        break;
                    case "transfer":
                        RT2008.Inventory.Transfer.Wizard wizTxfer = new RT2008.Inventory.Transfer.Wizard(Common.Enums.TxType.TXF);
                        wizTxfer.ShowDialog();
                        break;
                    case "transfer_picking_note":
                        RT2008.Inventory.Transfer.Wizard wizTxfer_PNQ = new RT2008.Inventory.Transfer.Wizard(Common.Enums.TxType.PNQ);
                        wizTxfer_PNQ.ShowDialog();
                        break;
                    case "transfer_picking_note_fast":
                        RT2008.Inventory.Transfer.PickingNoteFast wizPNQFast = new RT2008.Inventory.Transfer.PickingNoteFast();
                        wizPNQFast.ShowDialog();
                        break;
                    case "adjustment":
                        RT2008.Inventory.Adjustment.Wizard wizAdj = new RT2008.Inventory.Adjustment.Wizard();
                        wizAdj.ShowDialog();
                        break;
                    case "adjustment_authorization":
                        RT2008.Inventory.Adjustment.Authorization wizAuthAdj = new RT2008.Inventory.Adjustment.Authorization();
                        wizAuthAdj.ShowDialog();
                        break;
                    case "prepare_replenishment":
                        RT2008.Inventory.Replenishment.Preparation wizRepPreparation = new RT2008.Inventory.Replenishment.Preparation();
                        wizRepPreparation.ShowDialog();
                        break;
                    case "replenishment":
                        RT2008.Inventory.Replenishment.Wizard wizRPL = new RT2008.Inventory.Replenishment.Wizard();
                        wizRPL.ShowDialog();
                        break;
                    case "replenishment_advance":
                        RT2008.Inventory.Replenishment.Wizard_Advance wizRPLAdv = new RT2008.Inventory.Replenishment.Wizard_Advance();
                        wizRPLAdv.ShowDialog();
                        break;
                    case "replenishment_confirmation":
                        RT2008.Inventory.Replenishment.Confirmation wizConfirm = new RT2008.Inventory.Replenishment.Confirmation();
                        wizConfirm.ShowDialog();
                        break;
                    case "replenishment_authorization":
                        RT2008.Inventory.Replenishment.Authorization wizAuth = new RT2008.Inventory.Replenishment.Authorization();
                        wizAuth.ShowDialog();
                        break;
                    case "stocktake_allitems":
                        RT2008.Inventory.StockTake.AllItems wizStkAll = new RT2008.Inventory.StockTake.AllItems();
                        wizStkAll.ShowDialog();
                        break;
                    case "stocktake_partial":
                        RT2008.Inventory.StockTake.PartialItems wizStkPartial = new RT2008.Inventory.StockTake.PartialItems();
                        wizStkPartial.ShowDialog();
                        break;
                    case "stocktake":
                        RT2008.Inventory.StockTake.Wizard wizStockTake = new RT2008.Inventory.StockTake.Wizard();
                        wizStockTake.ShowDialog();
                        break;
                    case "recapture_onhand_quantity":
                        RT2008.Inventory.StockTake.RecaptureOnhand wizRecaptureOnhand = new RT2008.Inventory.StockTake.RecaptureOnhand();
                        wizRecaptureOnhand.ShowDialog();
                        break;
                    case "stocktake_approval":
                        RT2008.Inventory.StockTake.Approval wizApproval = new RT2008.Inventory.StockTake.Approval();
                        wizApproval.ShowDialog();
                        break;
                    case "stocktake_authorization":
                        RT2008.Inventory.StockTake.Authorization wizAuthStk = new RT2008.Inventory.StockTake.Authorization();
                        wizAuthStk.ShowDialog();
                        break;
                    case "goods_receive_import_xls":
                        RT2008.Inventory.GoodsReceive.Import.ImportXls wizXlsImport = new RT2008.Inventory.GoodsReceive.Import.ImportXls();
                        wizXlsImport.ShowDialog();
                        break;
                    case "goods_receive_import_txt":
                        RT2008.Inventory.GoodsReceive.Import.ImportTxt wizCAPTxtImport = new RT2008.Inventory.GoodsReceive.Import.ImportTxt();
                        wizCAPTxtImport.ShowDialog();
                        break;
                    case "goods_return_import":
                        break;
                    case "transfer_import":
                        RT2008.Inventory.Transfer.Import.ImportTxt wizTxferImport = new RT2008.Inventory.Transfer.Import.ImportTxt();
                        wizTxferImport.ShowDialog();
                        break;
                    case "transfer_import_advance":
                        RT2008.Inventory.Transfer.Import.AdvanceImport wizTxferImportAdv = new RT2008.Inventory.Transfer.Import.AdvanceImport();
                        wizTxferImportAdv.ShowDialog();
                        break;
                    case "adjustment_import":
                        break;
                    case "goods_receive_export":
                        RT2008.Inventory.GoodsReceive.Export.Export2Txt wizCAPExport = new RT2008.Inventory.GoodsReceive.Export.Export2Txt();
                        wizCAPExport.ShowDialog();
                        break;
                    case "goods_return_export":
                        break;
                    case "transfer_export":
                        RT2008.Inventory.Transfer.Export.Export2Txt wizTxferExport = new RT2008.Inventory.Transfer.Export.Export2Txt();
                        wizTxferExport.ShowDialog();
                        break;
                    case "adjustment_export":
                        break;
                    case "stockstatus_monthly":
                        RT2008.Inventory.Reports.StockStatus.StockStatus_Monthly wizMonthly = new RT2008.Inventory.Reports.StockStatus.StockStatus_Monthly();
                        wizMonthly.ShowDialog();
                        break;
                    case "stockstatus_stockvalue":
                        RT2008.Inventory.Reports.StockStatus.StockStatus_StockValue wizStockValue = new RT2008.Inventory.Reports.StockStatus.StockStatus_StockValue();
                        wizStockValue.ShowDialog();
                        break;
                    case "stockstatus_retailvalue":
                        RT2008.Inventory.Reports.StockStatus.StockStatus_RetailValue wizRetailValue = new RT2008.Inventory.Reports.StockStatus.StockStatus_RetailValue();
                        wizRetailValue.ShowDialog();
                        break;
                }
            }
        }
    }
}
