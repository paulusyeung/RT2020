using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using DevExpress.XtraReports.UI;

namespace RT2008.Inventory.Reports
{
    public partial class Journal : DevExpress.XtraReports.UI.XtraReport
    {
        public Journal()
        {
            InitializeComponent();
        }

    }
}
