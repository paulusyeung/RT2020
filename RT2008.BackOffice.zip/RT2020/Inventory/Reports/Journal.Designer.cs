namespace RT2008.Inventory.Reports
{
    partial class Journal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Detail = new DevExpress.XtraReports.UI.DetailBand();
            this.oleDbDataAdapter1 = new System.Data.OleDb.OleDbDataAdapter();
            this.oleDbCommand1 = new System.Data.OleDb.OleDbCommand();
            this.oleDbConnection1 = new System.Data.OleDb.OleDbConnection();
            this.GroupHeader1 = new DevExpress.XtraReports.UI.GroupHeaderBand();
            this.stockcode1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text9 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text10 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text11 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text12 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text13 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text14 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text15 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text16 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text17 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text18 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text19 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text20 = new DevExpress.XtraReports.UI.XRLabel();
            this.hdrStock1 = new DevExpress.XtraReports.UI.XRLabel();
            this.hdrAppendix11 = new DevExpress.XtraReports.UI.XRLabel();
            this.hdrAppendix21 = new DevExpress.XtraReports.UI.XRLabel();
            this.hdrAppendix31 = new DevExpress.XtraReports.UI.XRLabel();
            this.hdrClass11 = new DevExpress.XtraReports.UI.XRLabel();
            this.hdrClass21 = new DevExpress.XtraReports.UI.XRLabel();
            this.hdrClass31 = new DevExpress.XtraReports.UI.XRLabel();
            this.hdrClass41 = new DevExpress.XtraReports.UI.XRLabel();
            this.hdrClass51 = new DevExpress.XtraReports.UI.XRLabel();
            this.hdrClass61 = new DevExpress.XtraReports.UI.XRLabel();
            this.StkCode1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Appendix11 = new DevExpress.XtraReports.UI.XRLabel();
            this.Appendix21 = new DevExpress.XtraReports.UI.XRLabel();
            this.Appendix31 = new DevExpress.XtraReports.UI.XRLabel();
            this.Class11 = new DevExpress.XtraReports.UI.XRLabel();
            this.Class21 = new DevExpress.XtraReports.UI.XRLabel();
            this.Class31 = new DevExpress.XtraReports.UI.XRLabel();
            this.Class41 = new DevExpress.XtraReports.UI.XRLabel();
            this.Class51 = new DevExpress.XtraReports.UI.XRLabel();
            this.Class61 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text21 = new DevExpress.XtraReports.UI.XRLabel();
            this.Line1 = new DevExpress.XtraReports.UI.XRLine();
            this.GroupFooter1 = new DevExpress.XtraReports.UI.GroupFooterBand();
            this.Text22 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text23 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text24 = new DevExpress.XtraReports.UI.XRLabel();
            this.SumofQTYIN1 = new DevExpress.XtraReports.UI.XRLabel();
            this.cdamt1 = new DevExpress.XtraReports.UI.XRLabel();
            this.SumofQTYOUT1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text25 = new DevExpress.XtraReports.UI.XRLabel();
            this.Line2 = new DevExpress.XtraReports.UI.XRLine();
            this.Text26 = new DevExpress.XtraReports.UI.XRLabel();
            this.BFQTY1 = new DevExpress.XtraReports.UI.XRLabel();
            this.BFAMT1 = new DevExpress.XtraReports.UI.XRLabel();
            this.CDQTY1 = new DevExpress.XtraReports.UI.XRLabel();
            this.ReportHeader = new DevExpress.XtraReports.UI.ReportHeaderBand();
            this.PageHeader = new DevExpress.XtraReports.UI.PageHeaderBand();
            this.Text1 = new DevExpress.XtraReports.UI.XRLabel();
            this.PrintDate1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text2 = new DevExpress.XtraReports.UI.XRLabel();
            this.hdrtostk1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text3 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text4 = new DevExpress.XtraReports.UI.XRLabel();
            this.hdrfmstk1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text5 = new DevExpress.XtraReports.UI.XRLabel();
            this.PageNumber1 = new DevExpress.XtraReports.UI.XRPageInfo();
            this.hdrtodate1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text6 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text7 = new DevExpress.XtraReports.UI.XRLabel();
            this.hdrfrdate1 = new DevExpress.XtraReports.UI.XRLabel();
            this.PrintTime1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text8 = new DevExpress.XtraReports.UI.XRLabel();
            this.TotalPageCount1 = new DevExpress.XtraReports.UI.XRLabel();
            this.hdrCurrent1 = new DevExpress.XtraReports.UI.XRLabel();
            this.hdrCompName1 = new DevExpress.XtraReports.UI.XRLabel();
            this.type1 = new DevExpress.XtraReports.UI.XRLabel();
            this.QTYIN1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Dateregd1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Amount1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Shop1 = new DevExpress.XtraReports.UI.XRLabel();
            this.SuppNum1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Remarks1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Trnno1 = new DevExpress.XtraReports.UI.XRLabel();
            this.FTShop1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Avrcost1 = new DevExpress.XtraReports.UI.XRLabel();
            this.QTYOUT1 = new DevExpress.XtraReports.UI.XRLabel();
            this.REF1 = new DevExpress.XtraReports.UI.XRLabel();
            this.ReportFooter = new DevExpress.XtraReports.UI.ReportFooterBand();
            this.PageFooter = new DevExpress.XtraReports.UI.PageFooterBand();
            this.pageend1 = new DevExpress.XtraReports.UI.XRLabel();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            // 
            // Detail
            // 
            this.Detail.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.REF1,
            this.QTYOUT1,
            this.Avrcost1,
            this.FTShop1,
            this.Trnno1,
            this.Remarks1,
            this.SuppNum1,
            this.Shop1,
            this.Amount1,
            this.Dateregd1,
            this.QTYIN1,
            this.type1});
            this.Detail.Height = 15;
            this.Detail.Name = "Detail";
            // 
            // oleDbDataAdapter1
            // 
            this.oleDbDataAdapter1.SelectCommand = this.oleDbCommand1;
            this.oleDbDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "rptLedgerDetail", new System.Data.Common.DataColumnMapping[0])});
            // 
            // oleDbCommand1
            // 
            this.oleDbCommand1.CommandText = "SELECT * FROM rptLedgerDetail";
            this.oleDbCommand1.Connection = this.oleDbConnection1;
            // 
            // oleDbConnection1
            // 
            this.oleDbConnection1.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=rptsa1330.mdb";
            // 
            // GroupHeader1
            // 
            this.GroupHeader1.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.Line1,
            this.Text21,
            this.Class61,
            this.Class51,
            this.Class41,
            this.Class31,
            this.Class21,
            this.Class11,
            this.Appendix31,
            this.Appendix21,
            this.Appendix11,
            this.StkCode1,
            this.hdrClass61,
            this.hdrClass51,
            this.hdrClass41,
            this.hdrClass31,
            this.hdrClass21,
            this.hdrClass11,
            this.hdrAppendix31,
            this.hdrAppendix21,
            this.hdrAppendix11,
            this.hdrStock1,
            this.Text20,
            this.Text19,
            this.Text18,
            this.Text17,
            this.Text16,
            this.Text15,
            this.Text14,
            this.Text13,
            this.Text12,
            this.Text11,
            this.Text10,
            this.Text9,
            this.stockcode1});
            this.GroupHeader1.GroupFields.AddRange(new DevExpress.XtraReports.UI.GroupField[] {
            new DevExpress.XtraReports.UI.GroupField("stock code", DevExpress.XtraReports.UI.XRColumnSortOrder.Ascending)});
            this.GroupHeader1.Height = 62;
            this.GroupHeader1.Name = "GroupHeader1";
            // 
            // stockcode1
            // 
            this.stockcode1.BackColor = System.Drawing.Color.White;
            this.stockcode1.BorderColor = System.Drawing.Color.Black;
            this.stockcode1.CanGrow = false;
            this.stockcode1.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.stockcode1.ForeColor = System.Drawing.Color.Black;
            this.stockcode1.Location = new System.Drawing.Point(723, 0);
            this.stockcode1.Name = "stockcode1";
            this.stockcode1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.stockcode1.ParentStyleUsing.UseBackColor = false;
            this.stockcode1.ParentStyleUsing.UseBorderColor = false;
            this.stockcode1.ParentStyleUsing.UseBorders = false;
            this.stockcode1.ParentStyleUsing.UseBorderWidth = false;
            this.stockcode1.ParentStyleUsing.UseFont = false;
            this.stockcode1.ParentStyleUsing.UseForeColor = false;
            this.stockcode1.Size = new System.Drawing.Size(45, 12);
            this.stockcode1.Text = "Untranslated";
            this.stockcode1.Visible = false;
            // 
            // Text9
            // 
            this.Text9.BackColor = System.Drawing.Color.White;
            this.Text9.BorderColor = System.Drawing.Color.Black;
            this.Text9.CanGrow = false;
            this.Text9.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.Text9.ForeColor = System.Drawing.Color.Black;
            this.Text9.Location = new System.Drawing.Point(651, 48);
            this.Text9.Name = "Text9";
            this.Text9.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text9.ParentStyleUsing.UseBackColor = false;
            this.Text9.ParentStyleUsing.UseBorderColor = false;
            this.Text9.ParentStyleUsing.UseBorders = false;
            this.Text9.ParentStyleUsing.UseBorderWidth = false;
            this.Text9.ParentStyleUsing.UseFont = false;
            this.Text9.ParentStyleUsing.UseForeColor = false;
            this.Text9.Size = new System.Drawing.Size(44, 12);
            this.Text9.Text = "SUPP#";
            // 
            // Text10
            // 
            this.Text10.BackColor = System.Drawing.Color.White;
            this.Text10.BorderColor = System.Drawing.Color.Black;
            this.Text10.CanGrow = false;
            this.Text10.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.Text10.ForeColor = System.Drawing.Color.Black;
            this.Text10.Location = new System.Drawing.Point(617, 48);
            this.Text10.Name = "Text10";
            this.Text10.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text10.ParentStyleUsing.UseBackColor = false;
            this.Text10.ParentStyleUsing.UseBorderColor = false;
            this.Text10.ParentStyleUsing.UseBorders = false;
            this.Text10.ParentStyleUsing.UseBorderWidth = false;
            this.Text10.ParentStyleUsing.UseFont = false;
            this.Text10.ParentStyleUsing.UseForeColor = false;
            this.Text10.Size = new System.Drawing.Size(33, 13);
            this.Text10.Text = "LOC#";
            // 
            // Text11
            // 
            this.Text11.BackColor = System.Drawing.Color.White;
            this.Text11.BorderColor = System.Drawing.Color.Black;
            this.Text11.CanGrow = false;
            this.Text11.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.Text11.ForeColor = System.Drawing.Color.Black;
            this.Text11.Location = new System.Drawing.Point(584, 48);
            this.Text11.Name = "Text11";
            this.Text11.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text11.ParentStyleUsing.UseBackColor = false;
            this.Text11.ParentStyleUsing.UseBorderColor = false;
            this.Text11.ParentStyleUsing.UseBorders = false;
            this.Text11.ParentStyleUsing.UseBorderWidth = false;
            this.Text11.ParentStyleUsing.UseFont = false;
            this.Text11.ParentStyleUsing.UseForeColor = false;
            this.Text11.Size = new System.Drawing.Size(32, 12);
            this.Text11.Text = "LOC#";
            // 
            // Text12
            // 
            this.Text12.BackColor = System.Drawing.Color.White;
            this.Text12.BorderColor = System.Drawing.Color.Black;
            this.Text12.CanGrow = false;
            this.Text12.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.Text12.ForeColor = System.Drawing.Color.Black;
            this.Text12.Location = new System.Drawing.Point(436, 48);
            this.Text12.Name = "Text12";
            this.Text12.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text12.ParentStyleUsing.UseBackColor = false;
            this.Text12.ParentStyleUsing.UseBorderColor = false;
            this.Text12.ParentStyleUsing.UseBorders = false;
            this.Text12.ParentStyleUsing.UseBorderWidth = false;
            this.Text12.ParentStyleUsing.UseFont = false;
            this.Text12.ParentStyleUsing.UseForeColor = false;
            this.Text12.Size = new System.Drawing.Size(73, 12);
            this.Text12.Text = "DOCUMENT #";
            // 
            // Text13
            // 
            this.Text13.BackColor = System.Drawing.Color.White;
            this.Text13.BorderColor = System.Drawing.Color.Black;
            this.Text13.CanGrow = false;
            this.Text13.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.Text13.ForeColor = System.Drawing.Color.Black;
            this.Text13.Location = new System.Drawing.Point(241, 48);
            this.Text13.Name = "Text13";
            this.Text13.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text13.ParentStyleUsing.UseBackColor = false;
            this.Text13.ParentStyleUsing.UseBorderColor = false;
            this.Text13.ParentStyleUsing.UseBorders = false;
            this.Text13.ParentStyleUsing.UseBorderWidth = false;
            this.Text13.ParentStyleUsing.UseFont = false;
            this.Text13.ParentStyleUsing.UseForeColor = false;
            this.Text13.Size = new System.Drawing.Size(57, 12);
            this.Text13.Text = "QTY OUT";
            this.Text13.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopRight;
            // 
            // Text14
            // 
            this.Text14.BackColor = System.Drawing.Color.White;
            this.Text14.BorderColor = System.Drawing.Color.Black;
            this.Text14.CanGrow = false;
            this.Text14.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.Text14.ForeColor = System.Drawing.Color.Black;
            this.Text14.Location = new System.Drawing.Point(0, 48);
            this.Text14.Name = "Text14";
            this.Text14.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text14.ParentStyleUsing.UseBackColor = false;
            this.Text14.ParentStyleUsing.UseBorderColor = false;
            this.Text14.ParentStyleUsing.UseBorders = false;
            this.Text14.ParentStyleUsing.UseBorderWidth = false;
            this.Text14.ParentStyleUsing.UseFont = false;
            this.Text14.ParentStyleUsing.UseForeColor = false;
            this.Text14.Size = new System.Drawing.Size(66, 12);
            this.Text14.Text = "DATE ";
            // 
            // Text15
            // 
            this.Text15.BackColor = System.Drawing.Color.White;
            this.Text15.BorderColor = System.Drawing.Color.Black;
            this.Text15.CanGrow = false;
            this.Text15.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.Text15.ForeColor = System.Drawing.Color.Black;
            this.Text15.Location = new System.Drawing.Point(191, 48);
            this.Text15.Name = "Text15";
            this.Text15.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text15.ParentStyleUsing.UseBackColor = false;
            this.Text15.ParentStyleUsing.UseBorderColor = false;
            this.Text15.ParentStyleUsing.UseBorders = false;
            this.Text15.ParentStyleUsing.UseBorderWidth = false;
            this.Text15.ParentStyleUsing.UseFont = false;
            this.Text15.ParentStyleUsing.UseForeColor = false;
            this.Text15.Size = new System.Drawing.Size(50, 12);
            this.Text15.Text = "QTY IN";
            this.Text15.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopRight;
            // 
            // Text16
            // 
            this.Text16.BackColor = System.Drawing.Color.White;
            this.Text16.BorderColor = System.Drawing.Color.Black;
            this.Text16.CanGrow = false;
            this.Text16.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.Text16.ForeColor = System.Drawing.Color.Black;
            this.Text16.Location = new System.Drawing.Point(66, 48);
            this.Text16.Name = "Text16";
            this.Text16.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text16.ParentStyleUsing.UseBackColor = false;
            this.Text16.ParentStyleUsing.UseBorderColor = false;
            this.Text16.ParentStyleUsing.UseBorders = false;
            this.Text16.ParentStyleUsing.UseBorderWidth = false;
            this.Text16.ParentStyleUsing.UseFont = false;
            this.Text16.ParentStyleUsing.UseForeColor = false;
            this.Text16.Size = new System.Drawing.Size(125, 12);
            this.Text16.Text = "TRAN-TYPE";
            // 
            // Text17
            // 
            this.Text17.BackColor = System.Drawing.Color.White;
            this.Text17.BorderColor = System.Drawing.Color.Black;
            this.Text17.CanGrow = false;
            this.Text17.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.Text17.ForeColor = System.Drawing.Color.Black;
            this.Text17.Location = new System.Drawing.Point(695, 48);
            this.Text17.Name = "Text17";
            this.Text17.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text17.ParentStyleUsing.UseBackColor = false;
            this.Text17.ParentStyleUsing.UseBorderColor = false;
            this.Text17.ParentStyleUsing.UseBorders = false;
            this.Text17.ParentStyleUsing.UseBorderWidth = false;
            this.Text17.ParentStyleUsing.UseFont = false;
            this.Text17.ParentStyleUsing.UseForeColor = false;
            this.Text17.Size = new System.Drawing.Size(73, 12);
            this.Text17.Text = "REMARKS";
            // 
            // Text18
            // 
            this.Text18.BackColor = System.Drawing.Color.White;
            this.Text18.BorderColor = System.Drawing.Color.Black;
            this.Text18.CanGrow = false;
            this.Text18.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.Text18.ForeColor = System.Drawing.Color.Black;
            this.Text18.Location = new System.Drawing.Point(373, 48);
            this.Text18.Name = "Text18";
            this.Text18.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text18.ParentStyleUsing.UseBackColor = false;
            this.Text18.ParentStyleUsing.UseBorderColor = false;
            this.Text18.ParentStyleUsing.UseBorders = false;
            this.Text18.ParentStyleUsing.UseBorderWidth = false;
            this.Text18.ParentStyleUsing.UseFont = false;
            this.Text18.ParentStyleUsing.UseForeColor = false;
            this.Text18.Size = new System.Drawing.Size(57, 12);
            this.Text18.Text = "COST";
            this.Text18.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopRight;
            // 
            // Text19
            // 
            this.Text19.BackColor = System.Drawing.Color.White;
            this.Text19.BorderColor = System.Drawing.Color.Black;
            this.Text19.CanGrow = false;
            this.Text19.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.Text19.ForeColor = System.Drawing.Color.Black;
            this.Text19.Location = new System.Drawing.Point(299, 48);
            this.Text19.Name = "Text19";
            this.Text19.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text19.ParentStyleUsing.UseBackColor = false;
            this.Text19.ParentStyleUsing.UseBorderColor = false;
            this.Text19.ParentStyleUsing.UseBorders = false;
            this.Text19.ParentStyleUsing.UseBorderWidth = false;
            this.Text19.ParentStyleUsing.UseFont = false;
            this.Text19.ParentStyleUsing.UseForeColor = false;
            this.Text19.Size = new System.Drawing.Size(75, 12);
            this.Text19.Text = "PRICE";
            this.Text19.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopRight;
            // 
            // Text20
            // 
            this.Text20.BackColor = System.Drawing.Color.White;
            this.Text20.BorderColor = System.Drawing.Color.Black;
            this.Text20.CanGrow = false;
            this.Text20.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.Text20.ForeColor = System.Drawing.Color.Black;
            this.Text20.Location = new System.Drawing.Point(617, 36);
            this.Text20.Name = "Text20";
            this.Text20.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text20.ParentStyleUsing.UseBackColor = false;
            this.Text20.ParentStyleUsing.UseBorderColor = false;
            this.Text20.ParentStyleUsing.UseBorders = false;
            this.Text20.ParentStyleUsing.UseBorderWidth = false;
            this.Text20.ParentStyleUsing.UseFont = false;
            this.Text20.ParentStyleUsing.UseForeColor = false;
            this.Text20.Size = new System.Drawing.Size(33, 12);
            this.Text20.Text = "VS";
            // 
            // hdrStock1
            // 
            this.hdrStock1.BackColor = System.Drawing.Color.White;
            this.hdrStock1.BorderColor = System.Drawing.Color.Black;
            this.hdrStock1.CanGrow = false;
            this.hdrStock1.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.hdrStock1.ForeColor = System.Drawing.Color.Black;
            this.hdrStock1.Location = new System.Drawing.Point(0, 0);
            this.hdrStock1.Name = "hdrStock1";
            this.hdrStock1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.hdrStock1.ParentStyleUsing.UseBackColor = false;
            this.hdrStock1.ParentStyleUsing.UseBorderColor = false;
            this.hdrStock1.ParentStyleUsing.UseBorders = false;
            this.hdrStock1.ParentStyleUsing.UseBorderWidth = false;
            this.hdrStock1.ParentStyleUsing.UseFont = false;
            this.hdrStock1.ParentStyleUsing.UseForeColor = false;
            this.hdrStock1.Size = new System.Drawing.Size(75, 12);
            this.hdrStock1.Text = "Untranslated";
            // 
            // hdrAppendix11
            // 
            this.hdrAppendix11.BackColor = System.Drawing.Color.White;
            this.hdrAppendix11.BorderColor = System.Drawing.Color.Black;
            this.hdrAppendix11.CanGrow = false;
            this.hdrAppendix11.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.hdrAppendix11.ForeColor = System.Drawing.Color.Black;
            this.hdrAppendix11.Location = new System.Drawing.Point(0, 12);
            this.hdrAppendix11.Name = "hdrAppendix11";
            this.hdrAppendix11.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.hdrAppendix11.ParentStyleUsing.UseBackColor = false;
            this.hdrAppendix11.ParentStyleUsing.UseBorderColor = false;
            this.hdrAppendix11.ParentStyleUsing.UseBorders = false;
            this.hdrAppendix11.ParentStyleUsing.UseBorderWidth = false;
            this.hdrAppendix11.ParentStyleUsing.UseFont = false;
            this.hdrAppendix11.ParentStyleUsing.UseForeColor = false;
            this.hdrAppendix11.Size = new System.Drawing.Size(75, 12);
            this.hdrAppendix11.Text = "Untranslated";
            // 
            // hdrAppendix21
            // 
            this.hdrAppendix21.BackColor = System.Drawing.Color.White;
            this.hdrAppendix21.BorderColor = System.Drawing.Color.Black;
            this.hdrAppendix21.CanGrow = false;
            this.hdrAppendix21.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.hdrAppendix21.ForeColor = System.Drawing.Color.Black;
            this.hdrAppendix21.Location = new System.Drawing.Point(0, 24);
            this.hdrAppendix21.Name = "hdrAppendix21";
            this.hdrAppendix21.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.hdrAppendix21.ParentStyleUsing.UseBackColor = false;
            this.hdrAppendix21.ParentStyleUsing.UseBorderColor = false;
            this.hdrAppendix21.ParentStyleUsing.UseBorders = false;
            this.hdrAppendix21.ParentStyleUsing.UseBorderWidth = false;
            this.hdrAppendix21.ParentStyleUsing.UseFont = false;
            this.hdrAppendix21.ParentStyleUsing.UseForeColor = false;
            this.hdrAppendix21.Size = new System.Drawing.Size(75, 12);
            this.hdrAppendix21.Text = "Untranslated";
            // 
            // hdrAppendix31
            // 
            this.hdrAppendix31.BackColor = System.Drawing.Color.White;
            this.hdrAppendix31.BorderColor = System.Drawing.Color.Black;
            this.hdrAppendix31.CanGrow = false;
            this.hdrAppendix31.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.hdrAppendix31.ForeColor = System.Drawing.Color.Black;
            this.hdrAppendix31.Location = new System.Drawing.Point(0, 36);
            this.hdrAppendix31.Name = "hdrAppendix31";
            this.hdrAppendix31.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.hdrAppendix31.ParentStyleUsing.UseBackColor = false;
            this.hdrAppendix31.ParentStyleUsing.UseBorderColor = false;
            this.hdrAppendix31.ParentStyleUsing.UseBorders = false;
            this.hdrAppendix31.ParentStyleUsing.UseBorderWidth = false;
            this.hdrAppendix31.ParentStyleUsing.UseFont = false;
            this.hdrAppendix31.ParentStyleUsing.UseForeColor = false;
            this.hdrAppendix31.Size = new System.Drawing.Size(75, 12);
            this.hdrAppendix31.Text = "Untranslated";
            // 
            // hdrClass11
            // 
            this.hdrClass11.BackColor = System.Drawing.Color.White;
            this.hdrClass11.BorderColor = System.Drawing.Color.Black;
            this.hdrClass11.CanGrow = false;
            this.hdrClass11.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.hdrClass11.ForeColor = System.Drawing.Color.Black;
            this.hdrClass11.Location = new System.Drawing.Point(175, 0);
            this.hdrClass11.Name = "hdrClass11";
            this.hdrClass11.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.hdrClass11.ParentStyleUsing.UseBackColor = false;
            this.hdrClass11.ParentStyleUsing.UseBorderColor = false;
            this.hdrClass11.ParentStyleUsing.UseBorders = false;
            this.hdrClass11.ParentStyleUsing.UseBorderWidth = false;
            this.hdrClass11.ParentStyleUsing.UseFont = false;
            this.hdrClass11.ParentStyleUsing.UseForeColor = false;
            this.hdrClass11.Size = new System.Drawing.Size(66, 12);
            this.hdrClass11.Text = "Untranslated";
            // 
            // hdrClass21
            // 
            this.hdrClass21.BackColor = System.Drawing.Color.White;
            this.hdrClass21.BorderColor = System.Drawing.Color.Black;
            this.hdrClass21.CanGrow = false;
            this.hdrClass21.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.hdrClass21.ForeColor = System.Drawing.Color.Black;
            this.hdrClass21.Location = new System.Drawing.Point(175, 12);
            this.hdrClass21.Name = "hdrClass21";
            this.hdrClass21.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.hdrClass21.ParentStyleUsing.UseBackColor = false;
            this.hdrClass21.ParentStyleUsing.UseBorderColor = false;
            this.hdrClass21.ParentStyleUsing.UseBorders = false;
            this.hdrClass21.ParentStyleUsing.UseBorderWidth = false;
            this.hdrClass21.ParentStyleUsing.UseFont = false;
            this.hdrClass21.ParentStyleUsing.UseForeColor = false;
            this.hdrClass21.Size = new System.Drawing.Size(66, 12);
            this.hdrClass21.Text = "Untranslated";
            // 
            // hdrClass31
            // 
            this.hdrClass31.BackColor = System.Drawing.Color.White;
            this.hdrClass31.BorderColor = System.Drawing.Color.Black;
            this.hdrClass31.CanGrow = false;
            this.hdrClass31.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.hdrClass31.ForeColor = System.Drawing.Color.Black;
            this.hdrClass31.Location = new System.Drawing.Point(175, 24);
            this.hdrClass31.Name = "hdrClass31";
            this.hdrClass31.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.hdrClass31.ParentStyleUsing.UseBackColor = false;
            this.hdrClass31.ParentStyleUsing.UseBorderColor = false;
            this.hdrClass31.ParentStyleUsing.UseBorders = false;
            this.hdrClass31.ParentStyleUsing.UseBorderWidth = false;
            this.hdrClass31.ParentStyleUsing.UseFont = false;
            this.hdrClass31.ParentStyleUsing.UseForeColor = false;
            this.hdrClass31.Size = new System.Drawing.Size(66, 12);
            this.hdrClass31.Text = "Untranslated";
            // 
            // hdrClass41
            // 
            this.hdrClass41.BackColor = System.Drawing.Color.White;
            this.hdrClass41.BorderColor = System.Drawing.Color.Black;
            this.hdrClass41.CanGrow = false;
            this.hdrClass41.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.hdrClass41.ForeColor = System.Drawing.Color.Black;
            this.hdrClass41.Location = new System.Drawing.Point(323, 0);
            this.hdrClass41.Name = "hdrClass41";
            this.hdrClass41.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.hdrClass41.ParentStyleUsing.UseBackColor = false;
            this.hdrClass41.ParentStyleUsing.UseBorderColor = false;
            this.hdrClass41.ParentStyleUsing.UseBorders = false;
            this.hdrClass41.ParentStyleUsing.UseBorderWidth = false;
            this.hdrClass41.ParentStyleUsing.UseFont = false;
            this.hdrClass41.ParentStyleUsing.UseForeColor = false;
            this.hdrClass41.Size = new System.Drawing.Size(66, 12);
            this.hdrClass41.Text = "Untranslated";
            // 
            // hdrClass51
            // 
            this.hdrClass51.BackColor = System.Drawing.Color.White;
            this.hdrClass51.BorderColor = System.Drawing.Color.Black;
            this.hdrClass51.CanGrow = false;
            this.hdrClass51.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.hdrClass51.ForeColor = System.Drawing.Color.Black;
            this.hdrClass51.Location = new System.Drawing.Point(323, 12);
            this.hdrClass51.Name = "hdrClass51";
            this.hdrClass51.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.hdrClass51.ParentStyleUsing.UseBackColor = false;
            this.hdrClass51.ParentStyleUsing.UseBorderColor = false;
            this.hdrClass51.ParentStyleUsing.UseBorders = false;
            this.hdrClass51.ParentStyleUsing.UseBorderWidth = false;
            this.hdrClass51.ParentStyleUsing.UseFont = false;
            this.hdrClass51.ParentStyleUsing.UseForeColor = false;
            this.hdrClass51.Size = new System.Drawing.Size(66, 12);
            this.hdrClass51.Text = "Untranslated";
            // 
            // hdrClass61
            // 
            this.hdrClass61.BackColor = System.Drawing.Color.White;
            this.hdrClass61.BorderColor = System.Drawing.Color.Black;
            this.hdrClass61.CanGrow = false;
            this.hdrClass61.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.hdrClass61.ForeColor = System.Drawing.Color.Black;
            this.hdrClass61.Location = new System.Drawing.Point(323, 24);
            this.hdrClass61.Name = "hdrClass61";
            this.hdrClass61.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.hdrClass61.ParentStyleUsing.UseBackColor = false;
            this.hdrClass61.ParentStyleUsing.UseBorderColor = false;
            this.hdrClass61.ParentStyleUsing.UseBorders = false;
            this.hdrClass61.ParentStyleUsing.UseBorderWidth = false;
            this.hdrClass61.ParentStyleUsing.UseFont = false;
            this.hdrClass61.ParentStyleUsing.UseForeColor = false;
            this.hdrClass61.Size = new System.Drawing.Size(66, 12);
            this.hdrClass61.Text = "Untranslated";
            // 
            // StkCode1
            // 
            this.StkCode1.BackColor = System.Drawing.Color.White;
            this.StkCode1.BorderColor = System.Drawing.Color.Black;
            this.StkCode1.CanGrow = false;
            this.StkCode1.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "rptStock.StkCode", "")});
            this.StkCode1.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.StkCode1.ForeColor = System.Drawing.Color.Black;
            this.StkCode1.Location = new System.Drawing.Point(81, 0);
            this.StkCode1.Name = "StkCode1";
            this.StkCode1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.StkCode1.ParentStyleUsing.UseBackColor = false;
            this.StkCode1.ParentStyleUsing.UseBorderColor = false;
            this.StkCode1.ParentStyleUsing.UseBorders = false;
            this.StkCode1.ParentStyleUsing.UseBorderWidth = false;
            this.StkCode1.ParentStyleUsing.UseFont = false;
            this.StkCode1.ParentStyleUsing.UseForeColor = false;
            this.StkCode1.Size = new System.Drawing.Size(75, 12);
            // 
            // Appendix11
            // 
            this.Appendix11.BackColor = System.Drawing.Color.White;
            this.Appendix11.BorderColor = System.Drawing.Color.Black;
            this.Appendix11.CanGrow = false;
            this.Appendix11.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "rptStock.Appendix1", "")});
            this.Appendix11.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.Appendix11.ForeColor = System.Drawing.Color.Black;
            this.Appendix11.Location = new System.Drawing.Point(81, 12);
            this.Appendix11.Name = "Appendix11";
            this.Appendix11.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Appendix11.ParentStyleUsing.UseBackColor = false;
            this.Appendix11.ParentStyleUsing.UseBorderColor = false;
            this.Appendix11.ParentStyleUsing.UseBorders = false;
            this.Appendix11.ParentStyleUsing.UseBorderWidth = false;
            this.Appendix11.ParentStyleUsing.UseFont = false;
            this.Appendix11.ParentStyleUsing.UseForeColor = false;
            this.Appendix11.Size = new System.Drawing.Size(50, 12);
            // 
            // Appendix21
            // 
            this.Appendix21.BackColor = System.Drawing.Color.White;
            this.Appendix21.BorderColor = System.Drawing.Color.Black;
            this.Appendix21.CanGrow = false;
            this.Appendix21.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "rptStock.Appendix2", "")});
            this.Appendix21.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.Appendix21.ForeColor = System.Drawing.Color.Black;
            this.Appendix21.Location = new System.Drawing.Point(81, 24);
            this.Appendix21.Name = "Appendix21";
            this.Appendix21.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Appendix21.ParentStyleUsing.UseBackColor = false;
            this.Appendix21.ParentStyleUsing.UseBorderColor = false;
            this.Appendix21.ParentStyleUsing.UseBorders = false;
            this.Appendix21.ParentStyleUsing.UseBorderWidth = false;
            this.Appendix21.ParentStyleUsing.UseFont = false;
            this.Appendix21.ParentStyleUsing.UseForeColor = false;
            this.Appendix21.Size = new System.Drawing.Size(50, 12);
            // 
            // Appendix31
            // 
            this.Appendix31.BackColor = System.Drawing.Color.White;
            this.Appendix31.BorderColor = System.Drawing.Color.Black;
            this.Appendix31.CanGrow = false;
            this.Appendix31.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "rptStock.Appendix3", "")});
            this.Appendix31.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.Appendix31.ForeColor = System.Drawing.Color.Black;
            this.Appendix31.Location = new System.Drawing.Point(82, 36);
            this.Appendix31.Name = "Appendix31";
            this.Appendix31.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Appendix31.ParentStyleUsing.UseBackColor = false;
            this.Appendix31.ParentStyleUsing.UseBorderColor = false;
            this.Appendix31.ParentStyleUsing.UseBorders = false;
            this.Appendix31.ParentStyleUsing.UseBorderWidth = false;
            this.Appendix31.ParentStyleUsing.UseFont = false;
            this.Appendix31.ParentStyleUsing.UseForeColor = false;
            this.Appendix31.Size = new System.Drawing.Size(50, 12);
            // 
            // Class11
            // 
            this.Class11.BackColor = System.Drawing.Color.White;
            this.Class11.BorderColor = System.Drawing.Color.Black;
            this.Class11.CanGrow = false;
            this.Class11.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "rptStock.Class1", "")});
            this.Class11.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.Class11.ForeColor = System.Drawing.Color.Black;
            this.Class11.Location = new System.Drawing.Point(241, 0);
            this.Class11.Name = "Class11";
            this.Class11.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Class11.ParentStyleUsing.UseBackColor = false;
            this.Class11.ParentStyleUsing.UseBorderColor = false;
            this.Class11.ParentStyleUsing.UseBorders = false;
            this.Class11.ParentStyleUsing.UseBorderWidth = false;
            this.Class11.ParentStyleUsing.UseFont = false;
            this.Class11.ParentStyleUsing.UseForeColor = false;
            this.Class11.Size = new System.Drawing.Size(37, 12);
            // 
            // Class21
            // 
            this.Class21.BackColor = System.Drawing.Color.White;
            this.Class21.BorderColor = System.Drawing.Color.Black;
            this.Class21.CanGrow = false;
            this.Class21.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "rptStock.Class2", "")});
            this.Class21.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.Class21.ForeColor = System.Drawing.Color.Black;
            this.Class21.Location = new System.Drawing.Point(241, 12);
            this.Class21.Name = "Class21";
            this.Class21.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Class21.ParentStyleUsing.UseBackColor = false;
            this.Class21.ParentStyleUsing.UseBorderColor = false;
            this.Class21.ParentStyleUsing.UseBorders = false;
            this.Class21.ParentStyleUsing.UseBorderWidth = false;
            this.Class21.ParentStyleUsing.UseFont = false;
            this.Class21.ParentStyleUsing.UseForeColor = false;
            this.Class21.Size = new System.Drawing.Size(37, 12);
            // 
            // Class31
            // 
            this.Class31.BackColor = System.Drawing.Color.White;
            this.Class31.BorderColor = System.Drawing.Color.Black;
            this.Class31.CanGrow = false;
            this.Class31.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "rptStock.Class3", "")});
            this.Class31.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.Class31.ForeColor = System.Drawing.Color.Black;
            this.Class31.Location = new System.Drawing.Point(241, 24);
            this.Class31.Name = "Class31";
            this.Class31.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Class31.ParentStyleUsing.UseBackColor = false;
            this.Class31.ParentStyleUsing.UseBorderColor = false;
            this.Class31.ParentStyleUsing.UseBorders = false;
            this.Class31.ParentStyleUsing.UseBorderWidth = false;
            this.Class31.ParentStyleUsing.UseFont = false;
            this.Class31.ParentStyleUsing.UseForeColor = false;
            this.Class31.Size = new System.Drawing.Size(37, 12);
            // 
            // Class41
            // 
            this.Class41.BackColor = System.Drawing.Color.White;
            this.Class41.BorderColor = System.Drawing.Color.Black;
            this.Class41.CanGrow = false;
            this.Class41.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "rptStock.Class4", "")});
            this.Class41.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.Class41.ForeColor = System.Drawing.Color.Black;
            this.Class41.Location = new System.Drawing.Point(398, 0);
            this.Class41.Name = "Class41";
            this.Class41.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Class41.ParentStyleUsing.UseBackColor = false;
            this.Class41.ParentStyleUsing.UseBorderColor = false;
            this.Class41.ParentStyleUsing.UseBorders = false;
            this.Class41.ParentStyleUsing.UseBorderWidth = false;
            this.Class41.ParentStyleUsing.UseFont = false;
            this.Class41.ParentStyleUsing.UseForeColor = false;
            this.Class41.Size = new System.Drawing.Size(37, 12);
            // 
            // Class51
            // 
            this.Class51.BackColor = System.Drawing.Color.White;
            this.Class51.BorderColor = System.Drawing.Color.Black;
            this.Class51.CanGrow = false;
            this.Class51.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "rptStock.Class5", "")});
            this.Class51.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.Class51.ForeColor = System.Drawing.Color.Black;
            this.Class51.Location = new System.Drawing.Point(398, 12);
            this.Class51.Name = "Class51";
            this.Class51.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Class51.ParentStyleUsing.UseBackColor = false;
            this.Class51.ParentStyleUsing.UseBorderColor = false;
            this.Class51.ParentStyleUsing.UseBorders = false;
            this.Class51.ParentStyleUsing.UseBorderWidth = false;
            this.Class51.ParentStyleUsing.UseFont = false;
            this.Class51.ParentStyleUsing.UseForeColor = false;
            this.Class51.Size = new System.Drawing.Size(37, 12);
            // 
            // Class61
            // 
            this.Class61.BackColor = System.Drawing.Color.White;
            this.Class61.BorderColor = System.Drawing.Color.Black;
            this.Class61.CanGrow = false;
            this.Class61.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "rptStock.Class6", "")});
            this.Class61.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.Class61.ForeColor = System.Drawing.Color.Black;
            this.Class61.Location = new System.Drawing.Point(398, 24);
            this.Class61.Name = "Class61";
            this.Class61.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Class61.ParentStyleUsing.UseBackColor = false;
            this.Class61.ParentStyleUsing.UseBorderColor = false;
            this.Class61.ParentStyleUsing.UseBorders = false;
            this.Class61.ParentStyleUsing.UseBorderWidth = false;
            this.Class61.ParentStyleUsing.UseFont = false;
            this.Class61.ParentStyleUsing.UseForeColor = false;
            this.Class61.Size = new System.Drawing.Size(37, 12);
            // 
            // Text21
            // 
            this.Text21.BackColor = System.Drawing.Color.White;
            this.Text21.BorderColor = System.Drawing.Color.Black;
            this.Text21.CanGrow = false;
            this.Text21.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.Text21.ForeColor = System.Drawing.Color.Black;
            this.Text21.Location = new System.Drawing.Point(510, 48);
            this.Text21.Name = "Text21";
            this.Text21.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text21.ParentStyleUsing.UseBackColor = false;
            this.Text21.ParentStyleUsing.UseBorderColor = false;
            this.Text21.ParentStyleUsing.UseBorders = false;
            this.Text21.ParentStyleUsing.UseBorderWidth = false;
            this.Text21.ParentStyleUsing.UseFont = false;
            this.Text21.ParentStyleUsing.UseForeColor = false;
            this.Text21.Size = new System.Drawing.Size(74, 12);
            this.Text21.Text = "REF#";
            // 
            // Line1
            // 
            this.Line1.BackColor = System.Drawing.Color.White;
            this.Line1.BorderColor = System.Drawing.Color.Black;
            this.Line1.Borders = DevExpress.XtraPrinting.BorderSide.Top;
            this.Line1.CanGrow = false;
            this.Line1.ForeColor = System.Drawing.Color.Black;
            this.Line1.Location = new System.Drawing.Point(0, 60);
            this.Line1.Name = "Line1";
            this.Line1.ParentStyleUsing.UseBackColor = false;
            this.Line1.ParentStyleUsing.UseBorderColor = false;
            this.Line1.ParentStyleUsing.UseBorders = false;
            this.Line1.ParentStyleUsing.UseBorderWidth = false;
            this.Line1.ParentStyleUsing.UseFont = false;
            this.Line1.ParentStyleUsing.UseForeColor = false;
            this.Line1.Size = new System.Drawing.Size(769, 2);
            // 
            // GroupFooter1
            // 
            this.GroupFooter1.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.CDQTY1,
            this.BFAMT1,
            this.BFQTY1,
            this.Text26,
            this.Line2,
            this.Text25,
            this.SumofQTYOUT1,
            this.cdamt1,
            this.SumofQTYIN1,
            this.Text24,
            this.Text23,
            this.Text22});
            this.GroupFooter1.Height = 42;
            this.GroupFooter1.Name = "GroupFooter1";
            // 
            // Text22
            // 
            this.Text22.BackColor = System.Drawing.Color.White;
            this.Text22.BorderColor = System.Drawing.Color.Black;
            this.Text22.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.Text22.ForeColor = System.Drawing.Color.Black;
            this.Text22.Location = new System.Drawing.Point(330, 16);
            this.Text22.Name = "Text22";
            this.Text22.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text22.ParentStyleUsing.UseBackColor = false;
            this.Text22.ParentStyleUsing.UseBorderColor = false;
            this.Text22.ParentStyleUsing.UseBorders = false;
            this.Text22.ParentStyleUsing.UseBorderWidth = false;
            this.Text22.ParentStyleUsing.UseFont = false;
            this.Text22.ParentStyleUsing.UseForeColor = false;
            this.Text22.Size = new System.Drawing.Size(43, 10);
            this.Text22.Text = "BF QTY:";
            this.Text22.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopRight;
            // 
            // Text23
            // 
            this.Text23.BackColor = System.Drawing.Color.White;
            this.Text23.BorderColor = System.Drawing.Color.Black;
            this.Text23.CanGrow = false;
            this.Text23.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.Text23.ForeColor = System.Drawing.Color.Black;
            this.Text23.Location = new System.Drawing.Point(436, 16);
            this.Text23.Name = "Text23";
            this.Text23.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text23.ParentStyleUsing.UseBackColor = false;
            this.Text23.ParentStyleUsing.UseBorderColor = false;
            this.Text23.ParentStyleUsing.UseBorders = false;
            this.Text23.ParentStyleUsing.UseBorderWidth = false;
            this.Text23.ParentStyleUsing.UseFont = false;
            this.Text23.ParentStyleUsing.UseForeColor = false;
            this.Text23.Size = new System.Drawing.Size(50, 12);
            this.Text23.Text = "BF AMT:";
            this.Text23.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopRight;
            // 
            // Text24
            // 
            this.Text24.BackColor = System.Drawing.Color.White;
            this.Text24.BorderColor = System.Drawing.Color.Black;
            this.Text24.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.Text24.ForeColor = System.Drawing.Color.Black;
            this.Text24.Location = new System.Drawing.Point(664, 16);
            this.Text24.Name = "Text24";
            this.Text24.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text24.ParentStyleUsing.UseBackColor = false;
            this.Text24.ParentStyleUsing.UseBorderColor = false;
            this.Text24.ParentStyleUsing.UseBorders = false;
            this.Text24.ParentStyleUsing.UseBorderWidth = false;
            this.Text24.ParentStyleUsing.UseFont = false;
            this.Text24.ParentStyleUsing.UseForeColor = false;
            this.Text24.Size = new System.Drawing.Size(43, 10);
            this.Text24.Text = "CD AMT:";
            this.Text24.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopRight;
            // 
            // SumofQTYIN1
            // 
            this.SumofQTYIN1.BackColor = System.Drawing.Color.White;
            this.SumofQTYIN1.BorderColor = System.Drawing.Color.Black;
            this.SumofQTYIN1.CanGrow = false;
            this.SumofQTYIN1.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.SumofQTYIN1.ForeColor = System.Drawing.Color.Black;
            this.SumofQTYIN1.Location = new System.Drawing.Point(191, 16);
            this.SumofQTYIN1.Name = "SumofQTYIN1";
            this.SumofQTYIN1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.SumofQTYIN1.ParentStyleUsing.UseBackColor = false;
            this.SumofQTYIN1.ParentStyleUsing.UseBorderColor = false;
            this.SumofQTYIN1.ParentStyleUsing.UseBorders = false;
            this.SumofQTYIN1.ParentStyleUsing.UseBorderWidth = false;
            this.SumofQTYIN1.ParentStyleUsing.UseFont = false;
            this.SumofQTYIN1.ParentStyleUsing.UseForeColor = false;
            this.SumofQTYIN1.Size = new System.Drawing.Size(50, 11);
            // 
            // cdamt1
            // 
            this.cdamt1.BackColor = System.Drawing.Color.White;
            this.cdamt1.BorderColor = System.Drawing.Color.Black;
            this.cdamt1.CanGrow = false;
            this.cdamt1.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.cdamt1.ForeColor = System.Drawing.Color.Black;
            this.cdamt1.Location = new System.Drawing.Point(709, 16);
            this.cdamt1.Name = "cdamt1";
            this.cdamt1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.cdamt1.ParentStyleUsing.UseBackColor = false;
            this.cdamt1.ParentStyleUsing.UseBorderColor = false;
            this.cdamt1.ParentStyleUsing.UseBorders = false;
            this.cdamt1.ParentStyleUsing.UseBorderWidth = false;
            this.cdamt1.ParentStyleUsing.UseFont = false;
            this.cdamt1.ParentStyleUsing.UseForeColor = false;
            this.cdamt1.Size = new System.Drawing.Size(59, 11);
            this.cdamt1.Text = "Untranslated";
            this.cdamt1.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopRight;
            // 
            // SumofQTYOUT1
            // 
            this.SumofQTYOUT1.BackColor = System.Drawing.Color.White;
            this.SumofQTYOUT1.BorderColor = System.Drawing.Color.Black;
            this.SumofQTYOUT1.CanGrow = false;
            this.SumofQTYOUT1.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.SumofQTYOUT1.ForeColor = System.Drawing.Color.Black;
            this.SumofQTYOUT1.Location = new System.Drawing.Point(241, 16);
            this.SumofQTYOUT1.Name = "SumofQTYOUT1";
            this.SumofQTYOUT1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.SumofQTYOUT1.ParentStyleUsing.UseBackColor = false;
            this.SumofQTYOUT1.ParentStyleUsing.UseBorderColor = false;
            this.SumofQTYOUT1.ParentStyleUsing.UseBorders = false;
            this.SumofQTYOUT1.ParentStyleUsing.UseBorderWidth = false;
            this.SumofQTYOUT1.ParentStyleUsing.UseFont = false;
            this.SumofQTYOUT1.ParentStyleUsing.UseForeColor = false;
            this.SumofQTYOUT1.Size = new System.Drawing.Size(57, 11);
            // 
            // Text25
            // 
            this.Text25.BackColor = System.Drawing.Color.White;
            this.Text25.BorderColor = System.Drawing.Color.Black;
            this.Text25.CanGrow = false;
            this.Text25.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.Text25.ForeColor = System.Drawing.Color.Black;
            this.Text25.Location = new System.Drawing.Point(0, 16);
            this.Text25.Name = "Text25";
            this.Text25.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text25.ParentStyleUsing.UseBackColor = false;
            this.Text25.ParentStyleUsing.UseBorderColor = false;
            this.Text25.ParentStyleUsing.UseBorders = false;
            this.Text25.ParentStyleUsing.UseBorderWidth = false;
            this.Text25.ParentStyleUsing.UseFont = false;
            this.Text25.ParentStyleUsing.UseForeColor = false;
            this.Text25.Size = new System.Drawing.Size(191, 12);
            this.Text25.Text = "SUB-TOTAL ...........................";
            // 
            // Line2
            // 
            this.Line2.BackColor = System.Drawing.Color.White;
            this.Line2.BorderColor = System.Drawing.Color.Black;
            this.Line2.Borders = DevExpress.XtraPrinting.BorderSide.Top;
            this.Line2.CanGrow = false;
            this.Line2.ForeColor = System.Drawing.Color.Black;
            this.Line2.Location = new System.Drawing.Point(0, 0);
            this.Line2.Name = "Line2";
            this.Line2.ParentStyleUsing.UseBackColor = false;
            this.Line2.ParentStyleUsing.UseBorderColor = false;
            this.Line2.ParentStyleUsing.UseBorders = false;
            this.Line2.ParentStyleUsing.UseBorderWidth = false;
            this.Line2.ParentStyleUsing.UseFont = false;
            this.Line2.ParentStyleUsing.UseForeColor = false;
            this.Line2.Size = new System.Drawing.Size(779, 2);
            // 
            // Text26
            // 
            this.Text26.BackColor = System.Drawing.Color.White;
            this.Text26.BorderColor = System.Drawing.Color.Black;
            this.Text26.CanGrow = false;
            this.Text26.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.Text26.ForeColor = System.Drawing.Color.Black;
            this.Text26.Location = new System.Drawing.Point(559, 16);
            this.Text26.Name = "Text26";
            this.Text26.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text26.ParentStyleUsing.UseBackColor = false;
            this.Text26.ParentStyleUsing.UseBorderColor = false;
            this.Text26.ParentStyleUsing.UseBorders = false;
            this.Text26.ParentStyleUsing.UseBorderWidth = false;
            this.Text26.ParentStyleUsing.UseFont = false;
            this.Text26.ParentStyleUsing.UseForeColor = false;
            this.Text26.Size = new System.Drawing.Size(50, 12);
            this.Text26.Text = "CD QTY:";
            this.Text26.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopRight;
            // 
            // BFQTY1
            // 
            this.BFQTY1.BackColor = System.Drawing.Color.White;
            this.BFQTY1.BorderColor = System.Drawing.Color.Black;
            this.BFQTY1.CanGrow = false;
            this.BFQTY1.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "rptStockSum.BFQTY", "")});
            this.BFQTY1.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.BFQTY1.ForeColor = System.Drawing.Color.Black;
            this.BFQTY1.Location = new System.Drawing.Point(373, 16);
            this.BFQTY1.Name = "BFQTY1";
            this.BFQTY1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.BFQTY1.ParentStyleUsing.UseBackColor = false;
            this.BFQTY1.ParentStyleUsing.UseBorderColor = false;
            this.BFQTY1.ParentStyleUsing.UseBorders = false;
            this.BFQTY1.ParentStyleUsing.UseBorderWidth = false;
            this.BFQTY1.ParentStyleUsing.UseFont = false;
            this.BFQTY1.ParentStyleUsing.UseForeColor = false;
            this.BFQTY1.Size = new System.Drawing.Size(32, 11);
            // 
            // BFAMT1
            // 
            this.BFAMT1.BackColor = System.Drawing.Color.White;
            this.BFAMT1.BorderColor = System.Drawing.Color.Black;
            this.BFAMT1.CanGrow = false;
            this.BFAMT1.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "rptStockSum.BFAMT", "")});
            this.BFAMT1.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.BFAMT1.ForeColor = System.Drawing.Color.Black;
            this.BFAMT1.Location = new System.Drawing.Point(489, 16);
            this.BFAMT1.Name = "BFAMT1";
            this.BFAMT1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.BFAMT1.ParentStyleUsing.UseBackColor = false;
            this.BFAMT1.ParentStyleUsing.UseBorderColor = false;
            this.BFAMT1.ParentStyleUsing.UseBorders = false;
            this.BFAMT1.ParentStyleUsing.UseBorderWidth = false;
            this.BFAMT1.ParentStyleUsing.UseFont = false;
            this.BFAMT1.ParentStyleUsing.UseForeColor = false;
            this.BFAMT1.Size = new System.Drawing.Size(42, 11);
            // 
            // CDQTY1
            // 
            this.CDQTY1.BackColor = System.Drawing.Color.White;
            this.CDQTY1.BorderColor = System.Drawing.Color.Black;
            this.CDQTY1.CanGrow = false;
            this.CDQTY1.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "rptStockSum.CDQTY", "")});
            this.CDQTY1.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.CDQTY1.ForeColor = System.Drawing.Color.Black;
            this.CDQTY1.Location = new System.Drawing.Point(617, 16);
            this.CDQTY1.Name = "CDQTY1";
            this.CDQTY1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.CDQTY1.ParentStyleUsing.UseBackColor = false;
            this.CDQTY1.ParentStyleUsing.UseBorderColor = false;
            this.CDQTY1.ParentStyleUsing.UseBorders = false;
            this.CDQTY1.ParentStyleUsing.UseBorderWidth = false;
            this.CDQTY1.ParentStyleUsing.UseFont = false;
            this.CDQTY1.ParentStyleUsing.UseForeColor = false;
            this.CDQTY1.Size = new System.Drawing.Size(32, 11);
            // 
            // ReportHeader
            // 
            this.ReportHeader.Height = 0;
            this.ReportHeader.Name = "ReportHeader";
            // 
            // PageHeader
            // 
            this.PageHeader.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.hdrCompName1,
            this.hdrCurrent1,
            this.TotalPageCount1,
            this.Text8,
            this.PrintTime1,
            this.hdrfrdate1,
            this.Text7,
            this.Text6,
            this.hdrtodate1,
            this.PageNumber1,
            this.Text5,
            this.hdrfmstk1,
            this.Text4,
            this.Text3,
            this.hdrtostk1,
            this.Text2,
            this.PrintDate1,
            this.Text1});
            this.PageHeader.Name = "PageHeader";
            // 
            // Text1
            // 
            this.Text1.BackColor = System.Drawing.Color.White;
            this.Text1.BorderColor = System.Drawing.Color.Black;
            this.Text1.CanGrow = false;
            this.Text1.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Bold);
            this.Text1.ForeColor = System.Drawing.Color.Black;
            this.Text1.Location = new System.Drawing.Point(0, 18);
            this.Text1.Name = "Text1";
            this.Text1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text1.ParentStyleUsing.UseBackColor = false;
            this.Text1.ParentStyleUsing.UseBorderColor = false;
            this.Text1.ParentStyleUsing.UseBorders = false;
            this.Text1.ParentStyleUsing.UseBorderWidth = false;
            this.Text1.ParentStyleUsing.UseFont = false;
            this.Text1.ParentStyleUsing.UseForeColor = false;
            this.Text1.Size = new System.Drawing.Size(362, 16);
            this.Text1.Text = "SA1330 - In / Out History List For Month";
            // 
            // PrintDate1
            // 
            this.PrintDate1.BackColor = System.Drawing.Color.White;
            this.PrintDate1.BorderColor = System.Drawing.Color.Black;
            this.PrintDate1.CanGrow = false;
            this.PrintDate1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.PrintDate1.ForeColor = System.Drawing.Color.Black;
            this.PrintDate1.Location = new System.Drawing.Point(617, 49);
            this.PrintDate1.Name = "PrintDate1";
            this.PrintDate1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.PrintDate1.ParentStyleUsing.UseBackColor = false;
            this.PrintDate1.ParentStyleUsing.UseBorderColor = false;
            this.PrintDate1.ParentStyleUsing.UseBorders = false;
            this.PrintDate1.ParentStyleUsing.UseBorderWidth = false;
            this.PrintDate1.ParentStyleUsing.UseFont = false;
            this.PrintDate1.ParentStyleUsing.UseForeColor = false;
            this.PrintDate1.Size = new System.Drawing.Size(62, 12);
            this.PrintDate1.Text = "Untranslated";
            // 
            // Text2
            // 
            this.Text2.BackColor = System.Drawing.Color.White;
            this.Text2.BorderColor = System.Drawing.Color.Black;
            this.Text2.CanGrow = false;
            this.Text2.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.Text2.ForeColor = System.Drawing.Color.Black;
            this.Text2.Location = new System.Drawing.Point(510, 49);
            this.Text2.Name = "Text2";
            this.Text2.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text2.ParentStyleUsing.UseBackColor = false;
            this.Text2.ParentStyleUsing.UseBorderColor = false;
            this.Text2.ParentStyleUsing.UseBorders = false;
            this.Text2.ParentStyleUsing.UseBorderWidth = false;
            this.Text2.ParentStyleUsing.UseFont = false;
            this.Text2.ParentStyleUsing.UseForeColor = false;
            this.Text2.Size = new System.Drawing.Size(97, 12);
            this.Text2.Text = "Print At :";
            this.Text2.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopRight;
            // 
            // hdrtostk1
            // 
            this.hdrtostk1.BackColor = System.Drawing.Color.White;
            this.hdrtostk1.BorderColor = System.Drawing.Color.Black;
            this.hdrtostk1.CanGrow = false;
            this.hdrtostk1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.hdrtostk1.ForeColor = System.Drawing.Color.Black;
            this.hdrtostk1.Location = new System.Drawing.Point(191, 62);
            this.hdrtostk1.Name = "hdrtostk1";
            this.hdrtostk1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.hdrtostk1.ParentStyleUsing.UseBackColor = false;
            this.hdrtostk1.ParentStyleUsing.UseBorderColor = false;
            this.hdrtostk1.ParentStyleUsing.UseBorders = false;
            this.hdrtostk1.ParentStyleUsing.UseBorderWidth = false;
            this.hdrtostk1.ParentStyleUsing.UseFont = false;
            this.hdrtostk1.ParentStyleUsing.UseForeColor = false;
            this.hdrtostk1.Size = new System.Drawing.Size(83, 12);
            this.hdrtostk1.Text = "Untranslated";
            // 
            // Text3
            // 
            this.Text3.BackColor = System.Drawing.Color.White;
            this.Text3.BorderColor = System.Drawing.Color.Black;
            this.Text3.CanGrow = false;
            this.Text3.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.Text3.ForeColor = System.Drawing.Color.Black;
            this.Text3.Location = new System.Drawing.Point(0, 62);
            this.Text3.Name = "Text3";
            this.Text3.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text3.ParentStyleUsing.UseBackColor = false;
            this.Text3.ParentStyleUsing.UseBorderColor = false;
            this.Text3.ParentStyleUsing.UseBorders = false;
            this.Text3.ParentStyleUsing.UseBorderWidth = false;
            this.Text3.ParentStyleUsing.UseFont = false;
            this.Text3.ParentStyleUsing.UseForeColor = false;
            this.Text3.Size = new System.Drawing.Size(75, 12);
            this.Text3.Text = "From Art# :";
            // 
            // Text4
            // 
            this.Text4.BackColor = System.Drawing.Color.White;
            this.Text4.BorderColor = System.Drawing.Color.Black;
            this.Text4.CanGrow = false;
            this.Text4.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.Text4.ForeColor = System.Drawing.Color.Black;
            this.Text4.Location = new System.Drawing.Point(170, 62);
            this.Text4.Name = "Text4";
            this.Text4.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text4.ParentStyleUsing.UseBackColor = false;
            this.Text4.ParentStyleUsing.UseBorderColor = false;
            this.Text4.ParentStyleUsing.UseBorders = false;
            this.Text4.ParentStyleUsing.UseBorderWidth = false;
            this.Text4.ParentStyleUsing.UseFont = false;
            this.Text4.ParentStyleUsing.UseForeColor = false;
            this.Text4.Size = new System.Drawing.Size(20, 12);
            this.Text4.Text = "TO";
            // 
            // hdrfmstk1
            // 
            this.hdrfmstk1.BackColor = System.Drawing.Color.White;
            this.hdrfmstk1.BorderColor = System.Drawing.Color.Black;
            this.hdrfmstk1.CanGrow = false;
            this.hdrfmstk1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.hdrfmstk1.ForeColor = System.Drawing.Color.Black;
            this.hdrfmstk1.Location = new System.Drawing.Point(75, 62);
            this.hdrfmstk1.Name = "hdrfmstk1";
            this.hdrfmstk1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.hdrfmstk1.ParentStyleUsing.UseBackColor = false;
            this.hdrfmstk1.ParentStyleUsing.UseBorderColor = false;
            this.hdrfmstk1.ParentStyleUsing.UseBorders = false;
            this.hdrfmstk1.ParentStyleUsing.UseBorderWidth = false;
            this.hdrfmstk1.ParentStyleUsing.UseFont = false;
            this.hdrfmstk1.ParentStyleUsing.UseForeColor = false;
            this.hdrfmstk1.Size = new System.Drawing.Size(83, 12);
            this.hdrfmstk1.Text = "Untranslated";
            // 
            // Text5
            // 
            this.Text5.BackColor = System.Drawing.Color.White;
            this.Text5.BorderColor = System.Drawing.Color.Black;
            this.Text5.CanGrow = false;
            this.Text5.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.Text5.ForeColor = System.Drawing.Color.Black;
            this.Text5.Location = new System.Drawing.Point(510, 62);
            this.Text5.Name = "Text5";
            this.Text5.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text5.ParentStyleUsing.UseBackColor = false;
            this.Text5.ParentStyleUsing.UseBorderColor = false;
            this.Text5.ParentStyleUsing.UseBorders = false;
            this.Text5.ParentStyleUsing.UseBorderWidth = false;
            this.Text5.ParentStyleUsing.UseFont = false;
            this.Text5.ParentStyleUsing.UseForeColor = false;
            this.Text5.Size = new System.Drawing.Size(97, 14);
            this.Text5.Text = "Page :";
            this.Text5.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopRight;
            // 
            // PageNumber1
            // 
            this.PageNumber1.BackColor = System.Drawing.Color.White;
            this.PageNumber1.BorderColor = System.Drawing.Color.Black;
            this.PageNumber1.CanGrow = false;
            this.PageNumber1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.PageNumber1.ForeColor = System.Drawing.Color.Black;
            this.PageNumber1.Location = new System.Drawing.Point(617, 62);
            this.PageNumber1.Name = "PageNumber1";
            this.PageNumber1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.PageNumber1.PageInfo = DevExpress.XtraPrinting.PageInfo.Number;
            this.PageNumber1.ParentStyleUsing.UseBackColor = false;
            this.PageNumber1.ParentStyleUsing.UseBorderColor = false;
            this.PageNumber1.ParentStyleUsing.UseBorders = false;
            this.PageNumber1.ParentStyleUsing.UseBorderWidth = false;
            this.PageNumber1.ParentStyleUsing.UseFont = false;
            this.PageNumber1.ParentStyleUsing.UseForeColor = false;
            this.PageNumber1.Size = new System.Drawing.Size(33, 12);
            // 
            // hdrtodate1
            // 
            this.hdrtodate1.BackColor = System.Drawing.Color.White;
            this.hdrtodate1.BorderColor = System.Drawing.Color.Black;
            this.hdrtodate1.CanGrow = false;
            this.hdrtodate1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.hdrtodate1.ForeColor = System.Drawing.Color.Black;
            this.hdrtodate1.Location = new System.Drawing.Point(191, 76);
            this.hdrtodate1.Name = "hdrtodate1";
            this.hdrtodate1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.hdrtodate1.ParentStyleUsing.UseBackColor = false;
            this.hdrtodate1.ParentStyleUsing.UseBorderColor = false;
            this.hdrtodate1.ParentStyleUsing.UseBorders = false;
            this.hdrtodate1.ParentStyleUsing.UseBorderWidth = false;
            this.hdrtodate1.ParentStyleUsing.UseFont = false;
            this.hdrtodate1.ParentStyleUsing.UseForeColor = false;
            this.hdrtodate1.Size = new System.Drawing.Size(83, 12);
            this.hdrtodate1.Text = "Untranslated";
            // 
            // Text6
            // 
            this.Text6.BackColor = System.Drawing.Color.White;
            this.Text6.BorderColor = System.Drawing.Color.Black;
            this.Text6.CanGrow = false;
            this.Text6.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.Text6.ForeColor = System.Drawing.Color.Black;
            this.Text6.Location = new System.Drawing.Point(170, 76);
            this.Text6.Name = "Text6";
            this.Text6.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text6.ParentStyleUsing.UseBackColor = false;
            this.Text6.ParentStyleUsing.UseBorderColor = false;
            this.Text6.ParentStyleUsing.UseBorders = false;
            this.Text6.ParentStyleUsing.UseBorderWidth = false;
            this.Text6.ParentStyleUsing.UseFont = false;
            this.Text6.ParentStyleUsing.UseForeColor = false;
            this.Text6.Size = new System.Drawing.Size(20, 12);
            this.Text6.Text = "TO";
            // 
            // Text7
            // 
            this.Text7.BackColor = System.Drawing.Color.White;
            this.Text7.BorderColor = System.Drawing.Color.Black;
            this.Text7.CanGrow = false;
            this.Text7.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.Text7.ForeColor = System.Drawing.Color.Black;
            this.Text7.Location = new System.Drawing.Point(0, 76);
            this.Text7.Name = "Text7";
            this.Text7.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text7.ParentStyleUsing.UseBackColor = false;
            this.Text7.ParentStyleUsing.UseBorderColor = false;
            this.Text7.ParentStyleUsing.UseBorders = false;
            this.Text7.ParentStyleUsing.UseBorderWidth = false;
            this.Text7.ParentStyleUsing.UseFont = false;
            this.Text7.ParentStyleUsing.UseForeColor = false;
            this.Text7.Size = new System.Drawing.Size(75, 12);
            this.Text7.Text = "From Date :";
            // 
            // hdrfrdate1
            // 
            this.hdrfrdate1.BackColor = System.Drawing.Color.White;
            this.hdrfrdate1.BorderColor = System.Drawing.Color.Black;
            this.hdrfrdate1.CanGrow = false;
            this.hdrfrdate1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.hdrfrdate1.ForeColor = System.Drawing.Color.Black;
            this.hdrfrdate1.Location = new System.Drawing.Point(75, 76);
            this.hdrfrdate1.Name = "hdrfrdate1";
            this.hdrfrdate1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.hdrfrdate1.ParentStyleUsing.UseBackColor = false;
            this.hdrfrdate1.ParentStyleUsing.UseBorderColor = false;
            this.hdrfrdate1.ParentStyleUsing.UseBorders = false;
            this.hdrfrdate1.ParentStyleUsing.UseBorderWidth = false;
            this.hdrfrdate1.ParentStyleUsing.UseFont = false;
            this.hdrfrdate1.ParentStyleUsing.UseForeColor = false;
            this.hdrfrdate1.Size = new System.Drawing.Size(83, 12);
            this.hdrfrdate1.Text = "Untranslated";
            // 
            // PrintTime1
            // 
            this.PrintTime1.BackColor = System.Drawing.Color.White;
            this.PrintTime1.BorderColor = System.Drawing.Color.Black;
            this.PrintTime1.CanGrow = false;
            this.PrintTime1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.PrintTime1.ForeColor = System.Drawing.Color.Black;
            this.PrintTime1.Location = new System.Drawing.Point(679, 49);
            this.PrintTime1.Name = "PrintTime1";
            this.PrintTime1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.PrintTime1.ParentStyleUsing.UseBackColor = false;
            this.PrintTime1.ParentStyleUsing.UseBorderColor = false;
            this.PrintTime1.ParentStyleUsing.UseBorders = false;
            this.PrintTime1.ParentStyleUsing.UseBorderWidth = false;
            this.PrintTime1.ParentStyleUsing.UseFont = false;
            this.PrintTime1.ParentStyleUsing.UseForeColor = false;
            this.PrintTime1.Size = new System.Drawing.Size(63, 12);
            this.PrintTime1.Text = "Untranslated";
            // 
            // Text8
            // 
            this.Text8.BackColor = System.Drawing.Color.White;
            this.Text8.BorderColor = System.Drawing.Color.Black;
            this.Text8.CanGrow = false;
            this.Text8.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.Text8.ForeColor = System.Drawing.Color.Black;
            this.Text8.Location = new System.Drawing.Point(651, 62);
            this.Text8.Name = "Text8";
            this.Text8.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text8.ParentStyleUsing.UseBackColor = false;
            this.Text8.ParentStyleUsing.UseBorderColor = false;
            this.Text8.ParentStyleUsing.UseBorders = false;
            this.Text8.ParentStyleUsing.UseBorderWidth = false;
            this.Text8.ParentStyleUsing.UseFont = false;
            this.Text8.ParentStyleUsing.UseForeColor = false;
            this.Text8.Size = new System.Drawing.Size(25, 12);
            this.Text8.Text = "of";
            this.Text8.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter;
            // 
            // TotalPageCount1
            // 
            this.TotalPageCount1.BackColor = System.Drawing.Color.White;
            this.TotalPageCount1.BorderColor = System.Drawing.Color.Black;
            this.TotalPageCount1.CanGrow = false;
            this.TotalPageCount1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.TotalPageCount1.ForeColor = System.Drawing.Color.Black;
            this.TotalPageCount1.Location = new System.Drawing.Point(676, 62);
            this.TotalPageCount1.Name = "TotalPageCount1";
            this.TotalPageCount1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.TotalPageCount1.ParentStyleUsing.UseBackColor = false;
            this.TotalPageCount1.ParentStyleUsing.UseBorderColor = false;
            this.TotalPageCount1.ParentStyleUsing.UseBorders = false;
            this.TotalPageCount1.ParentStyleUsing.UseBorderWidth = false;
            this.TotalPageCount1.ParentStyleUsing.UseFont = false;
            this.TotalPageCount1.ParentStyleUsing.UseForeColor = false;
            this.TotalPageCount1.Size = new System.Drawing.Size(60, 12);
            this.TotalPageCount1.Text = "Untranslated";
            // 
            // hdrCurrent1
            // 
            this.hdrCurrent1.BackColor = System.Drawing.Color.White;
            this.hdrCurrent1.BorderColor = System.Drawing.Color.Black;
            this.hdrCurrent1.CanGrow = false;
            this.hdrCurrent1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.hdrCurrent1.ForeColor = System.Drawing.Color.Black;
            this.hdrCurrent1.Location = new System.Drawing.Point(0, 36);
            this.hdrCurrent1.Name = "hdrCurrent1";
            this.hdrCurrent1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.hdrCurrent1.ParentStyleUsing.UseBackColor = false;
            this.hdrCurrent1.ParentStyleUsing.UseBorderColor = false;
            this.hdrCurrent1.ParentStyleUsing.UseBorders = false;
            this.hdrCurrent1.ParentStyleUsing.UseBorderWidth = false;
            this.hdrCurrent1.ParentStyleUsing.UseFont = false;
            this.hdrCurrent1.ParentStyleUsing.UseForeColor = false;
            this.hdrCurrent1.Size = new System.Drawing.Size(416, 12);
            this.hdrCurrent1.Text = "Untranslated";
            // 
            // hdrCompName1
            // 
            this.hdrCompName1.BackColor = System.Drawing.Color.White;
            this.hdrCompName1.BorderColor = System.Drawing.Color.Black;
            this.hdrCompName1.CanGrow = false;
            this.hdrCompName1.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Bold);
            this.hdrCompName1.ForeColor = System.Drawing.Color.Black;
            this.hdrCompName1.Location = new System.Drawing.Point(0, 0);
            this.hdrCompName1.Name = "hdrCompName1";
            this.hdrCompName1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.hdrCompName1.ParentStyleUsing.UseBackColor = false;
            this.hdrCompName1.ParentStyleUsing.UseBorderColor = false;
            this.hdrCompName1.ParentStyleUsing.UseBorders = false;
            this.hdrCompName1.ParentStyleUsing.UseBorderWidth = false;
            this.hdrCompName1.ParentStyleUsing.UseFont = false;
            this.hdrCompName1.ParentStyleUsing.UseForeColor = false;
            this.hdrCompName1.Size = new System.Drawing.Size(769, 16);
            this.hdrCompName1.Text = "Untranslated";
            // 
            // type1
            // 
            this.type1.BackColor = System.Drawing.Color.White;
            this.type1.BorderColor = System.Drawing.Color.Black;
            this.type1.CanGrow = false;
            this.type1.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.type1.ForeColor = System.Drawing.Color.Black;
            this.type1.Location = new System.Drawing.Point(66, 0);
            this.type1.Name = "type1";
            this.type1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.type1.ParentStyleUsing.UseBackColor = false;
            this.type1.ParentStyleUsing.UseBorderColor = false;
            this.type1.ParentStyleUsing.UseBorders = false;
            this.type1.ParentStyleUsing.UseBorderWidth = false;
            this.type1.ParentStyleUsing.UseFont = false;
            this.type1.ParentStyleUsing.UseForeColor = false;
            this.type1.Size = new System.Drawing.Size(125, 10);
            this.type1.Text = "Untranslated";
            // 
            // QTYIN1
            // 
            this.QTYIN1.BackColor = System.Drawing.Color.White;
            this.QTYIN1.BorderColor = System.Drawing.Color.Black;
            this.QTYIN1.CanGrow = false;
            this.QTYIN1.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.QTYIN1.ForeColor = System.Drawing.Color.Black;
            this.QTYIN1.Location = new System.Drawing.Point(191, 0);
            this.QTYIN1.Name = "QTYIN1";
            this.QTYIN1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.QTYIN1.ParentStyleUsing.UseBackColor = false;
            this.QTYIN1.ParentStyleUsing.UseBorderColor = false;
            this.QTYIN1.ParentStyleUsing.UseBorders = false;
            this.QTYIN1.ParentStyleUsing.UseBorderWidth = false;
            this.QTYIN1.ParentStyleUsing.UseFont = false;
            this.QTYIN1.ParentStyleUsing.UseForeColor = false;
            this.QTYIN1.Size = new System.Drawing.Size(50, 11);
            this.QTYIN1.Text = "Untranslated";
            // 
            // Dateregd1
            // 
            this.Dateregd1.BackColor = System.Drawing.Color.White;
            this.Dateregd1.BorderColor = System.Drawing.Color.Black;
            this.Dateregd1.CanGrow = false;
            this.Dateregd1.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "rptLedgerDetail.Dateregd", "")});
            this.Dateregd1.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.Dateregd1.ForeColor = System.Drawing.Color.Black;
            this.Dateregd1.Location = new System.Drawing.Point(0, 0);
            this.Dateregd1.Name = "Dateregd1";
            this.Dateregd1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Dateregd1.ParentStyleUsing.UseBackColor = false;
            this.Dateregd1.ParentStyleUsing.UseBorderColor = false;
            this.Dateregd1.ParentStyleUsing.UseBorders = false;
            this.Dateregd1.ParentStyleUsing.UseBorderWidth = false;
            this.Dateregd1.ParentStyleUsing.UseFont = false;
            this.Dateregd1.ParentStyleUsing.UseForeColor = false;
            this.Dateregd1.Size = new System.Drawing.Size(66, 11);
            // 
            // Amount1
            // 
            this.Amount1.BackColor = System.Drawing.Color.White;
            this.Amount1.BorderColor = System.Drawing.Color.Black;
            this.Amount1.CanGrow = false;
            this.Amount1.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "rptLedgerDetail.Amount", "")});
            this.Amount1.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.Amount1.ForeColor = System.Drawing.Color.Black;
            this.Amount1.Location = new System.Drawing.Point(299, 0);
            this.Amount1.Name = "Amount1";
            this.Amount1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Amount1.ParentStyleUsing.UseBackColor = false;
            this.Amount1.ParentStyleUsing.UseBorderColor = false;
            this.Amount1.ParentStyleUsing.UseBorders = false;
            this.Amount1.ParentStyleUsing.UseBorderWidth = false;
            this.Amount1.ParentStyleUsing.UseFont = false;
            this.Amount1.ParentStyleUsing.UseForeColor = false;
            this.Amount1.Size = new System.Drawing.Size(74, 11);
            // 
            // Shop1
            // 
            this.Shop1.BackColor = System.Drawing.Color.White;
            this.Shop1.BorderColor = System.Drawing.Color.Black;
            this.Shop1.CanGrow = false;
            this.Shop1.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "rptLedgerHeader.Shop", "")});
            this.Shop1.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.Shop1.ForeColor = System.Drawing.Color.Black;
            this.Shop1.Location = new System.Drawing.Point(584, 0);
            this.Shop1.Name = "Shop1";
            this.Shop1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Shop1.ParentStyleUsing.UseBackColor = false;
            this.Shop1.ParentStyleUsing.UseBorderColor = false;
            this.Shop1.ParentStyleUsing.UseBorders = false;
            this.Shop1.ParentStyleUsing.UseBorderWidth = false;
            this.Shop1.ParentStyleUsing.UseFont = false;
            this.Shop1.ParentStyleUsing.UseForeColor = false;
            this.Shop1.Size = new System.Drawing.Size(32, 9);
            // 
            // SuppNum1
            // 
            this.SuppNum1.BackColor = System.Drawing.Color.White;
            this.SuppNum1.BorderColor = System.Drawing.Color.Black;
            this.SuppNum1.CanGrow = false;
            this.SuppNum1.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "rptLedgerHeader.SuppNum", "")});
            this.SuppNum1.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.SuppNum1.ForeColor = System.Drawing.Color.Black;
            this.SuppNum1.Location = new System.Drawing.Point(651, 0);
            this.SuppNum1.Name = "SuppNum1";
            this.SuppNum1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.SuppNum1.ParentStyleUsing.UseBackColor = false;
            this.SuppNum1.ParentStyleUsing.UseBorderColor = false;
            this.SuppNum1.ParentStyleUsing.UseBorders = false;
            this.SuppNum1.ParentStyleUsing.UseBorderWidth = false;
            this.SuppNum1.ParentStyleUsing.UseFont = false;
            this.SuppNum1.ParentStyleUsing.UseForeColor = false;
            this.SuppNum1.Size = new System.Drawing.Size(44, 8);
            // 
            // Remarks1
            // 
            this.Remarks1.BackColor = System.Drawing.Color.White;
            this.Remarks1.BorderColor = System.Drawing.Color.Black;
            this.Remarks1.CanGrow = false;
            this.Remarks1.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "rptLedgerHeader.Remarks", "")});
            this.Remarks1.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.Remarks1.ForeColor = System.Drawing.Color.Black;
            this.Remarks1.Location = new System.Drawing.Point(695, 0);
            this.Remarks1.Name = "Remarks1";
            this.Remarks1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Remarks1.ParentStyleUsing.UseBackColor = false;
            this.Remarks1.ParentStyleUsing.UseBorderColor = false;
            this.Remarks1.ParentStyleUsing.UseBorders = false;
            this.Remarks1.ParentStyleUsing.UseBorderWidth = false;
            this.Remarks1.ParentStyleUsing.UseFont = false;
            this.Remarks1.ParentStyleUsing.UseForeColor = false;
            this.Remarks1.Size = new System.Drawing.Size(73, 9);
            // 
            // Trnno1
            // 
            this.Trnno1.BackColor = System.Drawing.Color.White;
            this.Trnno1.BorderColor = System.Drawing.Color.Black;
            this.Trnno1.CanGrow = false;
            this.Trnno1.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "rptLedgerDetail.Trnno", "")});
            this.Trnno1.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.Trnno1.ForeColor = System.Drawing.Color.Black;
            this.Trnno1.Location = new System.Drawing.Point(436, 0);
            this.Trnno1.Name = "Trnno1";
            this.Trnno1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Trnno1.ParentStyleUsing.UseBackColor = false;
            this.Trnno1.ParentStyleUsing.UseBorderColor = false;
            this.Trnno1.ParentStyleUsing.UseBorders = false;
            this.Trnno1.ParentStyleUsing.UseBorderWidth = false;
            this.Trnno1.ParentStyleUsing.UseFont = false;
            this.Trnno1.ParentStyleUsing.UseForeColor = false;
            this.Trnno1.Size = new System.Drawing.Size(73, 9);
            // 
            // FTShop1
            // 
            this.FTShop1.BackColor = System.Drawing.Color.White;
            this.FTShop1.BorderColor = System.Drawing.Color.Black;
            this.FTShop1.CanGrow = false;
            this.FTShop1.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "rptLedgerHeader.FTShop", "")});
            this.FTShop1.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.FTShop1.ForeColor = System.Drawing.Color.Black;
            this.FTShop1.Location = new System.Drawing.Point(617, 0);
            this.FTShop1.Name = "FTShop1";
            this.FTShop1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.FTShop1.ParentStyleUsing.UseBackColor = false;
            this.FTShop1.ParentStyleUsing.UseBorderColor = false;
            this.FTShop1.ParentStyleUsing.UseBorders = false;
            this.FTShop1.ParentStyleUsing.UseBorderWidth = false;
            this.FTShop1.ParentStyleUsing.UseFont = false;
            this.FTShop1.ParentStyleUsing.UseForeColor = false;
            this.FTShop1.Size = new System.Drawing.Size(33, 9);
            // 
            // Avrcost1
            // 
            this.Avrcost1.BackColor = System.Drawing.Color.White;
            this.Avrcost1.BorderColor = System.Drawing.Color.Black;
            this.Avrcost1.CanGrow = false;
            this.Avrcost1.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "rptLedgerDetail.Avrcost", "")});
            this.Avrcost1.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.Avrcost1.ForeColor = System.Drawing.Color.Black;
            this.Avrcost1.Location = new System.Drawing.Point(373, 0);
            this.Avrcost1.Name = "Avrcost1";
            this.Avrcost1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Avrcost1.ParentStyleUsing.UseBackColor = false;
            this.Avrcost1.ParentStyleUsing.UseBorderColor = false;
            this.Avrcost1.ParentStyleUsing.UseBorders = false;
            this.Avrcost1.ParentStyleUsing.UseBorderWidth = false;
            this.Avrcost1.ParentStyleUsing.UseFont = false;
            this.Avrcost1.ParentStyleUsing.UseForeColor = false;
            this.Avrcost1.Size = new System.Drawing.Size(57, 11);
            // 
            // QTYOUT1
            // 
            this.QTYOUT1.BackColor = System.Drawing.Color.White;
            this.QTYOUT1.BorderColor = System.Drawing.Color.Black;
            this.QTYOUT1.CanGrow = false;
            this.QTYOUT1.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.QTYOUT1.ForeColor = System.Drawing.Color.Black;
            this.QTYOUT1.Location = new System.Drawing.Point(241, 0);
            this.QTYOUT1.Name = "QTYOUT1";
            this.QTYOUT1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.QTYOUT1.ParentStyleUsing.UseBackColor = false;
            this.QTYOUT1.ParentStyleUsing.UseBorderColor = false;
            this.QTYOUT1.ParentStyleUsing.UseBorders = false;
            this.QTYOUT1.ParentStyleUsing.UseBorderWidth = false;
            this.QTYOUT1.ParentStyleUsing.UseFont = false;
            this.QTYOUT1.ParentStyleUsing.UseForeColor = false;
            this.QTYOUT1.Size = new System.Drawing.Size(57, 11);
            this.QTYOUT1.Text = "Untranslated";
            // 
            // REF1
            // 
            this.REF1.BackColor = System.Drawing.Color.White;
            this.REF1.BorderColor = System.Drawing.Color.Black;
            this.REF1.CanGrow = false;
            this.REF1.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "rptLedgerHeader.REF", "")});
            this.REF1.Font = new System.Drawing.Font("Arial Unicode MS", 6F);
            this.REF1.ForeColor = System.Drawing.Color.Black;
            this.REF1.Location = new System.Drawing.Point(510, 0);
            this.REF1.Name = "REF1";
            this.REF1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.REF1.ParentStyleUsing.UseBackColor = false;
            this.REF1.ParentStyleUsing.UseBorderColor = false;
            this.REF1.ParentStyleUsing.UseBorders = false;
            this.REF1.ParentStyleUsing.UseBorderWidth = false;
            this.REF1.ParentStyleUsing.UseFont = false;
            this.REF1.ParentStyleUsing.UseForeColor = false;
            this.REF1.Size = new System.Drawing.Size(74, 9);
            // 
            // ReportFooter
            // 
            this.ReportFooter.Height = 0;
            this.ReportFooter.Name = "ReportFooter";
            // 
            // PageFooter
            // 
            this.PageFooter.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.pageend1});
            this.PageFooter.Height = 27;
            this.PageFooter.Name = "PageFooter";
            // 
            // pageend1
            // 
            this.pageend1.BackColor = System.Drawing.Color.White;
            this.pageend1.BorderColor = System.Drawing.Color.Black;
            this.pageend1.CanGrow = false;
            this.pageend1.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.pageend1.ForeColor = System.Drawing.Color.Black;
            this.pageend1.Location = new System.Drawing.Point(0, 15);
            this.pageend1.Name = "pageend1";
            this.pageend1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.pageend1.ParentStyleUsing.UseBackColor = false;
            this.pageend1.ParentStyleUsing.UseBorderColor = false;
            this.pageend1.ParentStyleUsing.UseBorders = false;
            this.pageend1.ParentStyleUsing.UseBorderWidth = false;
            this.pageend1.ParentStyleUsing.UseFont = false;
            this.pageend1.ParentStyleUsing.UseForeColor = false;
            this.pageend1.Size = new System.Drawing.Size(299, 12);
            this.pageend1.Text = "Untranslated";
            // 
            // Journal
            // 
            this.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.Detail,
            this.GroupHeader1,
            this.GroupFooter1,
            this.ReportHeader,
            this.PageHeader,
            this.ReportFooter,
            this.PageFooter});
            this.DataAdapter = this.oleDbDataAdapter1;
            this.Margins = new System.Drawing.Printing.Margins(25, 25, 25, 0);
            this.PageHeight = 1169;
            this.PageWidth = 826;
            this.PaperKind = System.Drawing.Printing.PaperKind.Custom;
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();

        }

        #endregion

        private DevExpress.XtraReports.UI.DetailBand Detail;
        private DevExpress.XtraReports.UI.XRLabel REF1;
        private DevExpress.XtraReports.UI.XRLabel QTYOUT1;
        private DevExpress.XtraReports.UI.XRLabel Avrcost1;
        private DevExpress.XtraReports.UI.XRLabel FTShop1;
        private DevExpress.XtraReports.UI.XRLabel Trnno1;
        private DevExpress.XtraReports.UI.XRLabel Remarks1;
        private DevExpress.XtraReports.UI.XRLabel SuppNum1;
        private DevExpress.XtraReports.UI.XRLabel Shop1;
        private DevExpress.XtraReports.UI.XRLabel Amount1;
        private DevExpress.XtraReports.UI.XRLabel Dateregd1;
        private DevExpress.XtraReports.UI.XRLabel QTYIN1;
        private DevExpress.XtraReports.UI.XRLabel type1;
        private System.Data.OleDb.OleDbDataAdapter oleDbDataAdapter1;
        private System.Data.OleDb.OleDbCommand oleDbCommand1;
        private System.Data.OleDb.OleDbConnection oleDbConnection1;
        private DevExpress.XtraReports.UI.GroupHeaderBand GroupHeader1;
        private DevExpress.XtraReports.UI.XRLine Line1;
        private DevExpress.XtraReports.UI.XRLabel Text21;
        private DevExpress.XtraReports.UI.XRLabel Class61;
        private DevExpress.XtraReports.UI.XRLabel Class51;
        private DevExpress.XtraReports.UI.XRLabel Class41;
        private DevExpress.XtraReports.UI.XRLabel Class31;
        private DevExpress.XtraReports.UI.XRLabel Class21;
        private DevExpress.XtraReports.UI.XRLabel Class11;
        private DevExpress.XtraReports.UI.XRLabel Appendix31;
        private DevExpress.XtraReports.UI.XRLabel Appendix21;
        private DevExpress.XtraReports.UI.XRLabel Appendix11;
        private DevExpress.XtraReports.UI.XRLabel StkCode1;
        private DevExpress.XtraReports.UI.XRLabel hdrClass61;
        private DevExpress.XtraReports.UI.XRLabel hdrClass51;
        private DevExpress.XtraReports.UI.XRLabel hdrClass41;
        private DevExpress.XtraReports.UI.XRLabel hdrClass31;
        private DevExpress.XtraReports.UI.XRLabel hdrClass21;
        private DevExpress.XtraReports.UI.XRLabel hdrClass11;
        private DevExpress.XtraReports.UI.XRLabel hdrAppendix31;
        private DevExpress.XtraReports.UI.XRLabel hdrAppendix21;
        private DevExpress.XtraReports.UI.XRLabel hdrAppendix11;
        private DevExpress.XtraReports.UI.XRLabel hdrStock1;
        private DevExpress.XtraReports.UI.XRLabel Text20;
        private DevExpress.XtraReports.UI.XRLabel Text19;
        private DevExpress.XtraReports.UI.XRLabel Text18;
        private DevExpress.XtraReports.UI.XRLabel Text17;
        private DevExpress.XtraReports.UI.XRLabel Text16;
        private DevExpress.XtraReports.UI.XRLabel Text15;
        private DevExpress.XtraReports.UI.XRLabel Text14;
        private DevExpress.XtraReports.UI.XRLabel Text13;
        private DevExpress.XtraReports.UI.XRLabel Text12;
        private DevExpress.XtraReports.UI.XRLabel Text11;
        private DevExpress.XtraReports.UI.XRLabel Text10;
        private DevExpress.XtraReports.UI.XRLabel Text9;
        private DevExpress.XtraReports.UI.XRLabel stockcode1;
        private DevExpress.XtraReports.UI.GroupFooterBand GroupFooter1;
        private DevExpress.XtraReports.UI.XRLabel CDQTY1;
        private DevExpress.XtraReports.UI.XRLabel BFAMT1;
        private DevExpress.XtraReports.UI.XRLabel BFQTY1;
        private DevExpress.XtraReports.UI.XRLabel Text26;
        private DevExpress.XtraReports.UI.XRLine Line2;
        private DevExpress.XtraReports.UI.XRLabel Text25;
        private DevExpress.XtraReports.UI.XRLabel SumofQTYOUT1;
        private DevExpress.XtraReports.UI.XRLabel cdamt1;
        private DevExpress.XtraReports.UI.XRLabel SumofQTYIN1;
        private DevExpress.XtraReports.UI.XRLabel Text24;
        private DevExpress.XtraReports.UI.XRLabel Text23;
        private DevExpress.XtraReports.UI.XRLabel Text22;
        private DevExpress.XtraReports.UI.ReportHeaderBand ReportHeader;
        private DevExpress.XtraReports.UI.PageHeaderBand PageHeader;
        private DevExpress.XtraReports.UI.XRLabel hdrCompName1;
        private DevExpress.XtraReports.UI.XRLabel hdrCurrent1;
        private DevExpress.XtraReports.UI.XRLabel TotalPageCount1;
        private DevExpress.XtraReports.UI.XRLabel Text8;
        private DevExpress.XtraReports.UI.XRLabel PrintTime1;
        private DevExpress.XtraReports.UI.XRLabel hdrfrdate1;
        private DevExpress.XtraReports.UI.XRLabel Text7;
        private DevExpress.XtraReports.UI.XRLabel Text6;
        private DevExpress.XtraReports.UI.XRLabel hdrtodate1;
        private DevExpress.XtraReports.UI.XRPageInfo PageNumber1;
        private DevExpress.XtraReports.UI.XRLabel Text5;
        private DevExpress.XtraReports.UI.XRLabel hdrfmstk1;
        private DevExpress.XtraReports.UI.XRLabel Text4;
        private DevExpress.XtraReports.UI.XRLabel Text3;
        private DevExpress.XtraReports.UI.XRLabel hdrtostk1;
        private DevExpress.XtraReports.UI.XRLabel Text2;
        private DevExpress.XtraReports.UI.XRLabel PrintDate1;
        private DevExpress.XtraReports.UI.XRLabel Text1;
        private DevExpress.XtraReports.UI.ReportFooterBand ReportFooter;
        private DevExpress.XtraReports.UI.PageFooterBand PageFooter;
        private DevExpress.XtraReports.UI.XRLabel pageend1;

    }
}
