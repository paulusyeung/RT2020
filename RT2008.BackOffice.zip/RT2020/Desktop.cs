﻿#region Using

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;

using Gizmox.WebGUI.Forms;
using Gizmox.WebGUI.Common.Resources;
using Gizmox.WebGUI.Common.Interfaces;
using System.Diagnostics;
using System.Reflection;
using RT2008.Controls;

#endregion

namespace RT2008
{
    public partial class Desktop : Form
    {
        private enum AtsStyle { Inventory, Purchasing, MemberMgmt, PriceMgmt, Settings };

        public Desktop()
        {
            InitializeComponent();

            SetTheme();
            SetAttributes();
            SetNavPanes();
            SetAppToolStrip(AtsStyle.Inventory);

            SetCloseButton();
        }

        private void SetAttributes()
        {
            amsFile.Text = RT2008.Controls.Utility.Dictionary.GetWord("file_main_menu");
            amsView.Text = RT2008.Controls.Utility.Dictionary.GetWord("view_main_menu");
            amsViewChs.Text = RT2008.Controls.Utility.Dictionary.GetWord("chs_main_menu");
            amsViewCht.Text = RT2008.Controls.Utility.Dictionary.GetWord("cht_main_menu");
            amsHelp.Text = RT2008.Controls.Utility.Dictionary.GetWord("help_main_menu");
            amsFileExit.Text = RT2008.Controls.Utility.Dictionary.GetWord("exit_main_menu");
            amsHelpAbout.Text = RT2008.Controls.Utility.Dictionary.GetWord("about_main_menu");
        }

        private void SetTheme()
        {
            ImageResourceHandle bgImage = new ImageResourceHandle("RT2008.jpg");

            //this.picBgImage.Image = bgImage;
            this.picBgImage.Dock = DockStyle.Fill;
            this.picBgImage.BackgroundImage = bgImage;
            this.picBgImage.BackgroundImageLayout = ImageLayout.Center;

            /**
             * 2020.03.20 paulus: 根據個 theme 改個 background color
             */
            Context.CurrentTheme = RT2008.Controls.Utility.Default.CurrentTheme;
            wspPane.BackColor = RT2008.Controls.Utility.Default.TopPanelBackgroundColor;
        }

        private void SetAppToolStrip(AtsStyle index)
        {
            this.atsPane.Controls.Clear();

            switch (index)
            {
                case AtsStyle.Inventory:
                    RT2008.AtsPane.InventoryAts oAtsInvt = new RT2008.AtsPane.InventoryAts();
                    oAtsInvt.Dock = DockStyle.Fill;
                    this.atsPane.Controls.Add(oAtsInvt);
                    navTabs.SelectedIndex = 0;
                    break;
                case AtsStyle.Purchasing:
                    RT2008.AtsPane.PurchasingAts oAtsPurchasing = new RT2008.AtsPane.PurchasingAts();
                    oAtsPurchasing.Dock = DockStyle.Fill;
                    this.atsPane.Controls.Add(oAtsPurchasing);
                    navTabs.SelectedIndex = 1;
                    break;
                case AtsStyle.MemberMgmt:
                    RT2008.AtsPane.MemberMgmtAts oAtsMemberMgmt = new RT2008.AtsPane.MemberMgmtAts();
                    oAtsMemberMgmt.Dock = DockStyle.Fill;
                    this.atsPane.Controls.Add(oAtsMemberMgmt);
                    navTabs.SelectedIndex = 2;
                    break;
                case AtsStyle.Settings:
                    RT2008.AtsPane.SettingsAts oAtsSettings = new RT2008.AtsPane.SettingsAts();
                    oAtsSettings.Dock = DockStyle.Fill;
                    this.atsPane.Controls.Add(oAtsSettings);
                    navTabs.SelectedIndex = 4;
                    break;
            }
        }

        private void SetNavPanes()
        {
            RT2008.NavPane.NavMenu.FillNavPane(ref this.navTabs);

            //RT2008.NavPane.InventoryNav navInvt = new RT2008.NavPane.InventoryNav();
            //navInvt.Dock = DockStyle.Fill;
            //tabInvt.Controls.Add(navInvt);

            //RT2008.NavPane.PurchasingNav navPurchasing = new RT2008.NavPane.PurchasingNav();
            //navPurchasing.Dock = DockStyle.Fill;
            //tabPurchasing.Controls.Add(navPurchasing);

            //RT2008.NavPane.MemberMgmtNav navMemberMgmt = new RT2008.NavPane.MemberMgmtNav();
            //navMemberMgmt.Dock = DockStyle.Fill;
            //tabMemberMgmt.Controls.Add(navMemberMgmt);

            //RT2008.NavPane.SettingsNav navSettings = new RT2008.NavPane.SettingsNav();
            //navSettings.Dock = DockStyle.Fill;
            //tabSettings.Controls.Add(navSettings);
        }

        #region Close Button
        private void SetCloseButton()
        {
            Button cmdClose = new Button();
            cmdClose.Name = "cmdClose";
            cmdClose.Location = new System.Drawing.Point(this.Width - 43, 3);
            cmdClose.Size = new System.Drawing.Size(38, 38);
            cmdClose.Image = new IconResourceHandle("32x32.shutdown32.png");
            cmdClose.ImageAlign = ContentAlignment.MiddleCenter;
            cmdClose.TextImageRelation = Gizmox.WebGUI.Forms.TextImageRelation.ImageAboveText;
            cmdClose.Anchor = ((Gizmox.WebGUI.Forms.AnchorStyles)((Gizmox.WebGUI.Forms.AnchorStyles.Top | Gizmox.WebGUI.Forms.AnchorStyles.Right)));

            cmdClose.Click += new System.EventHandler(this.cmdClose_Click);
            this.Controls.Add(cmdClose);
        }

        private void cmdClose_Click(object sender, EventArgs e)
        {
            Shutdown();
        }

        private void Shutdown()
        {
            DAL.Common.Config.CurrentUserId = System.Guid.Empty;

            RT2008.Controls.Log4net.LogInfo(RT2008.Controls.Log4net.LogAction.Logout, this.ToString());

            // set the IsLoggedOn to false will redirect to Logon Page.
            this.Context.Session.IsLoggedOn = false;
            VWGContext.Current.HttpContext.Session.Abandon();
            VWGContext.Current.Transfer(new Desktop());
        }
        #endregion

        private void amsMain_MenuClick(object objSource, MenuItemEventArgs objArgs)
        {
            MenuItemEventArgs oArg = (MenuItemEventArgs)objArgs;
            string strAction = oArg.MenuItem.Tag as string;
            if (strAction != null)
            {
                switch (strAction)
                {
                    case "amsFileExit":
                        //RT2008.DAL.Common.Config.CurrentUserId = System.Guid.Empty;
                        // While setting the IsLoggedOn to false, will redirect to Logon Page.
                        //this.Context.Session.IsLoggedOn = false;
                        // VWGContext.Current.HttpContext.Session.Abandon();
                        //Context.Redirect("Desktop.wgx");
                        Shutdown();
                        break;
                    case "Print":
//                        MessageBox.Show(((Gizmox.WebGUI.Common.Interfaces.ISessionRegistry)this.Context.Session).Count.ToString());
                        break;
                    case "amsViewEn": // English
                        //VWGContext.Current.CurrentUICulture = new System.Globalization.CultureInfo("en-US");
                        System.Web.HttpContext.Current.Session["UserLanguage"] = "en-US";
                        Context.Redirect("Desktop.wgx");
                        break;
                    case "amsViewChs": // Simplified Chinese
                        //VWGContext.Current.CurrentUICulture = new System.Globalization.CultureInfo("zh-CHS");
                        System.Web.HttpContext.Current.Session["UserLanguage"] = "zh-CHS";
                        Context.Redirect("Desktop.wgx");
                        break;
                    case "amsViewCht": // Tradictional Chinese
                        //VWGContext.Current.CurrentUICulture = new System.Globalization.CultureInfo("zh-CHT");
                        System.Web.HttpContext.Current.Session["UserLanguage"] = "zh-CHT";
                        Context.Redirect("Desktop.wgx");
                        break;
                    case "amsViewWinXP":
                        this.Context.CurrentTheme = "iOS";          // Theme.Default;
                        break;
                    case "amsViewVista":
                        this.Context.CurrentTheme = "Vista";        // new Theme("Vista");
                        break;
                    case "amsViewBlack":
                        this.Context.CurrentTheme = "Graphite";     // new Theme("Black");
                        break;
                    case "amsHelpAbout":
                        Help.About oAbout = new RT2008.Help.About();
                        oAbout.ShowDialog();
                        break;
                    default:
//                        MessageBox.Show(strAction);
                        break;
                }
            }
        }

        #region Deselect selected TreeNodes on switching navTabs
        private void DeSelectTreeNodes()
        {
            Control[] invt = this.Form.Controls.Find("navInvt", true);
            if (invt.Length > 0)
            {
                TreeView tvInvt = (TreeView)invt[0];
                tvInvt.SelectedNode = null;
            }
            Control[] purchase = this.Form.Controls.Find("navPurchasing", true);
            if (purchase.Length > 0)
            {
                TreeView tvInvt = (TreeView)purchase[0];
                tvInvt.SelectedNode = null;
            }
            Control[] mbrMgmt = this.Form.Controls.Find("navMemberMgmt", true);
            if (mbrMgmt.Length > 0)
            {
                TreeView tvInvt = (TreeView)mbrMgmt[0];
                tvInvt.SelectedNode = null;
            }
            Control[] prcMgmt = this.Form.Controls.Find("navPriceMgmt", true);
            if (prcMgmt.Length > 0)
            {
                TreeView tvInvt = (TreeView)prcMgmt[0];
                tvInvt.SelectedNode = null;
            }
            Control[] settings = this.Form.Controls.Find("navSettings", true);
            if (settings.Length > 0)
            {
                TreeView tvInvt = (TreeView)settings[0];
                tvInvt.SelectedNode = null;
            }
        }
        #endregion

        private void navTabs_SelectedIndexChanged(object sender, EventArgs e)
        {
            DeSelectTreeNodes();

            if (navTabs.SelectedItem != null)
            {
                if (navTabs.SelectedItem.Tag != null)
                {
                    switch (navTabs.SelectedItem.Tag.ToString().ToLower())
                    {
                        case "inventory":
                            SetAppToolStrip(AtsStyle.Inventory);
                            break;
                        case "purchasing":
                            SetAppToolStrip(AtsStyle.Purchasing);
                            break;
                        case "member":
                            SetAppToolStrip(AtsStyle.MemberMgmt);
                            break;
                        case "settings":
                            SetAppToolStrip(AtsStyle.Settings);
                            break;
                    }
                }
            }
        }
    }
}