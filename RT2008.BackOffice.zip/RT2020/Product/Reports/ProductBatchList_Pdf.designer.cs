namespace RT2008.Product.Reports
{
    partial class ProductBatchList_Pdf
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DevExpress.XtraReports.UI.XRSummary xrSummary1 = new DevExpress.XtraReports.UI.XRSummary();
            DevExpress.XtraReports.UI.XRSummary xrSummary2 = new DevExpress.XtraReports.UI.XRSummary();
            DevExpress.XtraReports.UI.XRSummary xrSummary3 = new DevExpress.XtraReports.UI.XRSummary();
            DevExpress.XtraReports.UI.XRSummary xrSummary4 = new DevExpress.XtraReports.UI.XRSummary();
            DevExpress.XtraReports.UI.XRSummary xrSummary5 = new DevExpress.XtraReports.UI.XRSummary();
            DevExpress.XtraReports.UI.XRSummary xrSummary6 = new DevExpress.XtraReports.UI.XRSummary();
            DevExpress.XtraReports.UI.XRSummary xrSummary7 = new DevExpress.XtraReports.UI.XRSummary();
            DevExpress.XtraReports.UI.XRSummary xrSummary8 = new DevExpress.XtraReports.UI.XRSummary();
            this.Detail = new DevExpress.XtraReports.UI.DetailBand();
            this.lbl4 = new DevExpress.XtraReports.UI.XRLabel();
            this.txtORIPRC = new DevExpress.XtraReports.UI.XRLabel();
            this.lblOPrc = new DevExpress.XtraReports.UI.XRLabel();
            this.lbl1 = new DevExpress.XtraReports.UI.XRLabel();
            this.txtBASPRC = new DevExpress.XtraReports.UI.XRLabel();
            this.lblRPrc = new DevExpress.XtraReports.UI.XRLabel();
            this.lbl5 = new DevExpress.XtraReports.UI.XRLabel();
            this.lbl3 = new DevExpress.XtraReports.UI.XRLabel();
            this.lbl2 = new DevExpress.XtraReports.UI.XRLabel();
            this.txtSTATUS = new DevExpress.XtraReports.UI.XRLabel();
            this.txtVPRC = new DevExpress.XtraReports.UI.XRLabel();
            this.txtVCURR = new DevExpress.XtraReports.UI.XRLabel();
            this.txtWHLPRC = new DevExpress.XtraReports.UI.XRLabel();
            this.lblStatus = new DevExpress.XtraReports.UI.XRLabel();
            this.lblWPrc = new DevExpress.XtraReports.UI.XRLabel();
            this.lblVPrc = new DevExpress.XtraReports.UI.XRLabel();
            this.txtDATECREATE = new DevExpress.XtraReports.UI.XRLabel();
            this.txtMAINUNIT = new DevExpress.XtraReports.UI.XRLabel();
            this.txtCLASS6 = new DevExpress.XtraReports.UI.XRLabel();
            this.txtCLASS5 = new DevExpress.XtraReports.UI.XRLabel();
            this.txtCLASS4 = new DevExpress.XtraReports.UI.XRLabel();
            this.txtCLASS3 = new DevExpress.XtraReports.UI.XRLabel();
            this.txtCLASS2 = new DevExpress.XtraReports.UI.XRLabel();
            this.txtCLASS1 = new DevExpress.XtraReports.UI.XRLabel();
            this.txtDESC = new DevExpress.XtraReports.UI.XRLabel();
            this.txtAPP3_COMBIN = new DevExpress.XtraReports.UI.XRLabel();
            this.txtAPP2_COMBIN = new DevExpress.XtraReports.UI.XRLabel();
            this.txtAPP1_COMBIN = new DevExpress.XtraReports.UI.XRLabel();
            this.txtSTKCODE = new DevExpress.XtraReports.UI.XRLabel();
            this.txtStatusDesc = new DevExpress.XtraReports.UI.XRLabel();
            this.PageHeader = new DevExpress.XtraReports.UI.PageHeaderBand();
            this.Line1 = new DevExpress.XtraReports.UI.XRLine();
            this.lblDesc = new DevExpress.XtraReports.UI.XRLabel();
            this.lblUnit = new DevExpress.XtraReports.UI.XRLabel();
            this.lblCompName = new DevExpress.XtraReports.UI.XRLabel();
            this.lblDC = new DevExpress.XtraReports.UI.XRLabel();
            this.lblA3_CT = new DevExpress.XtraReports.UI.XRLabel();
            this.lblA2_CT = new DevExpress.XtraReports.UI.XRLabel();
            this.lblA1_CT = new DevExpress.XtraReports.UI.XRLabel();
            this.lblC6 = new DevExpress.XtraReports.UI.XRLabel();
            this.lblC5 = new DevExpress.XtraReports.UI.XRLabel();
            this.lblC4 = new DevExpress.XtraReports.UI.XRLabel();
            this.lblC3 = new DevExpress.XtraReports.UI.XRLabel();
            this.lblC2 = new DevExpress.XtraReports.UI.XRLabel();
            this.lblC1 = new DevExpress.XtraReports.UI.XRLabel();
            this.lblA3 = new DevExpress.XtraReports.UI.XRLabel();
            this.lblA2 = new DevExpress.XtraReports.UI.XRLabel();
            this.lblA1 = new DevExpress.XtraReports.UI.XRLabel();
            this.txtPages = new DevExpress.XtraReports.UI.XRLabel();
            this.txtPage = new DevExpress.XtraReports.UI.XRLabel();
            this.lblOf = new DevExpress.XtraReports.UI.XRLabel();
            this.lblPage = new DevExpress.XtraReports.UI.XRLabel();
            this.txtPrint = new DevExpress.XtraReports.UI.XRLabel();
            this.lblPrint = new DevExpress.XtraReports.UI.XRLabel();
            this.lblCaption = new DevExpress.XtraReports.UI.XRLabel();
            this.lblSTK = new DevExpress.XtraReports.UI.XRLabel();
            this.ghSTK = new DevExpress.XtraReports.UI.GroupHeaderBand();
            this.gfSTK = new DevExpress.XtraReports.UI.GroupFooterBand();
            this.PageFooter = new DevExpress.XtraReports.UI.PageFooterBand();
            this.lblClass6 = new DevExpress.XtraReports.UI.XRLabel();
            this.lblClass5 = new DevExpress.XtraReports.UI.XRLabel();
            this.lblClass4 = new DevExpress.XtraReports.UI.XRLabel();
            this.lblClass3 = new DevExpress.XtraReports.UI.XRLabel();
            this.lblClass2 = new DevExpress.XtraReports.UI.XRLabel();
            this.lblClass1 = new DevExpress.XtraReports.UI.XRLabel();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            // 
            // Detail
            // 
            this.Detail.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.lbl4,
            this.txtORIPRC,
            this.lblOPrc,
            this.lbl1,
            this.txtBASPRC,
            this.lblRPrc,
            this.lbl5,
            this.lbl3,
            this.lbl2,
            this.txtSTATUS,
            this.txtVPRC,
            this.txtVCURR,
            this.txtWHLPRC,
            this.lblStatus,
            this.lblWPrc,
            this.lblVPrc,
            this.txtDATECREATE,
            this.txtMAINUNIT,
            this.txtCLASS6,
            this.txtCLASS5,
            this.txtCLASS4,
            this.txtCLASS3,
            this.txtCLASS2,
            this.txtCLASS1,
            this.txtDESC,
            this.txtAPP3_COMBIN,
            this.txtAPP2_COMBIN,
            this.txtAPP1_COMBIN,
            this.txtSTKCODE,
            this.txtStatusDesc});
            this.Detail.Height = 35;
            this.Detail.MultiColumn.Mode = DevExpress.XtraReports.UI.MultiColumnMode.UseColumnCount;
            this.Detail.Name = "Detail";
            this.Detail.ParentStyleUsing.UseBackColor = false;
            this.Detail.ParentStyleUsing.UseBorderColor = false;
            this.Detail.ParentStyleUsing.UseBorders = false;
            this.Detail.ParentStyleUsing.UseBorderWidth = false;
            this.Detail.ParentStyleUsing.UseFont = false;
            this.Detail.ParentStyleUsing.UseForeColor = false;
            // 
            // lbl4
            // 
            this.lbl4.CanGrow = false;
            this.lbl4.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbl4.Location = new System.Drawing.Point(556, 12);
            this.lbl4.Name = "lbl4";
            this.lbl4.NavigateUrl = null;
            this.lbl4.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.lbl4.ParentStyleUsing.UseBackColor = false;
            this.lbl4.ParentStyleUsing.UseBorderColor = false;
            this.lbl4.ParentStyleUsing.UseBorders = false;
            this.lbl4.ParentStyleUsing.UseBorderWidth = false;
            this.lbl4.ParentStyleUsing.UseFont = false;
            this.lbl4.ParentStyleUsing.UseForeColor = false;
            this.lbl4.Size = new System.Drawing.Size(8, 19);
            this.lbl4.Tag = null;
            this.lbl4.Text = ":";
            this.lbl4.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter;
            // 
            // txtORIPRC
            // 
            this.txtORIPRC.CanGrow = false;
            this.txtORIPRC.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "ORIPRC", "{0:n2}")});
            this.txtORIPRC.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtORIPRC.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txtORIPRC.Location = new System.Drawing.Point(565, 12);
            this.txtORIPRC.Name = "txtORIPRC";
            this.txtORIPRC.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.txtORIPRC.ParentStyleUsing.UseBackColor = false;
            this.txtORIPRC.ParentStyleUsing.UseBorderColor = false;
            this.txtORIPRC.ParentStyleUsing.UseBorders = false;
            this.txtORIPRC.ParentStyleUsing.UseBorderWidth = false;
            this.txtORIPRC.ParentStyleUsing.UseFont = false;
            this.txtORIPRC.ParentStyleUsing.UseForeColor = false;
            this.txtORIPRC.Size = new System.Drawing.Size(80, 19);
            xrSummary1.FormatString = "{0:$#,##0.00}";
            this.txtORIPRC.Summary = xrSummary1;
            this.txtORIPRC.Tag = null;
            this.txtORIPRC.Text = "txtORIPRC";
            // 
            // lblOPrc
            // 
            this.lblOPrc.CanGrow = false;
            this.lblOPrc.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblOPrc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblOPrc.Location = new System.Drawing.Point(490, 12);
            this.lblOPrc.Name = "lblOPrc";
            this.lblOPrc.NavigateUrl = null;
            this.lblOPrc.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.lblOPrc.ParentStyleUsing.UseBackColor = false;
            this.lblOPrc.ParentStyleUsing.UseBorderColor = false;
            this.lblOPrc.ParentStyleUsing.UseBorders = false;
            this.lblOPrc.ParentStyleUsing.UseBorderWidth = false;
            this.lblOPrc.ParentStyleUsing.UseFont = false;
            this.lblOPrc.ParentStyleUsing.UseForeColor = false;
            this.lblOPrc.Size = new System.Drawing.Size(67, 19);
            this.lblOPrc.Tag = null;
            this.lblOPrc.Text = "Original Price";
            this.lblOPrc.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopRight;
            // 
            // lbl1
            // 
            this.lbl1.CanGrow = false;
            this.lbl1.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbl1.Location = new System.Drawing.Point(56, 12);
            this.lbl1.Name = "lbl1";
            this.lbl1.NavigateUrl = null;
            this.lbl1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.lbl1.ParentStyleUsing.UseBackColor = false;
            this.lbl1.ParentStyleUsing.UseBorderColor = false;
            this.lbl1.ParentStyleUsing.UseBorders = false;
            this.lbl1.ParentStyleUsing.UseBorderWidth = false;
            this.lbl1.ParentStyleUsing.UseFont = false;
            this.lbl1.ParentStyleUsing.UseForeColor = false;
            this.lbl1.Size = new System.Drawing.Size(8, 19);
            this.lbl1.Tag = null;
            this.lbl1.Text = ":";
            this.lbl1.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter;
            // 
            // txtBASPRC
            // 
            this.txtBASPRC.CanGrow = false;
            this.txtBASPRC.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "BASPRC", "{0:n2}")});
            this.txtBASPRC.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtBASPRC.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txtBASPRC.Location = new System.Drawing.Point(62, 12);
            this.txtBASPRC.Name = "txtBASPRC";
            this.txtBASPRC.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.txtBASPRC.ParentStyleUsing.UseBackColor = false;
            this.txtBASPRC.ParentStyleUsing.UseBorderColor = false;
            this.txtBASPRC.ParentStyleUsing.UseBorders = false;
            this.txtBASPRC.ParentStyleUsing.UseBorderWidth = false;
            this.txtBASPRC.ParentStyleUsing.UseFont = false;
            this.txtBASPRC.ParentStyleUsing.UseForeColor = false;
            this.txtBASPRC.Size = new System.Drawing.Size(80, 19);
            xrSummary2.FormatString = "{0:$#,##0.00}";
            this.txtBASPRC.Summary = xrSummary2;
            this.txtBASPRC.Tag = null;
            this.txtBASPRC.Text = "txtBASPRC";
            // 
            // lblRPrc
            // 
            this.lblRPrc.CanGrow = false;
            this.lblRPrc.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblRPrc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblRPrc.Location = new System.Drawing.Point(0, 12);
            this.lblRPrc.Name = "lblRPrc";
            this.lblRPrc.NavigateUrl = null;
            this.lblRPrc.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.lblRPrc.ParentStyleUsing.UseBackColor = false;
            this.lblRPrc.ParentStyleUsing.UseBorderColor = false;
            this.lblRPrc.ParentStyleUsing.UseBorders = false;
            this.lblRPrc.ParentStyleUsing.UseBorderWidth = false;
            this.lblRPrc.ParentStyleUsing.UseFont = false;
            this.lblRPrc.ParentStyleUsing.UseForeColor = false;
            this.lblRPrc.Size = new System.Drawing.Size(57, 19);
            this.lblRPrc.Tag = null;
            this.lblRPrc.Text = "Retail Price";
            this.lblRPrc.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopRight;
            // 
            // lbl5
            // 
            this.lbl5.CanGrow = false;
            this.lbl5.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbl5.Location = new System.Drawing.Point(673, 12);
            this.lbl5.Name = "lbl5";
            this.lbl5.NavigateUrl = null;
            this.lbl5.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.lbl5.ParentStyleUsing.UseBackColor = false;
            this.lbl5.ParentStyleUsing.UseBorderColor = false;
            this.lbl5.ParentStyleUsing.UseBorders = false;
            this.lbl5.ParentStyleUsing.UseBorderWidth = false;
            this.lbl5.ParentStyleUsing.UseFont = false;
            this.lbl5.ParentStyleUsing.UseForeColor = false;
            this.lbl5.Size = new System.Drawing.Size(12, 19);
            this.lbl5.Tag = null;
            this.lbl5.Text = ":";
            // 
            // lbl3
            // 
            this.lbl3.CanGrow = false;
            this.lbl3.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbl3.Location = new System.Drawing.Point(373, 12);
            this.lbl3.Name = "lbl3";
            this.lbl3.NavigateUrl = null;
            this.lbl3.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.lbl3.ParentStyleUsing.UseBackColor = false;
            this.lbl3.ParentStyleUsing.UseBorderColor = false;
            this.lbl3.ParentStyleUsing.UseBorders = false;
            this.lbl3.ParentStyleUsing.UseBorderWidth = false;
            this.lbl3.ParentStyleUsing.UseFont = false;
            this.lbl3.ParentStyleUsing.UseForeColor = false;
            this.lbl3.Size = new System.Drawing.Size(8, 19);
            this.lbl3.Tag = null;
            this.lbl3.Text = ":";
            this.lbl3.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter;
            // 
            // lbl2
            // 
            this.lbl2.CanGrow = false;
            this.lbl2.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbl2.Location = new System.Drawing.Point(223, 12);
            this.lbl2.Name = "lbl2";
            this.lbl2.NavigateUrl = null;
            this.lbl2.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.lbl2.ParentStyleUsing.UseBackColor = false;
            this.lbl2.ParentStyleUsing.UseBorderColor = false;
            this.lbl2.ParentStyleUsing.UseBorders = false;
            this.lbl2.ParentStyleUsing.UseBorderWidth = false;
            this.lbl2.ParentStyleUsing.UseFont = false;
            this.lbl2.ParentStyleUsing.UseForeColor = false;
            this.lbl2.Size = new System.Drawing.Size(8, 19);
            this.lbl2.Tag = null;
            this.lbl2.Text = ":";
            this.lbl2.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter;
            // 
            // txtSTATUS
            // 
            this.txtSTATUS.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "STATUS", "")});
            this.txtSTATUS.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtSTATUS.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txtSTATUS.Location = new System.Drawing.Point(706, 12);
            this.txtSTATUS.Name = "txtSTATUS";
            this.txtSTATUS.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.txtSTATUS.ParentStyleUsing.UseBackColor = false;
            this.txtSTATUS.ParentStyleUsing.UseBorderColor = false;
            this.txtSTATUS.ParentStyleUsing.UseBorders = false;
            this.txtSTATUS.ParentStyleUsing.UseBorderWidth = false;
            this.txtSTATUS.ParentStyleUsing.UseFont = false;
            this.txtSTATUS.ParentStyleUsing.UseForeColor = false;
            this.txtSTATUS.Size = new System.Drawing.Size(19, 19);
            this.txtSTATUS.Tag = null;
            this.txtSTATUS.Visible = false;
            // 
            // txtVPRC
            // 
            this.txtVPRC.CanGrow = false;
            this.txtVPRC.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "VPRC", "{0:n2}")});
            this.txtVPRC.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtVPRC.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txtVPRC.Location = new System.Drawing.Point(410, 12);
            this.txtVPRC.Name = "txtVPRC";
            this.txtVPRC.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.txtVPRC.ParentStyleUsing.UseBackColor = false;
            this.txtVPRC.ParentStyleUsing.UseBorderColor = false;
            this.txtVPRC.ParentStyleUsing.UseBorders = false;
            this.txtVPRC.ParentStyleUsing.UseBorderWidth = false;
            this.txtVPRC.ParentStyleUsing.UseFont = false;
            this.txtVPRC.ParentStyleUsing.UseForeColor = false;
            this.txtVPRC.Size = new System.Drawing.Size(80, 19);
            xrSummary3.FormatString = "{0:$#,##0.00}";
            this.txtVPRC.Summary = xrSummary3;
            this.txtVPRC.Tag = null;
            this.txtVPRC.Text = "txtVPRC";
            // 
            // txtVCURR
            // 
            this.txtVCURR.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "VCURR", "")});
            this.txtVCURR.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtVCURR.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txtVCURR.Location = new System.Drawing.Point(379, 12);
            this.txtVCURR.Name = "txtVCURR";
            this.txtVCURR.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.txtVCURR.ParentStyleUsing.UseBackColor = false;
            this.txtVCURR.ParentStyleUsing.UseBorderColor = false;
            this.txtVCURR.ParentStyleUsing.UseBorders = false;
            this.txtVCURR.ParentStyleUsing.UseBorderWidth = false;
            this.txtVCURR.ParentStyleUsing.UseFont = false;
            this.txtVCURR.ParentStyleUsing.UseForeColor = false;
            this.txtVCURR.Size = new System.Drawing.Size(31, 19);
            this.txtVCURR.Tag = null;
            // 
            // txtWHLPRC
            // 
            this.txtWHLPRC.CanGrow = false;
            this.txtWHLPRC.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "WHLPRC", "{0:n2}")});
            this.txtWHLPRC.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtWHLPRC.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txtWHLPRC.Location = new System.Drawing.Point(231, 12);
            this.txtWHLPRC.Name = "txtWHLPRC";
            this.txtWHLPRC.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.txtWHLPRC.ParentStyleUsing.UseBackColor = false;
            this.txtWHLPRC.ParentStyleUsing.UseBorderColor = false;
            this.txtWHLPRC.ParentStyleUsing.UseBorders = false;
            this.txtWHLPRC.ParentStyleUsing.UseBorderWidth = false;
            this.txtWHLPRC.ParentStyleUsing.UseFont = false;
            this.txtWHLPRC.ParentStyleUsing.UseForeColor = false;
            this.txtWHLPRC.Size = new System.Drawing.Size(80, 19);
            xrSummary4.FormatString = "{0:$#,##0.00}";
            this.txtWHLPRC.Summary = xrSummary4;
            this.txtWHLPRC.Tag = null;
            this.txtWHLPRC.Text = "txtWHLPRC";
            // 
            // lblStatus
            // 
            this.lblStatus.CanGrow = false;
            this.lblStatus.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblStatus.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblStatus.Location = new System.Drawing.Point(624, 12);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.NavigateUrl = null;
            this.lblStatus.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.lblStatus.ParentStyleUsing.UseBackColor = false;
            this.lblStatus.ParentStyleUsing.UseBorderColor = false;
            this.lblStatus.ParentStyleUsing.UseBorders = false;
            this.lblStatus.ParentStyleUsing.UseBorderWidth = false;
            this.lblStatus.ParentStyleUsing.UseFont = false;
            this.lblStatus.ParentStyleUsing.UseForeColor = false;
            this.lblStatus.Size = new System.Drawing.Size(50, 19);
            this.lblStatus.Tag = null;
            this.lblStatus.Text = "Status";
            this.lblStatus.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopRight;
            // 
            // lblWPrc
            // 
            this.lblWPrc.CanGrow = false;
            this.lblWPrc.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblWPrc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblWPrc.Location = new System.Drawing.Point(142, 12);
            this.lblWPrc.Name = "lblWPrc";
            this.lblWPrc.NavigateUrl = null;
            this.lblWPrc.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.lblWPrc.ParentStyleUsing.UseBackColor = false;
            this.lblWPrc.ParentStyleUsing.UseBorderColor = false;
            this.lblWPrc.ParentStyleUsing.UseBorders = false;
            this.lblWPrc.ParentStyleUsing.UseBorderWidth = false;
            this.lblWPrc.ParentStyleUsing.UseFont = false;
            this.lblWPrc.ParentStyleUsing.UseForeColor = false;
            this.lblWPrc.Size = new System.Drawing.Size(81, 19);
            this.lblWPrc.Tag = null;
            this.lblWPrc.Text = "Wholesales Price";
            this.lblWPrc.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopRight;
            // 
            // lblVPrc
            // 
            this.lblVPrc.CanGrow = false;
            this.lblVPrc.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblVPrc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblVPrc.Location = new System.Drawing.Point(310, 12);
            this.lblVPrc.Name = "lblVPrc";
            this.lblVPrc.NavigateUrl = null;
            this.lblVPrc.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.lblVPrc.ParentStyleUsing.UseBackColor = false;
            this.lblVPrc.ParentStyleUsing.UseBorderColor = false;
            this.lblVPrc.ParentStyleUsing.UseBorders = false;
            this.lblVPrc.ParentStyleUsing.UseBorderWidth = false;
            this.lblVPrc.ParentStyleUsing.UseFont = false;
            this.lblVPrc.ParentStyleUsing.UseForeColor = false;
            this.lblVPrc.Size = new System.Drawing.Size(64, 19);
            this.lblVPrc.Tag = null;
            this.lblVPrc.Text = "Vendor Price";
            this.lblVPrc.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopRight;
            // 
            // txtDATECREATE
            // 
            this.txtDATECREATE.CanGrow = false;
            this.txtDATECREATE.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "DATECREATE", "")});
            this.txtDATECREATE.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtDATECREATE.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txtDATECREATE.Location = new System.Drawing.Point(673, 0);
            this.txtDATECREATE.Name = "txtDATECREATE";
            this.txtDATECREATE.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.txtDATECREATE.ParentStyleUsing.UseBackColor = false;
            this.txtDATECREATE.ParentStyleUsing.UseBorderColor = false;
            this.txtDATECREATE.ParentStyleUsing.UseBorders = false;
            this.txtDATECREATE.ParentStyleUsing.UseBorderWidth = false;
            this.txtDATECREATE.ParentStyleUsing.UseFont = false;
            this.txtDATECREATE.ParentStyleUsing.UseForeColor = false;
            this.txtDATECREATE.Size = new System.Drawing.Size(51, 19);
            xrSummary5.FormatString = "{0:dd/MM/yyyy}";
            this.txtDATECREATE.Summary = xrSummary5;
            this.txtDATECREATE.Tag = null;
            this.txtDATECREATE.Text = "30/12/1899";
            this.txtDATECREATE.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopRight;
            // 
            // txtMAINUNIT
            // 
            this.txtMAINUNIT.CanGrow = false;
            this.txtMAINUNIT.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "MAINUNIT", "")});
            this.txtMAINUNIT.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtMAINUNIT.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txtMAINUNIT.Location = new System.Drawing.Point(644, 0);
            this.txtMAINUNIT.Name = "txtMAINUNIT";
            this.txtMAINUNIT.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.txtMAINUNIT.ParentStyleUsing.UseBackColor = false;
            this.txtMAINUNIT.ParentStyleUsing.UseBorderColor = false;
            this.txtMAINUNIT.ParentStyleUsing.UseBorders = false;
            this.txtMAINUNIT.ParentStyleUsing.UseBorderWidth = false;
            this.txtMAINUNIT.ParentStyleUsing.UseFont = false;
            this.txtMAINUNIT.ParentStyleUsing.UseForeColor = false;
            this.txtMAINUNIT.Size = new System.Drawing.Size(31, 19);
            this.txtMAINUNIT.Tag = null;
            // 
            // txtCLASS6
            // 
            this.txtCLASS6.CanGrow = false;
            this.txtCLASS6.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "CLASS6", "")});
            this.txtCLASS6.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtCLASS6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txtCLASS6.Location = new System.Drawing.Point(456, 0);
            this.txtCLASS6.Name = "txtCLASS6";
            this.txtCLASS6.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.txtCLASS6.ParentStyleUsing.UseBackColor = false;
            this.txtCLASS6.ParentStyleUsing.UseBorderColor = false;
            this.txtCLASS6.ParentStyleUsing.UseBorders = false;
            this.txtCLASS6.ParentStyleUsing.UseBorderWidth = false;
            this.txtCLASS6.ParentStyleUsing.UseFont = false;
            this.txtCLASS6.ParentStyleUsing.UseForeColor = false;
            this.txtCLASS6.Size = new System.Drawing.Size(37, 19);
            this.txtCLASS6.Tag = null;
            // 
            // txtCLASS5
            // 
            this.txtCLASS5.CanGrow = false;
            this.txtCLASS5.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "CLASS5", "")});
            this.txtCLASS5.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtCLASS5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txtCLASS5.Location = new System.Drawing.Point(419, 0);
            this.txtCLASS5.Name = "txtCLASS5";
            this.txtCLASS5.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.txtCLASS5.ParentStyleUsing.UseBackColor = false;
            this.txtCLASS5.ParentStyleUsing.UseBorderColor = false;
            this.txtCLASS5.ParentStyleUsing.UseBorders = false;
            this.txtCLASS5.ParentStyleUsing.UseBorderWidth = false;
            this.txtCLASS5.ParentStyleUsing.UseFont = false;
            this.txtCLASS5.ParentStyleUsing.UseForeColor = false;
            this.txtCLASS5.Size = new System.Drawing.Size(37, 19);
            this.txtCLASS5.Tag = null;
            // 
            // txtCLASS4
            // 
            this.txtCLASS4.CanGrow = false;
            this.txtCLASS4.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "CLASS4", "")});
            this.txtCLASS4.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtCLASS4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txtCLASS4.Location = new System.Drawing.Point(381, 0);
            this.txtCLASS4.Name = "txtCLASS4";
            this.txtCLASS4.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.txtCLASS4.ParentStyleUsing.UseBackColor = false;
            this.txtCLASS4.ParentStyleUsing.UseBorderColor = false;
            this.txtCLASS4.ParentStyleUsing.UseBorders = false;
            this.txtCLASS4.ParentStyleUsing.UseBorderWidth = false;
            this.txtCLASS4.ParentStyleUsing.UseFont = false;
            this.txtCLASS4.ParentStyleUsing.UseForeColor = false;
            this.txtCLASS4.Size = new System.Drawing.Size(37, 19);
            this.txtCLASS4.Tag = null;
            // 
            // txtCLASS3
            // 
            this.txtCLASS3.CanGrow = false;
            this.txtCLASS3.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "CLASS3", "")});
            this.txtCLASS3.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtCLASS3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txtCLASS3.Location = new System.Drawing.Point(344, 0);
            this.txtCLASS3.Name = "txtCLASS3";
            this.txtCLASS3.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.txtCLASS3.ParentStyleUsing.UseBackColor = false;
            this.txtCLASS3.ParentStyleUsing.UseBorderColor = false;
            this.txtCLASS3.ParentStyleUsing.UseBorders = false;
            this.txtCLASS3.ParentStyleUsing.UseBorderWidth = false;
            this.txtCLASS3.ParentStyleUsing.UseFont = false;
            this.txtCLASS3.ParentStyleUsing.UseForeColor = false;
            this.txtCLASS3.Size = new System.Drawing.Size(37, 19);
            this.txtCLASS3.Tag = null;
            // 
            // txtCLASS2
            // 
            this.txtCLASS2.CanGrow = false;
            this.txtCLASS2.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "CLASS2", "")});
            this.txtCLASS2.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtCLASS2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txtCLASS2.Location = new System.Drawing.Point(306, 0);
            this.txtCLASS2.Name = "txtCLASS2";
            this.txtCLASS2.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.txtCLASS2.ParentStyleUsing.UseBackColor = false;
            this.txtCLASS2.ParentStyleUsing.UseBorderColor = false;
            this.txtCLASS2.ParentStyleUsing.UseBorders = false;
            this.txtCLASS2.ParentStyleUsing.UseBorderWidth = false;
            this.txtCLASS2.ParentStyleUsing.UseFont = false;
            this.txtCLASS2.ParentStyleUsing.UseForeColor = false;
            this.txtCLASS2.Size = new System.Drawing.Size(37, 19);
            this.txtCLASS2.Tag = null;
            // 
            // txtCLASS1
            // 
            this.txtCLASS1.CanGrow = false;
            this.txtCLASS1.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "CLASS1", "")});
            this.txtCLASS1.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtCLASS1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txtCLASS1.Location = new System.Drawing.Point(269, 0);
            this.txtCLASS1.Name = "txtCLASS1";
            this.txtCLASS1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.txtCLASS1.ParentStyleUsing.UseBackColor = false;
            this.txtCLASS1.ParentStyleUsing.UseBorderColor = false;
            this.txtCLASS1.ParentStyleUsing.UseBorders = false;
            this.txtCLASS1.ParentStyleUsing.UseBorderWidth = false;
            this.txtCLASS1.ParentStyleUsing.UseFont = false;
            this.txtCLASS1.ParentStyleUsing.UseForeColor = false;
            this.txtCLASS1.Size = new System.Drawing.Size(37, 19);
            this.txtCLASS1.Tag = null;
            // 
            // txtDESC
            // 
            this.txtDESC.CanGrow = false;
            this.txtDESC.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "DESC", "")});
            this.txtDESC.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtDESC.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txtDESC.Location = new System.Drawing.Point(492, 0);
            this.txtDESC.Name = "txtDESC";
            this.txtDESC.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.txtDESC.ParentStyleUsing.UseBackColor = false;
            this.txtDESC.ParentStyleUsing.UseBorderColor = false;
            this.txtDESC.ParentStyleUsing.UseBorders = false;
            this.txtDESC.ParentStyleUsing.UseBorderWidth = false;
            this.txtDESC.ParentStyleUsing.UseFont = false;
            this.txtDESC.ParentStyleUsing.UseForeColor = false;
            this.txtDESC.Size = new System.Drawing.Size(152, 19);
            this.txtDESC.Tag = null;
            this.txtDESC.WordWrap = false;
            // 
            // txtAPP3_COMBIN
            // 
            this.txtAPP3_COMBIN.CanGrow = false;
            this.txtAPP3_COMBIN.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "APP3_COMBIN", "")});
            this.txtAPP3_COMBIN.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtAPP3_COMBIN.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txtAPP3_COMBIN.Location = new System.Drawing.Point(204, 0);
            this.txtAPP3_COMBIN.Name = "txtAPP3_COMBIN";
            this.txtAPP3_COMBIN.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.txtAPP3_COMBIN.ParentStyleUsing.UseBackColor = false;
            this.txtAPP3_COMBIN.ParentStyleUsing.UseBorderColor = false;
            this.txtAPP3_COMBIN.ParentStyleUsing.UseBorders = false;
            this.txtAPP3_COMBIN.ParentStyleUsing.UseBorderWidth = false;
            this.txtAPP3_COMBIN.ParentStyleUsing.UseFont = false;
            this.txtAPP3_COMBIN.ParentStyleUsing.UseForeColor = false;
            this.txtAPP3_COMBIN.Size = new System.Drawing.Size(65, 19);
            this.txtAPP3_COMBIN.Tag = null;
            // 
            // txtAPP2_COMBIN
            // 
            this.txtAPP2_COMBIN.CanGrow = false;
            this.txtAPP2_COMBIN.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "APP2_COMBIN", "")});
            this.txtAPP2_COMBIN.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtAPP2_COMBIN.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txtAPP2_COMBIN.Location = new System.Drawing.Point(140, 0);
            this.txtAPP2_COMBIN.Name = "txtAPP2_COMBIN";
            this.txtAPP2_COMBIN.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.txtAPP2_COMBIN.ParentStyleUsing.UseBackColor = false;
            this.txtAPP2_COMBIN.ParentStyleUsing.UseBorderColor = false;
            this.txtAPP2_COMBIN.ParentStyleUsing.UseBorders = false;
            this.txtAPP2_COMBIN.ParentStyleUsing.UseBorderWidth = false;
            this.txtAPP2_COMBIN.ParentStyleUsing.UseFont = false;
            this.txtAPP2_COMBIN.ParentStyleUsing.UseForeColor = false;
            this.txtAPP2_COMBIN.Size = new System.Drawing.Size(65, 19);
            this.txtAPP2_COMBIN.Tag = null;
            // 
            // txtAPP1_COMBIN
            // 
            this.txtAPP1_COMBIN.CanGrow = false;
            this.txtAPP1_COMBIN.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "APP1_COMBIN", "")});
            this.txtAPP1_COMBIN.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtAPP1_COMBIN.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txtAPP1_COMBIN.Location = new System.Drawing.Point(75, 0);
            this.txtAPP1_COMBIN.Name = "txtAPP1_COMBIN";
            this.txtAPP1_COMBIN.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.txtAPP1_COMBIN.ParentStyleUsing.UseBackColor = false;
            this.txtAPP1_COMBIN.ParentStyleUsing.UseBorderColor = false;
            this.txtAPP1_COMBIN.ParentStyleUsing.UseBorders = false;
            this.txtAPP1_COMBIN.ParentStyleUsing.UseBorderWidth = false;
            this.txtAPP1_COMBIN.ParentStyleUsing.UseFont = false;
            this.txtAPP1_COMBIN.ParentStyleUsing.UseForeColor = false;
            this.txtAPP1_COMBIN.Size = new System.Drawing.Size(65, 19);
            this.txtAPP1_COMBIN.Tag = null;
            // 
            // txtSTKCODE
            // 
            this.txtSTKCODE.CanGrow = false;
            this.txtSTKCODE.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "STKCODE", "")});
            this.txtSTKCODE.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtSTKCODE.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txtSTKCODE.Location = new System.Drawing.Point(0, 0);
            this.txtSTKCODE.Name = "txtSTKCODE";
            this.txtSTKCODE.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.txtSTKCODE.ParentStyleUsing.UseBackColor = false;
            this.txtSTKCODE.ParentStyleUsing.UseBorderColor = false;
            this.txtSTKCODE.ParentStyleUsing.UseBorders = false;
            this.txtSTKCODE.ParentStyleUsing.UseBorderWidth = false;
            this.txtSTKCODE.ParentStyleUsing.UseFont = false;
            this.txtSTKCODE.ParentStyleUsing.UseForeColor = false;
            this.txtSTKCODE.Size = new System.Drawing.Size(75, 19);
            this.txtSTKCODE.Tag = null;
            // 
            // txtStatusDesc
            // 
            this.txtStatusDesc.CanGrow = false;
            this.txtStatusDesc.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "STATUSDESC", "")});
            this.txtStatusDesc.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtStatusDesc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txtStatusDesc.Location = new System.Drawing.Point(685, 12);
            this.txtStatusDesc.Name = "txtStatusDesc";
            this.txtStatusDesc.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.txtStatusDesc.ParentStyleUsing.UseBackColor = false;
            this.txtStatusDesc.ParentStyleUsing.UseBorderColor = false;
            this.txtStatusDesc.ParentStyleUsing.UseBorders = false;
            this.txtStatusDesc.ParentStyleUsing.UseBorderWidth = false;
            this.txtStatusDesc.ParentStyleUsing.UseFont = false;
            this.txtStatusDesc.ParentStyleUsing.UseForeColor = false;
            this.txtStatusDesc.Size = new System.Drawing.Size(40, 19);
            this.txtStatusDesc.Tag = null;
            // 
            // PageHeader
            // 
            this.PageHeader.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.Line1,
            this.lblDesc,
            this.lblUnit,
            this.lblCompName,
            this.lblDC,
            this.lblA3_CT,
            this.lblA2_CT,
            this.lblA1_CT,
            this.lblC6,
            this.lblC5,
            this.lblC4,
            this.lblC3,
            this.lblC2,
            this.lblC1,
            this.lblA3,
            this.lblA2,
            this.lblA1,
            this.txtPages,
            this.txtPage,
            this.lblOf,
            this.lblPage,
            this.txtPrint,
            this.lblPrint,
            this.lblCaption,
            this.lblSTK});
            this.PageHeader.Height = 117;
            this.PageHeader.Name = "PageHeader";
            this.PageHeader.ParentStyleUsing.UseBackColor = false;
            this.PageHeader.ParentStyleUsing.UseBorderColor = false;
            this.PageHeader.ParentStyleUsing.UseBorders = false;
            this.PageHeader.ParentStyleUsing.UseBorderWidth = false;
            this.PageHeader.ParentStyleUsing.UseFont = false;
            this.PageHeader.ParentStyleUsing.UseForeColor = false;
            // 
            // Line1
            // 
            this.Line1.ForeColor = System.Drawing.Color.Black;
            this.Line1.Location = new System.Drawing.Point(0, 94);
            this.Line1.Name = "Line1";
            this.Line1.ParentStyleUsing.UseBackColor = false;
            this.Line1.ParentStyleUsing.UseBorderColor = false;
            this.Line1.ParentStyleUsing.UseBorders = false;
            this.Line1.ParentStyleUsing.UseBorderWidth = false;
            this.Line1.ParentStyleUsing.UseFont = false;
            this.Line1.ParentStyleUsing.UseForeColor = false;
            this.Line1.Size = new System.Drawing.Size(725, 2);
            this.Line1.Tag = null;
            // 
            // lblDesc
            // 
            this.lblDesc.CanGrow = false;
            this.lblDesc.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblDesc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblDesc.Location = new System.Drawing.Point(492, 81);
            this.lblDesc.Name = "lblDesc";
            this.lblDesc.NavigateUrl = null;
            this.lblDesc.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.lblDesc.ParentStyleUsing.UseBackColor = false;
            this.lblDesc.ParentStyleUsing.UseBorderColor = false;
            this.lblDesc.ParentStyleUsing.UseBorders = false;
            this.lblDesc.ParentStyleUsing.UseBorderWidth = false;
            this.lblDesc.ParentStyleUsing.UseFont = false;
            this.lblDesc.ParentStyleUsing.UseForeColor = false;
            this.lblDesc.Size = new System.Drawing.Size(152, 19);
            this.lblDesc.Tag = null;
            this.lblDesc.Text = "Description";
            // 
            // lblUnit
            // 
            this.lblUnit.CanGrow = false;
            this.lblUnit.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblUnit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblUnit.Location = new System.Drawing.Point(644, 81);
            this.lblUnit.Name = "lblUnit";
            this.lblUnit.NavigateUrl = null;
            this.lblUnit.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.lblUnit.ParentStyleUsing.UseBackColor = false;
            this.lblUnit.ParentStyleUsing.UseBorderColor = false;
            this.lblUnit.ParentStyleUsing.UseBorders = false;
            this.lblUnit.ParentStyleUsing.UseBorderWidth = false;
            this.lblUnit.ParentStyleUsing.UseFont = false;
            this.lblUnit.ParentStyleUsing.UseForeColor = false;
            this.lblUnit.Size = new System.Drawing.Size(31, 19);
            this.lblUnit.Tag = null;
            this.lblUnit.Text = "Unit";
            // 
            // lblCompName
            // 
            this.lblCompName.CanGrow = false;
            this.lblCompName.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblCompName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblCompName.Location = new System.Drawing.Point(0, 0);
            this.lblCompName.Name = "lblCompName";
            this.lblCompName.NavigateUrl = null;
            this.lblCompName.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.lblCompName.ParentStyleUsing.UseBackColor = false;
            this.lblCompName.ParentStyleUsing.UseBorderColor = false;
            this.lblCompName.ParentStyleUsing.UseBorders = false;
            this.lblCompName.ParentStyleUsing.UseBorderWidth = false;
            this.lblCompName.ParentStyleUsing.UseFont = false;
            this.lblCompName.ParentStyleUsing.UseForeColor = false;
            this.lblCompName.Size = new System.Drawing.Size(725, 19);
            this.lblCompName.Tag = null;
            // 
            // lblDC
            // 
            this.lblDC.CanGrow = false;
            this.lblDC.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblDC.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblDC.Location = new System.Drawing.Point(673, 68);
            this.lblDC.Multiline = true;
            this.lblDC.Name = "lblDC";
            this.lblDC.NavigateUrl = null;
            this.lblDC.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.lblDC.ParentStyleUsing.UseBackColor = false;
            this.lblDC.ParentStyleUsing.UseBorderColor = false;
            this.lblDC.ParentStyleUsing.UseBorders = false;
            this.lblDC.ParentStyleUsing.UseBorderWidth = false;
            this.lblDC.ParentStyleUsing.UseFont = false;
            this.lblDC.ParentStyleUsing.UseForeColor = false;
            this.lblDC.Size = new System.Drawing.Size(51, 25);
            this.lblDC.Tag = null;
            this.lblDC.Text = "Creation Date";
            this.lblDC.TextAlignment = DevExpress.XtraPrinting.TextAlignment.BottomRight;
            // 
            // lblA3_CT
            // 
            this.lblA3_CT.CanGrow = false;
            this.lblA3_CT.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblA3_CT.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblA3_CT.Location = new System.Drawing.Point(204, 81);
            this.lblA3_CT.Name = "lblA3_CT";
            this.lblA3_CT.NavigateUrl = null;
            this.lblA3_CT.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.lblA3_CT.ParentStyleUsing.UseBackColor = false;
            this.lblA3_CT.ParentStyleUsing.UseBorderColor = false;
            this.lblA3_CT.ParentStyleUsing.UseBorders = false;
            this.lblA3_CT.ParentStyleUsing.UseBorderWidth = false;
            this.lblA3_CT.ParentStyleUsing.UseFont = false;
            this.lblA3_CT.ParentStyleUsing.UseForeColor = false;
            this.lblA3_CT.Size = new System.Drawing.Size(66, 19);
            this.lblA3_CT.Tag = null;
            this.lblA3_CT.Text = "Combin#";
            // 
            // lblA2_CT
            // 
            this.lblA2_CT.CanGrow = false;
            this.lblA2_CT.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblA2_CT.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblA2_CT.Location = new System.Drawing.Point(140, 81);
            this.lblA2_CT.Name = "lblA2_CT";
            this.lblA2_CT.NavigateUrl = null;
            this.lblA2_CT.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.lblA2_CT.ParentStyleUsing.UseBackColor = false;
            this.lblA2_CT.ParentStyleUsing.UseBorderColor = false;
            this.lblA2_CT.ParentStyleUsing.UseBorders = false;
            this.lblA2_CT.ParentStyleUsing.UseBorderWidth = false;
            this.lblA2_CT.ParentStyleUsing.UseFont = false;
            this.lblA2_CT.ParentStyleUsing.UseForeColor = false;
            this.lblA2_CT.Size = new System.Drawing.Size(66, 19);
            this.lblA2_CT.Tag = null;
            this.lblA2_CT.Text = "Combin#";
            // 
            // lblA1_CT
            // 
            this.lblA1_CT.CanGrow = false;
            this.lblA1_CT.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblA1_CT.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblA1_CT.Location = new System.Drawing.Point(75, 81);
            this.lblA1_CT.Name = "lblA1_CT";
            this.lblA1_CT.NavigateUrl = null;
            this.lblA1_CT.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.lblA1_CT.ParentStyleUsing.UseBackColor = false;
            this.lblA1_CT.ParentStyleUsing.UseBorderColor = false;
            this.lblA1_CT.ParentStyleUsing.UseBorders = false;
            this.lblA1_CT.ParentStyleUsing.UseBorderWidth = false;
            this.lblA1_CT.ParentStyleUsing.UseFont = false;
            this.lblA1_CT.ParentStyleUsing.UseForeColor = false;
            this.lblA1_CT.Size = new System.Drawing.Size(66, 19);
            this.lblA1_CT.Tag = null;
            this.lblA1_CT.Text = "Combin#";
            // 
            // lblC6
            // 
            this.lblC6.CanGrow = false;
            this.lblC6.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblC6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblC6.Location = new System.Drawing.Point(456, 81);
            this.lblC6.Name = "lblC6";
            this.lblC6.NavigateUrl = null;
            this.lblC6.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.lblC6.ParentStyleUsing.UseBackColor = false;
            this.lblC6.ParentStyleUsing.UseBorderColor = false;
            this.lblC6.ParentStyleUsing.UseBorders = false;
            this.lblC6.ParentStyleUsing.UseBorderWidth = false;
            this.lblC6.ParentStyleUsing.UseFont = false;
            this.lblC6.ParentStyleUsing.UseForeColor = false;
            this.lblC6.Size = new System.Drawing.Size(38, 19);
            this.lblC6.Tag = null;
            this.lblC6.Text = "C6";
            // 
            // lblC5
            // 
            this.lblC5.CanGrow = false;
            this.lblC5.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblC5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblC5.Location = new System.Drawing.Point(419, 81);
            this.lblC5.Name = "lblC5";
            this.lblC5.NavigateUrl = null;
            this.lblC5.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.lblC5.ParentStyleUsing.UseBackColor = false;
            this.lblC5.ParentStyleUsing.UseBorderColor = false;
            this.lblC5.ParentStyleUsing.UseBorders = false;
            this.lblC5.ParentStyleUsing.UseBorderWidth = false;
            this.lblC5.ParentStyleUsing.UseFont = false;
            this.lblC5.ParentStyleUsing.UseForeColor = false;
            this.lblC5.Size = new System.Drawing.Size(38, 19);
            this.lblC5.Tag = null;
            this.lblC5.Text = "C5";
            // 
            // lblC4
            // 
            this.lblC4.CanGrow = false;
            this.lblC4.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblC4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblC4.Location = new System.Drawing.Point(381, 81);
            this.lblC4.Name = "lblC4";
            this.lblC4.NavigateUrl = null;
            this.lblC4.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.lblC4.ParentStyleUsing.UseBackColor = false;
            this.lblC4.ParentStyleUsing.UseBorderColor = false;
            this.lblC4.ParentStyleUsing.UseBorders = false;
            this.lblC4.ParentStyleUsing.UseBorderWidth = false;
            this.lblC4.ParentStyleUsing.UseFont = false;
            this.lblC4.ParentStyleUsing.UseForeColor = false;
            this.lblC4.Size = new System.Drawing.Size(38, 19);
            this.lblC4.Tag = null;
            this.lblC4.Text = "C4";
            // 
            // lblC3
            // 
            this.lblC3.CanGrow = false;
            this.lblC3.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblC3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblC3.Location = new System.Drawing.Point(344, 81);
            this.lblC3.Name = "lblC3";
            this.lblC3.NavigateUrl = null;
            this.lblC3.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.lblC3.ParentStyleUsing.UseBackColor = false;
            this.lblC3.ParentStyleUsing.UseBorderColor = false;
            this.lblC3.ParentStyleUsing.UseBorders = false;
            this.lblC3.ParentStyleUsing.UseBorderWidth = false;
            this.lblC3.ParentStyleUsing.UseFont = false;
            this.lblC3.ParentStyleUsing.UseForeColor = false;
            this.lblC3.Size = new System.Drawing.Size(38, 19);
            this.lblC3.Tag = null;
            this.lblC3.Text = "C3";
            // 
            // lblC2
            // 
            this.lblC2.CanGrow = false;
            this.lblC2.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblC2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblC2.Location = new System.Drawing.Point(306, 81);
            this.lblC2.Name = "lblC2";
            this.lblC2.NavigateUrl = null;
            this.lblC2.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.lblC2.ParentStyleUsing.UseBackColor = false;
            this.lblC2.ParentStyleUsing.UseBorderColor = false;
            this.lblC2.ParentStyleUsing.UseBorders = false;
            this.lblC2.ParentStyleUsing.UseBorderWidth = false;
            this.lblC2.ParentStyleUsing.UseFont = false;
            this.lblC2.ParentStyleUsing.UseForeColor = false;
            this.lblC2.Size = new System.Drawing.Size(38, 19);
            this.lblC2.Tag = null;
            this.lblC2.Text = "C2";
            // 
            // lblC1
            // 
            this.lblC1.CanGrow = false;
            this.lblC1.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblC1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblC1.Location = new System.Drawing.Point(269, 81);
            this.lblC1.Name = "lblC1";
            this.lblC1.NavigateUrl = null;
            this.lblC1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.lblC1.ParentStyleUsing.UseBackColor = false;
            this.lblC1.ParentStyleUsing.UseBorderColor = false;
            this.lblC1.ParentStyleUsing.UseBorders = false;
            this.lblC1.ParentStyleUsing.UseBorderWidth = false;
            this.lblC1.ParentStyleUsing.UseFont = false;
            this.lblC1.ParentStyleUsing.UseForeColor = false;
            this.lblC1.Size = new System.Drawing.Size(38, 19);
            this.lblC1.Tag = null;
            this.lblC1.Text = "C1";
            // 
            // lblA3
            // 
            this.lblA3.CanGrow = false;
            this.lblA3.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblA3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblA3.Location = new System.Drawing.Point(204, 69);
            this.lblA3.Name = "lblA3";
            this.lblA3.NavigateUrl = null;
            this.lblA3.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.lblA3.ParentStyleUsing.UseBackColor = false;
            this.lblA3.ParentStyleUsing.UseBorderColor = false;
            this.lblA3.ParentStyleUsing.UseBorders = false;
            this.lblA3.ParentStyleUsing.UseBorderWidth = false;
            this.lblA3.ParentStyleUsing.UseFont = false;
            this.lblA3.ParentStyleUsing.UseForeColor = false;
            this.lblA3.Size = new System.Drawing.Size(66, 19);
            this.lblA3.Tag = null;
            this.lblA3.Text = "APPENDIX3";
            // 
            // lblA2
            // 
            this.lblA2.CanGrow = false;
            this.lblA2.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblA2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblA2.Location = new System.Drawing.Point(140, 69);
            this.lblA2.Name = "lblA2";
            this.lblA2.NavigateUrl = null;
            this.lblA2.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.lblA2.ParentStyleUsing.UseBackColor = false;
            this.lblA2.ParentStyleUsing.UseBorderColor = false;
            this.lblA2.ParentStyleUsing.UseBorders = false;
            this.lblA2.ParentStyleUsing.UseBorderWidth = false;
            this.lblA2.ParentStyleUsing.UseFont = false;
            this.lblA2.ParentStyleUsing.UseForeColor = false;
            this.lblA2.Size = new System.Drawing.Size(66, 19);
            this.lblA2.Tag = null;
            this.lblA2.Text = "APPENDIX2";
            // 
            // lblA1
            // 
            this.lblA1.CanGrow = false;
            this.lblA1.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblA1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblA1.Location = new System.Drawing.Point(75, 69);
            this.lblA1.Name = "lblA1";
            this.lblA1.NavigateUrl = null;
            this.lblA1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.lblA1.ParentStyleUsing.UseBackColor = false;
            this.lblA1.ParentStyleUsing.UseBorderColor = false;
            this.lblA1.ParentStyleUsing.UseBorders = false;
            this.lblA1.ParentStyleUsing.UseBorderWidth = false;
            this.lblA1.ParentStyleUsing.UseFont = false;
            this.lblA1.ParentStyleUsing.UseForeColor = false;
            this.lblA1.Size = new System.Drawing.Size(66, 19);
            this.lblA1.Tag = null;
            this.lblA1.Text = "APPENDIX1";
            // 
            // txtPages
            // 
            this.txtPages.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtPages.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txtPages.Location = new System.Drawing.Point(669, 50);
            this.txtPages.Name = "txtPages";
            this.txtPages.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.txtPages.ParentStyleUsing.UseBackColor = false;
            this.txtPages.ParentStyleUsing.UseBorderColor = false;
            this.txtPages.ParentStyleUsing.UseBorders = false;
            this.txtPages.ParentStyleUsing.UseBorderWidth = false;
            this.txtPages.ParentStyleUsing.UseFont = false;
            this.txtPages.ParentStyleUsing.UseForeColor = false;
            this.txtPages.Size = new System.Drawing.Size(56, 19);
            xrSummary6.FormatString = "{0:0}";
            xrSummary6.Func = DevExpress.XtraReports.UI.SummaryFunc.DSum;
            this.txtPages.Summary = xrSummary6;
            this.txtPages.Tag = null;
            this.txtPages.Text = "1";
            // 
            // txtPage
            // 
            this.txtPage.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtPage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txtPage.Location = new System.Drawing.Point(581, 50);
            this.txtPage.Name = "txtPage";
            this.txtPage.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.txtPage.ParentStyleUsing.UseBackColor = false;
            this.txtPage.ParentStyleUsing.UseBorderColor = false;
            this.txtPage.ParentStyleUsing.UseBorders = false;
            this.txtPage.ParentStyleUsing.UseBorderWidth = false;
            this.txtPage.ParentStyleUsing.UseFont = false;
            this.txtPage.ParentStyleUsing.UseForeColor = false;
            this.txtPage.Size = new System.Drawing.Size(56, 19);
            xrSummary7.FormatString = "{0:0}";
            xrSummary7.Func = DevExpress.XtraReports.UI.SummaryFunc.DSum;
            this.txtPage.Summary = xrSummary7;
            this.txtPage.Tag = null;
            this.txtPage.Text = "1";
            // 
            // lblOf
            // 
            this.lblOf.CanGrow = false;
            this.lblOf.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblOf.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblOf.Location = new System.Drawing.Point(638, 50);
            this.lblOf.Name = "lblOf";
            this.lblOf.NavigateUrl = null;
            this.lblOf.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.lblOf.ParentStyleUsing.UseBackColor = false;
            this.lblOf.ParentStyleUsing.UseBorderColor = false;
            this.lblOf.ParentStyleUsing.UseBorders = false;
            this.lblOf.ParentStyleUsing.UseBorderWidth = false;
            this.lblOf.ParentStyleUsing.UseFont = false;
            this.lblOf.ParentStyleUsing.UseForeColor = false;
            this.lblOf.Size = new System.Drawing.Size(31, 19);
            this.lblOf.Tag = null;
            this.lblOf.Text = "of";
            this.lblOf.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter;
            // 
            // lblPage
            // 
            this.lblPage.CanGrow = false;
            this.lblPage.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblPage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblPage.Location = new System.Drawing.Point(481, 50);
            this.lblPage.Name = "lblPage";
            this.lblPage.NavigateUrl = null;
            this.lblPage.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.lblPage.ParentStyleUsing.UseBackColor = false;
            this.lblPage.ParentStyleUsing.UseBorderColor = false;
            this.lblPage.ParentStyleUsing.UseBorders = false;
            this.lblPage.ParentStyleUsing.UseBorderWidth = false;
            this.lblPage.ParentStyleUsing.UseFont = false;
            this.lblPage.ParentStyleUsing.UseForeColor = false;
            this.lblPage.Size = new System.Drawing.Size(100, 19);
            this.lblPage.Tag = null;
            this.lblPage.Text = "Page :";
            // 
            // txtPrint
            // 
            this.txtPrint.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtPrint.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txtPrint.Location = new System.Drawing.Point(581, 38);
            this.txtPrint.Name = "txtPrint";
            this.txtPrint.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.txtPrint.ParentStyleUsing.UseBackColor = false;
            this.txtPrint.ParentStyleUsing.UseBorderColor = false;
            this.txtPrint.ParentStyleUsing.UseBorders = false;
            this.txtPrint.ParentStyleUsing.UseBorderWidth = false;
            this.txtPrint.ParentStyleUsing.UseFont = false;
            this.txtPrint.ParentStyleUsing.UseForeColor = false;
            this.txtPrint.Size = new System.Drawing.Size(144, 19);
            xrSummary8.FormatString = "{0:dd/MM/yyyy hh:nn:ss}";
            this.txtPrint.Summary = xrSummary8;
            this.txtPrint.Tag = null;
            this.txtPrint.Text = "13/12/2007 15:29:46";
            // 
            // lblPrint
            // 
            this.lblPrint.CanGrow = false;
            this.lblPrint.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblPrint.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblPrint.Location = new System.Drawing.Point(481, 38);
            this.lblPrint.Name = "lblPrint";
            this.lblPrint.NavigateUrl = null;
            this.lblPrint.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.lblPrint.ParentStyleUsing.UseBackColor = false;
            this.lblPrint.ParentStyleUsing.UseBorderColor = false;
            this.lblPrint.ParentStyleUsing.UseBorders = false;
            this.lblPrint.ParentStyleUsing.UseBorderWidth = false;
            this.lblPrint.ParentStyleUsing.UseFont = false;
            this.lblPrint.ParentStyleUsing.UseForeColor = false;
            this.lblPrint.Size = new System.Drawing.Size(100, 19);
            this.lblPrint.Tag = null;
            this.lblPrint.Text = "Print At :";
            // 
            // lblCaption
            // 
            this.lblCaption.CanGrow = false;
            this.lblCaption.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblCaption.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblCaption.Location = new System.Drawing.Point(0, 19);
            this.lblCaption.Name = "lblCaption";
            this.lblCaption.NavigateUrl = null;
            this.lblCaption.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.lblCaption.ParentStyleUsing.UseBackColor = false;
            this.lblCaption.ParentStyleUsing.UseBorderColor = false;
            this.lblCaption.ParentStyleUsing.UseBorders = false;
            this.lblCaption.ParentStyleUsing.UseBorderWidth = false;
            this.lblCaption.ParentStyleUsing.UseFont = false;
            this.lblCaption.ParentStyleUsing.UseForeColor = false;
            this.lblCaption.Size = new System.Drawing.Size(725, 19);
            this.lblCaption.Tag = null;
            this.lblCaption.Text = "Stock Code Batch List (Ready for Post)";
            // 
            // lblSTK
            // 
            this.lblSTK.CanGrow = false;
            this.lblSTK.Font = new System.Drawing.Font("Arial Unicode MS", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblSTK.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblSTK.Location = new System.Drawing.Point(0, 81);
            this.lblSTK.Name = "lblSTK";
            this.lblSTK.NavigateUrl = null;
            this.lblSTK.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.lblSTK.ParentStyleUsing.UseBackColor = false;
            this.lblSTK.ParentStyleUsing.UseBorderColor = false;
            this.lblSTK.ParentStyleUsing.UseBorders = false;
            this.lblSTK.ParentStyleUsing.UseBorderWidth = false;
            this.lblSTK.ParentStyleUsing.UseFont = false;
            this.lblSTK.ParentStyleUsing.UseForeColor = false;
            this.lblSTK.Size = new System.Drawing.Size(75, 19);
            this.lblSTK.Tag = null;
            this.lblSTK.Text = "STKCODE";
            // 
            // ghSTK
            // 
            this.ghSTK.GroupFields.AddRange(new DevExpress.XtraReports.UI.GroupField[] {
            new DevExpress.XtraReports.UI.GroupField("STKCODE", DevExpress.XtraReports.UI.XRColumnSortOrder.Ascending)});
            this.ghSTK.Height = 0;
            this.ghSTK.Name = "ghSTK";
            this.ghSTK.ParentStyleUsing.UseBackColor = false;
            this.ghSTK.ParentStyleUsing.UseBorderColor = false;
            this.ghSTK.ParentStyleUsing.UseBorders = false;
            this.ghSTK.ParentStyleUsing.UseBorderWidth = false;
            this.ghSTK.ParentStyleUsing.UseFont = false;
            this.ghSTK.ParentStyleUsing.UseForeColor = false;
            // 
            // gfSTK
            // 
            this.gfSTK.Height = 0;
            this.gfSTK.Name = "gfSTK";
            this.gfSTK.ParentStyleUsing.UseBackColor = false;
            this.gfSTK.ParentStyleUsing.UseBorderColor = false;
            this.gfSTK.ParentStyleUsing.UseBorders = false;
            this.gfSTK.ParentStyleUsing.UseBorderWidth = false;
            this.gfSTK.ParentStyleUsing.UseFont = false;
            this.gfSTK.ParentStyleUsing.UseForeColor = false;
            this.gfSTK.Visible = false;
            // 
            // PageFooter
            // 
            this.PageFooter.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.lblClass6,
            this.lblClass5,
            this.lblClass4,
            this.lblClass3,
            this.lblClass2,
            this.lblClass1});
            this.PageFooter.Height = 23;
            this.PageFooter.Name = "PageFooter";
            this.PageFooter.ParentStyleUsing.UseBackColor = false;
            this.PageFooter.ParentStyleUsing.UseBorderColor = false;
            this.PageFooter.ParentStyleUsing.UseBorders = false;
            this.PageFooter.ParentStyleUsing.UseBorderWidth = false;
            this.PageFooter.ParentStyleUsing.UseFont = false;
            this.PageFooter.ParentStyleUsing.UseForeColor = false;
            // 
            // lblClass6
            // 
            this.lblClass6.CanGrow = false;
            this.lblClass6.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblClass6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblClass6.Location = new System.Drawing.Point(594, 0);
            this.lblClass6.Name = "lblClass6";
            this.lblClass6.NavigateUrl = null;
            this.lblClass6.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.lblClass6.ParentStyleUsing.UseBackColor = false;
            this.lblClass6.ParentStyleUsing.UseBorderColor = false;
            this.lblClass6.ParentStyleUsing.UseBorders = false;
            this.lblClass6.ParentStyleUsing.UseBorderWidth = false;
            this.lblClass6.ParentStyleUsing.UseFont = false;
            this.lblClass6.ParentStyleUsing.UseForeColor = false;
            this.lblClass6.Size = new System.Drawing.Size(119, 19);
            this.lblClass6.Tag = null;
            this.lblClass6.Text = "C6 : Class6";
            // 
            // lblClass5
            // 
            this.lblClass5.CanGrow = false;
            this.lblClass5.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblClass5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblClass5.Location = new System.Drawing.Point(475, 0);
            this.lblClass5.Name = "lblClass5";
            this.lblClass5.NavigateUrl = null;
            this.lblClass5.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.lblClass5.ParentStyleUsing.UseBackColor = false;
            this.lblClass5.ParentStyleUsing.UseBorderColor = false;
            this.lblClass5.ParentStyleUsing.UseBorders = false;
            this.lblClass5.ParentStyleUsing.UseBorderWidth = false;
            this.lblClass5.ParentStyleUsing.UseFont = false;
            this.lblClass5.ParentStyleUsing.UseForeColor = false;
            this.lblClass5.Size = new System.Drawing.Size(119, 19);
            this.lblClass5.Tag = null;
            this.lblClass5.Text = "C5 : Class5";
            // 
            // lblClass4
            // 
            this.lblClass4.CanGrow = false;
            this.lblClass4.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblClass4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblClass4.Location = new System.Drawing.Point(356, 0);
            this.lblClass4.Name = "lblClass4";
            this.lblClass4.NavigateUrl = null;
            this.lblClass4.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.lblClass4.ParentStyleUsing.UseBackColor = false;
            this.lblClass4.ParentStyleUsing.UseBorderColor = false;
            this.lblClass4.ParentStyleUsing.UseBorders = false;
            this.lblClass4.ParentStyleUsing.UseBorderWidth = false;
            this.lblClass4.ParentStyleUsing.UseFont = false;
            this.lblClass4.ParentStyleUsing.UseForeColor = false;
            this.lblClass4.Size = new System.Drawing.Size(119, 19);
            this.lblClass4.Tag = null;
            this.lblClass4.Text = "C4 : Class4";
            // 
            // lblClass3
            // 
            this.lblClass3.CanGrow = false;
            this.lblClass3.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblClass3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblClass3.Location = new System.Drawing.Point(238, 0);
            this.lblClass3.Name = "lblClass3";
            this.lblClass3.NavigateUrl = null;
            this.lblClass3.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.lblClass3.ParentStyleUsing.UseBackColor = false;
            this.lblClass3.ParentStyleUsing.UseBorderColor = false;
            this.lblClass3.ParentStyleUsing.UseBorders = false;
            this.lblClass3.ParentStyleUsing.UseBorderWidth = false;
            this.lblClass3.ParentStyleUsing.UseFont = false;
            this.lblClass3.ParentStyleUsing.UseForeColor = false;
            this.lblClass3.Size = new System.Drawing.Size(119, 19);
            this.lblClass3.Tag = null;
            this.lblClass3.Text = "C3 : Class3";
            // 
            // lblClass2
            // 
            this.lblClass2.CanGrow = false;
            this.lblClass2.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblClass2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblClass2.Location = new System.Drawing.Point(119, 0);
            this.lblClass2.Name = "lblClass2";
            this.lblClass2.NavigateUrl = null;
            this.lblClass2.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.lblClass2.ParentStyleUsing.UseBackColor = false;
            this.lblClass2.ParentStyleUsing.UseBorderColor = false;
            this.lblClass2.ParentStyleUsing.UseBorders = false;
            this.lblClass2.ParentStyleUsing.UseBorderWidth = false;
            this.lblClass2.ParentStyleUsing.UseFont = false;
            this.lblClass2.ParentStyleUsing.UseForeColor = false;
            this.lblClass2.Size = new System.Drawing.Size(119, 19);
            this.lblClass2.Tag = null;
            this.lblClass2.Text = "C2 : Class2";
            // 
            // lblClass1
            // 
            this.lblClass1.CanGrow = false;
            this.lblClass1.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblClass1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblClass1.Location = new System.Drawing.Point(0, 0);
            this.lblClass1.Name = "lblClass1";
            this.lblClass1.NavigateUrl = null;
            this.lblClass1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.lblClass1.ParentStyleUsing.UseBackColor = false;
            this.lblClass1.ParentStyleUsing.UseBorderColor = false;
            this.lblClass1.ParentStyleUsing.UseBorders = false;
            this.lblClass1.ParentStyleUsing.UseBorderWidth = false;
            this.lblClass1.ParentStyleUsing.UseFont = false;
            this.lblClass1.ParentStyleUsing.UseForeColor = false;
            this.lblClass1.Size = new System.Drawing.Size(119, 19);
            this.lblClass1.Tag = null;
            this.lblClass1.Text = "C1 : Class1";
            // 
            // ProductBatchList
            // 
            this.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.Detail,
            this.PageHeader,
            this.ghSTK,
            this.gfSTK,
            this.PageFooter});
            this.Margins = new System.Drawing.Printing.Margins(50, 50, 100, 100);
            this.PaperKind = System.Drawing.Printing.PaperKind.Custom;
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();

        }

        #endregion

        private DevExpress.XtraReports.UI.DetailBand Detail;
        private DevExpress.XtraReports.UI.XRLabel lbl4;
        private DevExpress.XtraReports.UI.XRLabel txtORIPRC;
        private DevExpress.XtraReports.UI.XRLabel lblOPrc;
        private DevExpress.XtraReports.UI.XRLabel lbl1;
        private DevExpress.XtraReports.UI.XRLabel txtBASPRC;
        private DevExpress.XtraReports.UI.XRLabel lblRPrc;
        private DevExpress.XtraReports.UI.XRLabel lbl5;
        private DevExpress.XtraReports.UI.XRLabel lbl3;
        private DevExpress.XtraReports.UI.XRLabel lbl2;
        private DevExpress.XtraReports.UI.XRLabel txtSTATUS;
        private DevExpress.XtraReports.UI.XRLabel txtVPRC;
        private DevExpress.XtraReports.UI.XRLabel txtVCURR;
        private DevExpress.XtraReports.UI.XRLabel txtWHLPRC;
        private DevExpress.XtraReports.UI.XRLabel lblStatus;
        private DevExpress.XtraReports.UI.XRLabel lblWPrc;
        private DevExpress.XtraReports.UI.XRLabel lblVPrc;
        private DevExpress.XtraReports.UI.XRLabel txtDATECREATE;
        private DevExpress.XtraReports.UI.XRLabel txtMAINUNIT;
        private DevExpress.XtraReports.UI.XRLabel txtCLASS6;
        private DevExpress.XtraReports.UI.XRLabel txtCLASS5;
        private DevExpress.XtraReports.UI.XRLabel txtCLASS4;
        private DevExpress.XtraReports.UI.XRLabel txtCLASS3;
        private DevExpress.XtraReports.UI.XRLabel txtCLASS2;
        private DevExpress.XtraReports.UI.XRLabel txtCLASS1;
        private DevExpress.XtraReports.UI.XRLabel txtDESC;
        private DevExpress.XtraReports.UI.XRLabel txtAPP3_COMBIN;
        private DevExpress.XtraReports.UI.XRLabel txtAPP2_COMBIN;
        private DevExpress.XtraReports.UI.XRLabel txtAPP1_COMBIN;
        private DevExpress.XtraReports.UI.XRLabel txtSTKCODE;
        private DevExpress.XtraReports.UI.XRLabel txtStatusDesc;
        private DevExpress.XtraReports.UI.PageHeaderBand PageHeader;
        private DevExpress.XtraReports.UI.XRLine Line1;
        private DevExpress.XtraReports.UI.XRLabel lblDesc;
        private DevExpress.XtraReports.UI.XRLabel lblUnit;
        private DevExpress.XtraReports.UI.XRLabel lblCompName;
        private DevExpress.XtraReports.UI.XRLabel lblDC;
        private DevExpress.XtraReports.UI.XRLabel lblA3_CT;
        private DevExpress.XtraReports.UI.XRLabel lblA2_CT;
        private DevExpress.XtraReports.UI.XRLabel lblA1_CT;
        private DevExpress.XtraReports.UI.XRLabel lblC6;
        private DevExpress.XtraReports.UI.XRLabel lblC5;
        private DevExpress.XtraReports.UI.XRLabel lblC4;
        private DevExpress.XtraReports.UI.XRLabel lblC3;
        private DevExpress.XtraReports.UI.XRLabel lblC2;
        private DevExpress.XtraReports.UI.XRLabel lblC1;
        private DevExpress.XtraReports.UI.XRLabel lblA3;
        private DevExpress.XtraReports.UI.XRLabel lblA2;
        private DevExpress.XtraReports.UI.XRLabel lblA1;
        private DevExpress.XtraReports.UI.XRLabel txtPages;
        private DevExpress.XtraReports.UI.XRLabel txtPage;
        private DevExpress.XtraReports.UI.XRLabel lblOf;
        private DevExpress.XtraReports.UI.XRLabel lblPage;
        private DevExpress.XtraReports.UI.XRLabel txtPrint;
        private DevExpress.XtraReports.UI.XRLabel lblPrint;
        private DevExpress.XtraReports.UI.XRLabel lblCaption;
        private DevExpress.XtraReports.UI.XRLabel lblSTK;
        private DevExpress.XtraReports.UI.GroupHeaderBand ghSTK;
        private DevExpress.XtraReports.UI.GroupFooterBand gfSTK;
        private DevExpress.XtraReports.UI.PageFooterBand PageFooter;
        private DevExpress.XtraReports.UI.XRLabel lblClass6;
        private DevExpress.XtraReports.UI.XRLabel lblClass5;
        private DevExpress.XtraReports.UI.XRLabel lblClass4;
        private DevExpress.XtraReports.UI.XRLabel lblClass3;
        private DevExpress.XtraReports.UI.XRLabel lblClass2;
        private DevExpress.XtraReports.UI.XRLabel lblClass1;

    }
}
