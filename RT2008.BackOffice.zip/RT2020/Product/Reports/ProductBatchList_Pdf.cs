using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using DevExpress.XtraReports.UI;

namespace RT2008.Product.Reports
{
    public partial class ProductBatchList_Pdf : DevExpress.XtraReports.UI.XtraReport
    {
        public ProductBatchList_Pdf()
        {
            InitializeComponent();
        }

    }
}
