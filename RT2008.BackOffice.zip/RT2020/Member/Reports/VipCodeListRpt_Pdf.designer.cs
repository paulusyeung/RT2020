namespace RT2008.Member.Reports
{
    partial class VipCodeListRpt_Pdf
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Detail = new DevExpress.XtraReports.UI.DetailBand();
            this.xrLine1 = new DevExpress.XtraReports.UI.XRLine();
            this.Text22 = new DevExpress.XtraReports.UI.XRLabel();
            this.GRADE1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text20 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text16 = new DevExpress.XtraReports.UI.XRLabel();
            this.GROUP1 = new DevExpress.XtraReports.UI.XRLabel();
            this.VIPNO1 = new DevExpress.XtraReports.UI.XRLabel();
            this.ADDRESS41 = new DevExpress.XtraReports.UI.XRLabel();
            this.ADDRESS31 = new DevExpress.XtraReports.UI.XRLabel();
            this.ADDRESS21 = new DevExpress.XtraReports.UI.XRLabel();
            this.ADDRESS11 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text42 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text41 = new DevExpress.XtraReports.UI.XRLabel();
            this.R31 = new DevExpress.XtraReports.UI.XRLabel();
            this.R21 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text40 = new DevExpress.XtraReports.UI.XRLabel();
            this.R11 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text39 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text38 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text37 = new DevExpress.XtraReports.UI.XRLabel();
            this.MEMO1 = new DevExpress.XtraReports.UI.XRLabel();
            this.PYDISC1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text36 = new DevExpress.XtraReports.UI.XRLabel();
            this.TERMS1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text35 = new DevExpress.XtraReports.UI.XRLabel();
            this.ACREDIT1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text34 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text33 = new DevExpress.XtraReports.UI.XRLabel();
            this.NATION1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text32 = new DevExpress.XtraReports.UI.XRLabel();
            this.REMARKS1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text31 = new DevExpress.XtraReports.UI.XRLabel();
            this.DATEREGIS1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text30 = new DevExpress.XtraReports.UI.XRLabel();
            this.DATEBIRTH1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text29 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text28 = new DevExpress.XtraReports.UI.XRLabel();
            this.DATEMIGRATE1 = new DevExpress.XtraReports.UI.XRLabel();
            this.DATECOMM1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text27 = new DevExpress.XtraReports.UI.XRLabel();
            this.CARDACTIVE1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text26 = new DevExpress.XtraReports.UI.XRLabel();
            this.CARDRECEIVE1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text25 = new DevExpress.XtraReports.UI.XRLabel();
            this.CARDNAME1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text24 = new DevExpress.XtraReports.UI.XRLabel();
            this.CARDEXPIRE1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text23 = new DevExpress.XtraReports.UI.XRLabel();
            this.CARDISSUE1 = new DevExpress.XtraReports.UI.XRLabel();
            this.SEX1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text21 = new DevExpress.XtraReports.UI.XRLabel();
            this.IDNO1 = new DevExpress.XtraReports.UI.XRLabel();
            this.EMAIL1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text19 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text18 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text17 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text15 = new DevExpress.XtraReports.UI.XRLabel();
            this.USERLCHG1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text14 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text13 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text12 = new DevExpress.XtraReports.UI.XRLabel();
            this.DATELCHG1 = new DevExpress.XtraReports.UI.XRLabel();
            this.DATECREATE1 = new DevExpress.XtraReports.UI.XRLabel();
            this.TELP1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text11 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text10 = new DevExpress.XtraReports.UI.XRLabel();
            this.TELH1 = new DevExpress.XtraReports.UI.XRLabel();
            this.FAX1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text9 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text8 = new DevExpress.XtraReports.UI.XRLabel();
            this.TELW1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text7 = new DevExpress.XtraReports.UI.XRLabel();
            this.NNAME1 = new DevExpress.XtraReports.UI.XRLabel();
            this.FNAME1 = new DevExpress.XtraReports.UI.XRLabel();
            this.LNAME1 = new DevExpress.XtraReports.UI.XRLabel();
            this.SALUTE1 = new DevExpress.XtraReports.UI.XRLabel();
            this.PageHeader = new DevExpress.XtraReports.UI.PageHeaderBand();
            this.xrPageInfo1 = new DevExpress.XtraReports.UI.XRPageInfo();
            this.hdrCompName1 = new DevExpress.XtraReports.UI.XRLabel();
            this.hdrTo1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text5 = new DevExpress.XtraReports.UI.XRLabel();
            this.hdrFm1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text4 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text3 = new DevExpress.XtraReports.UI.XRLabel();
            this.Text2 = new DevExpress.XtraReports.UI.XRLabel();
            this.lblCaption = new DevExpress.XtraReports.UI.XRLabel();
            this.PrintDate1 = new DevExpress.XtraReports.UI.XRLabel();
            this.PageFooter = new DevExpress.XtraReports.UI.PageFooterBand();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            // 
            // Detail
            // 
            this.Detail.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrLine1,
            this.Text22,
            this.GRADE1,
            this.Text20,
            this.Text16,
            this.GROUP1,
            this.VIPNO1,
            this.ADDRESS41,
            this.ADDRESS31,
            this.ADDRESS21,
            this.ADDRESS11,
            this.Text42,
            this.Text41,
            this.R31,
            this.R21,
            this.Text40,
            this.R11,
            this.Text39,
            this.Text38,
            this.Text37,
            this.MEMO1,
            this.PYDISC1,
            this.Text36,
            this.TERMS1,
            this.Text35,
            this.ACREDIT1,
            this.Text34,
            this.Text33,
            this.NATION1,
            this.Text32,
            this.REMARKS1,
            this.Text31,
            this.DATEREGIS1,
            this.Text30,
            this.DATEBIRTH1,
            this.Text29,
            this.Text28,
            this.DATEMIGRATE1,
            this.DATECOMM1,
            this.Text27,
            this.CARDACTIVE1,
            this.Text26,
            this.CARDRECEIVE1,
            this.Text25,
            this.CARDNAME1,
            this.Text24,
            this.CARDEXPIRE1,
            this.Text23,
            this.CARDISSUE1,
            this.SEX1,
            this.Text21,
            this.IDNO1,
            this.EMAIL1,
            this.Text19,
            this.Text18,
            this.Text17,
            this.Text15,
            this.USERLCHG1,
            this.Text14,
            this.Text13,
            this.Text12,
            this.DATELCHG1,
            this.DATECREATE1,
            this.TELP1,
            this.Text11,
            this.Text10,
            this.TELH1,
            this.FAX1,
            this.Text9,
            this.Text8,
            this.TELW1,
            this.Text7,
            this.NNAME1,
            this.FNAME1,
            this.LNAME1,
            this.SALUTE1});
            this.Detail.Height = 509;
            this.Detail.Name = "Detail";
            // 
            // xrLine1
            // 
            this.xrLine1.Location = new System.Drawing.Point(0, 0);
            this.xrLine1.Name = "xrLine1";
            this.xrLine1.Size = new System.Drawing.Size(775, 2);
            // 
            // Text22
            // 
            this.Text22.BackColor = System.Drawing.Color.White;
            this.Text22.BorderColor = System.Drawing.Color.Black;
            this.Text22.CanGrow = false;
            this.Text22.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text22.ForeColor = System.Drawing.Color.Black;
            this.Text22.Location = new System.Drawing.Point(683, 2);
            this.Text22.Name = "Text22";
            this.Text22.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text22.ParentStyleUsing.UseBackColor = false;
            this.Text22.ParentStyleUsing.UseBorderColor = false;
            this.Text22.ParentStyleUsing.UseBorders = false;
            this.Text22.ParentStyleUsing.UseBorderWidth = false;
            this.Text22.ParentStyleUsing.UseFont = false;
            this.Text22.ParentStyleUsing.UseForeColor = false;
            this.Text22.Size = new System.Drawing.Size(58, 12);
            this.Text22.Text = "GRADE :";
            // 
            // GRADE1
            // 
            this.GRADE1.BackColor = System.Drawing.Color.White;
            this.GRADE1.BorderColor = System.Drawing.Color.Black;
            this.GRADE1.CanGrow = false;
            this.GRADE1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.GRADE1.ForeColor = System.Drawing.Color.Black;
            this.GRADE1.Location = new System.Drawing.Point(683, 15);
            this.GRADE1.Name = "GRADE1";
            this.GRADE1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.GRADE1.ParentStyleUsing.UseBackColor = false;
            this.GRADE1.ParentStyleUsing.UseBorderColor = false;
            this.GRADE1.ParentStyleUsing.UseBorders = false;
            this.GRADE1.ParentStyleUsing.UseBorderWidth = false;
            this.GRADE1.ParentStyleUsing.UseFont = false;
            this.GRADE1.ParentStyleUsing.UseForeColor = false;
            this.GRADE1.Size = new System.Drawing.Size(92, 12);
            this.GRADE1.Text = "GRADE1";
            // 
            // Text20
            // 
            this.Text20.BackColor = System.Drawing.Color.White;
            this.Text20.BorderColor = System.Drawing.Color.Black;
            this.Text20.CanGrow = false;
            this.Text20.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text20.ForeColor = System.Drawing.Color.Black;
            this.Text20.Location = new System.Drawing.Point(383, 2);
            this.Text20.Name = "Text20";
            this.Text20.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text20.ParentStyleUsing.UseBackColor = false;
            this.Text20.ParentStyleUsing.UseBorderColor = false;
            this.Text20.ParentStyleUsing.UseBorders = false;
            this.Text20.ParentStyleUsing.UseBorderWidth = false;
            this.Text20.ParentStyleUsing.UseFont = false;
            this.Text20.ParentStyleUsing.UseForeColor = false;
            this.Text20.Size = new System.Drawing.Size(58, 12);
            this.Text20.Text = "GROUP :";
            // 
            // Text16
            // 
            this.Text16.BackColor = System.Drawing.Color.White;
            this.Text16.BorderColor = System.Drawing.Color.Black;
            this.Text16.CanGrow = false;
            this.Text16.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text16.ForeColor = System.Drawing.Color.Black;
            this.Text16.Location = new System.Drawing.Point(0, 2);
            this.Text16.Name = "Text16";
            this.Text16.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text16.ParentStyleUsing.UseBackColor = false;
            this.Text16.ParentStyleUsing.UseBorderColor = false;
            this.Text16.ParentStyleUsing.UseBorders = false;
            this.Text16.ParentStyleUsing.UseBorderWidth = false;
            this.Text16.ParentStyleUsing.UseFont = false;
            this.Text16.ParentStyleUsing.UseForeColor = false;
            this.Text16.Size = new System.Drawing.Size(83, 12);
            this.Text16.Text = "VIPNO :";
            // 
            // GROUP1
            // 
            this.GROUP1.BackColor = System.Drawing.Color.White;
            this.GROUP1.BorderColor = System.Drawing.Color.Black;
            this.GROUP1.CanGrow = false;
            this.GROUP1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.GROUP1.ForeColor = System.Drawing.Color.Black;
            this.GROUP1.Location = new System.Drawing.Point(383, 15);
            this.GROUP1.Name = "GROUP1";
            this.GROUP1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.GROUP1.ParentStyleUsing.UseBackColor = false;
            this.GROUP1.ParentStyleUsing.UseBorderColor = false;
            this.GROUP1.ParentStyleUsing.UseBorders = false;
            this.GROUP1.ParentStyleUsing.UseBorderWidth = false;
            this.GROUP1.ParentStyleUsing.UseFont = false;
            this.GROUP1.ParentStyleUsing.UseForeColor = false;
            this.GROUP1.Size = new System.Drawing.Size(100, 12);
            this.GROUP1.Text = "GROUP1";
            // 
            // VIPNO1
            // 
            this.VIPNO1.BackColor = System.Drawing.Color.White;
            this.VIPNO1.BorderColor = System.Drawing.Color.Black;
            this.VIPNO1.CanGrow = false;
            this.VIPNO1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.VIPNO1.ForeColor = System.Drawing.Color.Black;
            this.VIPNO1.Location = new System.Drawing.Point(0, 15);
            this.VIPNO1.Name = "VIPNO1";
            this.VIPNO1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.VIPNO1.ParentStyleUsing.UseBackColor = false;
            this.VIPNO1.ParentStyleUsing.UseBorderColor = false;
            this.VIPNO1.ParentStyleUsing.UseBorders = false;
            this.VIPNO1.ParentStyleUsing.UseBorderWidth = false;
            this.VIPNO1.ParentStyleUsing.UseFont = false;
            this.VIPNO1.ParentStyleUsing.UseForeColor = false;
            this.VIPNO1.Size = new System.Drawing.Size(91, 12);
            this.VIPNO1.Text = "VIPNO1";
            // 
            // ADDRESS41
            // 
            this.ADDRESS41.BackColor = System.Drawing.Color.White;
            this.ADDRESS41.BorderColor = System.Drawing.Color.Black;
            this.ADDRESS41.CanGrow = false;
            this.ADDRESS41.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.ADDRESS41.ForeColor = System.Drawing.Color.Black;
            this.ADDRESS41.Location = new System.Drawing.Point(125, 144);
            this.ADDRESS41.Name = "ADDRESS41";
            this.ADDRESS41.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.ADDRESS41.ParentStyleUsing.UseBackColor = false;
            this.ADDRESS41.ParentStyleUsing.UseBorderColor = false;
            this.ADDRESS41.ParentStyleUsing.UseBorders = false;
            this.ADDRESS41.ParentStyleUsing.UseBorderWidth = false;
            this.ADDRESS41.ParentStyleUsing.UseFont = false;
            this.ADDRESS41.ParentStyleUsing.UseForeColor = false;
            this.ADDRESS41.Size = new System.Drawing.Size(258, 12);
            this.ADDRESS41.Text = "ADDRESS41";
            // 
            // ADDRESS31
            // 
            this.ADDRESS31.BackColor = System.Drawing.Color.White;
            this.ADDRESS31.BorderColor = System.Drawing.Color.Black;
            this.ADDRESS31.CanGrow = false;
            this.ADDRESS31.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.ADDRESS31.ForeColor = System.Drawing.Color.Black;
            this.ADDRESS31.Location = new System.Drawing.Point(125, 130);
            this.ADDRESS31.Name = "ADDRESS31";
            this.ADDRESS31.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.ADDRESS31.ParentStyleUsing.UseBackColor = false;
            this.ADDRESS31.ParentStyleUsing.UseBorderColor = false;
            this.ADDRESS31.ParentStyleUsing.UseBorders = false;
            this.ADDRESS31.ParentStyleUsing.UseBorderWidth = false;
            this.ADDRESS31.ParentStyleUsing.UseFont = false;
            this.ADDRESS31.ParentStyleUsing.UseForeColor = false;
            this.ADDRESS31.Size = new System.Drawing.Size(258, 12);
            this.ADDRESS31.Text = "ADDRESS31";
            // 
            // ADDRESS21
            // 
            this.ADDRESS21.BackColor = System.Drawing.Color.White;
            this.ADDRESS21.BorderColor = System.Drawing.Color.Black;
            this.ADDRESS21.CanGrow = false;
            this.ADDRESS21.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.ADDRESS21.ForeColor = System.Drawing.Color.Black;
            this.ADDRESS21.Location = new System.Drawing.Point(125, 116);
            this.ADDRESS21.Name = "ADDRESS21";
            this.ADDRESS21.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.ADDRESS21.ParentStyleUsing.UseBackColor = false;
            this.ADDRESS21.ParentStyleUsing.UseBorderColor = false;
            this.ADDRESS21.ParentStyleUsing.UseBorders = false;
            this.ADDRESS21.ParentStyleUsing.UseBorderWidth = false;
            this.ADDRESS21.ParentStyleUsing.UseFont = false;
            this.ADDRESS21.ParentStyleUsing.UseForeColor = false;
            this.ADDRESS21.Size = new System.Drawing.Size(258, 12);
            this.ADDRESS21.Text = "ADDRESS21";
            // 
            // ADDRESS11
            // 
            this.ADDRESS11.BackColor = System.Drawing.Color.White;
            this.ADDRESS11.BorderColor = System.Drawing.Color.Black;
            this.ADDRESS11.CanGrow = false;
            this.ADDRESS11.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.ADDRESS11.ForeColor = System.Drawing.Color.Black;
            this.ADDRESS11.Location = new System.Drawing.Point(125, 101);
            this.ADDRESS11.Name = "ADDRESS11";
            this.ADDRESS11.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.ADDRESS11.ParentStyleUsing.UseBackColor = false;
            this.ADDRESS11.ParentStyleUsing.UseBorderColor = false;
            this.ADDRESS11.ParentStyleUsing.UseBorders = false;
            this.ADDRESS11.ParentStyleUsing.UseBorderWidth = false;
            this.ADDRESS11.ParentStyleUsing.UseFont = false;
            this.ADDRESS11.ParentStyleUsing.UseForeColor = false;
            this.ADDRESS11.Size = new System.Drawing.Size(258, 13);
            this.ADDRESS11.Text = "ADDRESS11";
            // 
            // Text42
            // 
            this.Text42.BackColor = System.Drawing.Color.White;
            this.Text42.BorderColor = System.Drawing.Color.Black;
            this.Text42.CanGrow = false;
            this.Text42.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text42.ForeColor = System.Drawing.Color.Black;
            this.Text42.Location = new System.Drawing.Point(383, 101);
            this.Text42.Name = "Text42";
            this.Text42.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text42.ParentStyleUsing.UseBackColor = false;
            this.Text42.ParentStyleUsing.UseBorderColor = false;
            this.Text42.ParentStyleUsing.UseBorders = false;
            this.Text42.ParentStyleUsing.UseBorderWidth = false;
            this.Text42.ParentStyleUsing.UseFont = false;
            this.Text42.ParentStyleUsing.UseForeColor = false;
            this.Text42.Size = new System.Drawing.Size(133, 12);
            this.Text42.Text = "REMARK2 :";
            // 
            // Text41
            // 
            this.Text41.BackColor = System.Drawing.Color.White;
            this.Text41.BorderColor = System.Drawing.Color.Black;
            this.Text41.CanGrow = false;
            this.Text41.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text41.ForeColor = System.Drawing.Color.Black;
            this.Text41.Location = new System.Drawing.Point(383, 116);
            this.Text41.Name = "Text41";
            this.Text41.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text41.ParentStyleUsing.UseBackColor = false;
            this.Text41.ParentStyleUsing.UseBorderColor = false;
            this.Text41.ParentStyleUsing.UseBorders = false;
            this.Text41.ParentStyleUsing.UseBorderWidth = false;
            this.Text41.ParentStyleUsing.UseFont = false;
            this.Text41.ParentStyleUsing.UseForeColor = false;
            this.Text41.Size = new System.Drawing.Size(133, 12);
            this.Text41.Text = "REMARK3 :";
            // 
            // R31
            // 
            this.R31.BackColor = System.Drawing.Color.White;
            this.R31.BorderColor = System.Drawing.Color.Black;
            this.R31.CanGrow = false;
            this.R31.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.R31.ForeColor = System.Drawing.Color.Black;
            this.R31.Location = new System.Drawing.Point(516, 116);
            this.R31.Name = "R31";
            this.R31.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.R31.ParentStyleUsing.UseBackColor = false;
            this.R31.ParentStyleUsing.UseBorderColor = false;
            this.R31.ParentStyleUsing.UseBorders = false;
            this.R31.ParentStyleUsing.UseBorderWidth = false;
            this.R31.ParentStyleUsing.UseFont = false;
            this.R31.ParentStyleUsing.UseForeColor = false;
            this.R31.Size = new System.Drawing.Size(116, 12);
            // 
            // R21
            // 
            this.R21.BackColor = System.Drawing.Color.White;
            this.R21.BorderColor = System.Drawing.Color.Black;
            this.R21.CanGrow = false;
            this.R21.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.R21.ForeColor = System.Drawing.Color.Black;
            this.R21.Location = new System.Drawing.Point(516, 101);
            this.R21.Name = "R21";
            this.R21.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.R21.ParentStyleUsing.UseBackColor = false;
            this.R21.ParentStyleUsing.UseBorderColor = false;
            this.R21.ParentStyleUsing.UseBorders = false;
            this.R21.ParentStyleUsing.UseBorderWidth = false;
            this.R21.ParentStyleUsing.UseFont = false;
            this.R21.ParentStyleUsing.UseForeColor = false;
            this.R21.Size = new System.Drawing.Size(116, 12);
            // 
            // Text40
            // 
            this.Text40.BackColor = System.Drawing.Color.White;
            this.Text40.BorderColor = System.Drawing.Color.Black;
            this.Text40.CanGrow = false;
            this.Text40.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text40.ForeColor = System.Drawing.Color.Black;
            this.Text40.Location = new System.Drawing.Point(383, 88);
            this.Text40.Name = "Text40";
            this.Text40.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text40.ParentStyleUsing.UseBackColor = false;
            this.Text40.ParentStyleUsing.UseBorderColor = false;
            this.Text40.ParentStyleUsing.UseBorders = false;
            this.Text40.ParentStyleUsing.UseBorderWidth = false;
            this.Text40.ParentStyleUsing.UseFont = false;
            this.Text40.ParentStyleUsing.UseForeColor = false;
            this.Text40.Size = new System.Drawing.Size(133, 12);
            this.Text40.Text = "REMARK1 :";
            // 
            // R11
            // 
            this.R11.BackColor = System.Drawing.Color.White;
            this.R11.BorderColor = System.Drawing.Color.Black;
            this.R11.CanGrow = false;
            this.R11.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.R11.ForeColor = System.Drawing.Color.Black;
            this.R11.Location = new System.Drawing.Point(516, 88);
            this.R11.Name = "R11";
            this.R11.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.R11.ParentStyleUsing.UseBackColor = false;
            this.R11.ParentStyleUsing.UseBorderColor = false;
            this.R11.ParentStyleUsing.UseBorders = false;
            this.R11.ParentStyleUsing.UseBorderWidth = false;
            this.R11.ParentStyleUsing.UseFont = false;
            this.R11.ParentStyleUsing.UseForeColor = false;
            this.R11.Size = new System.Drawing.Size(116, 12);
            // 
            // Text39
            // 
            this.Text39.BackColor = System.Drawing.Color.White;
            this.Text39.BorderColor = System.Drawing.Color.Black;
            this.Text39.CanGrow = false;
            this.Text39.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text39.ForeColor = System.Drawing.Color.Black;
            this.Text39.Location = new System.Drawing.Point(0, 273);
            this.Text39.Name = "Text39";
            this.Text39.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text39.ParentStyleUsing.UseBackColor = false;
            this.Text39.ParentStyleUsing.UseBorderColor = false;
            this.Text39.ParentStyleUsing.UseBorders = false;
            this.Text39.ParentStyleUsing.UseBorderWidth = false;
            this.Text39.ParentStyleUsing.UseFont = false;
            this.Text39.ParentStyleUsing.UseForeColor = false;
            this.Text39.Size = new System.Drawing.Size(125, 12);
            this.Text39.Text = "PAYMENT DISCOUNT :";
            // 
            // Text38
            // 
            this.Text38.BackColor = System.Drawing.Color.White;
            this.Text38.BorderColor = System.Drawing.Color.Black;
            this.Text38.CanGrow = false;
            this.Text38.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text38.ForeColor = System.Drawing.Color.Black;
            this.Text38.Location = new System.Drawing.Point(383, 48);
            this.Text38.Name = "Text38";
            this.Text38.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text38.ParentStyleUsing.UseBackColor = false;
            this.Text38.ParentStyleUsing.UseBorderColor = false;
            this.Text38.ParentStyleUsing.UseBorders = false;
            this.Text38.ParentStyleUsing.UseBorderWidth = false;
            this.Text38.ParentStyleUsing.UseFont = false;
            this.Text38.ParentStyleUsing.UseForeColor = false;
            this.Text38.Size = new System.Drawing.Size(133, 12);
            this.Text38.Text = "SEX :";
            // 
            // Text37
            // 
            this.Text37.BackColor = System.Drawing.Color.White;
            this.Text37.BorderColor = System.Drawing.Color.Black;
            this.Text37.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text37.ForeColor = System.Drawing.Color.Black;
            this.Text37.Location = new System.Drawing.Point(0, 371);
            this.Text37.Name = "Text37";
            this.Text37.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text37.ParentStyleUsing.UseBackColor = false;
            this.Text37.ParentStyleUsing.UseBorderColor = false;
            this.Text37.ParentStyleUsing.UseBorders = false;
            this.Text37.ParentStyleUsing.UseBorderWidth = false;
            this.Text37.ParentStyleUsing.UseFont = false;
            this.Text37.ParentStyleUsing.UseForeColor = false;
            this.Text37.Size = new System.Drawing.Size(129, 12);
            this.Text37.Text = "MEMO :";
            // 
            // MEMO1
            // 
            this.MEMO1.BackColor = System.Drawing.Color.White;
            this.MEMO1.BorderColor = System.Drawing.Color.Black;
            this.MEMO1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.MEMO1.ForeColor = System.Drawing.Color.Black;
            this.MEMO1.Location = new System.Drawing.Point(0, 383);
            this.MEMO1.Name = "MEMO1";
            this.MEMO1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.MEMO1.ParentStyleUsing.UseBackColor = false;
            this.MEMO1.ParentStyleUsing.UseBorderColor = false;
            this.MEMO1.ParentStyleUsing.UseBorders = false;
            this.MEMO1.ParentStyleUsing.UseBorderWidth = false;
            this.MEMO1.ParentStyleUsing.UseFont = false;
            this.MEMO1.ParentStyleUsing.UseForeColor = false;
            this.MEMO1.Size = new System.Drawing.Size(498, 12);
            // 
            // PYDISC1
            // 
            this.PYDISC1.BackColor = System.Drawing.Color.White;
            this.PYDISC1.BorderColor = System.Drawing.Color.Black;
            this.PYDISC1.CanGrow = false;
            this.PYDISC1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.PYDISC1.ForeColor = System.Drawing.Color.Black;
            this.PYDISC1.Location = new System.Drawing.Point(125, 273);
            this.PYDISC1.Name = "PYDISC1";
            this.PYDISC1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.PYDISC1.ParentStyleUsing.UseBackColor = false;
            this.PYDISC1.ParentStyleUsing.UseBorderColor = false;
            this.PYDISC1.ParentStyleUsing.UseBorders = false;
            this.PYDISC1.ParentStyleUsing.UseBorderWidth = false;
            this.PYDISC1.ParentStyleUsing.UseFont = false;
            this.PYDISC1.ParentStyleUsing.UseForeColor = false;
            this.PYDISC1.Size = new System.Drawing.Size(87, 12);
            // 
            // Text36
            // 
            this.Text36.BackColor = System.Drawing.Color.White;
            this.Text36.BorderColor = System.Drawing.Color.Black;
            this.Text36.CanGrow = false;
            this.Text36.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text36.ForeColor = System.Drawing.Color.Black;
            this.Text36.Location = new System.Drawing.Point(0, 301);
            this.Text36.Name = "Text36";
            this.Text36.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text36.ParentStyleUsing.UseBackColor = false;
            this.Text36.ParentStyleUsing.UseBorderColor = false;
            this.Text36.ParentStyleUsing.UseBorders = false;
            this.Text36.ParentStyleUsing.UseBorderWidth = false;
            this.Text36.ParentStyleUsing.UseFont = false;
            this.Text36.ParentStyleUsing.UseForeColor = false;
            this.Text36.Size = new System.Drawing.Size(125, 12);
            this.Text36.Text = "CREDIT TERMS :";
            // 
            // TERMS1
            // 
            this.TERMS1.BackColor = System.Drawing.Color.White;
            this.TERMS1.BorderColor = System.Drawing.Color.Black;
            this.TERMS1.CanGrow = false;
            this.TERMS1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.TERMS1.ForeColor = System.Drawing.Color.Black;
            this.TERMS1.Location = new System.Drawing.Point(125, 301);
            this.TERMS1.Name = "TERMS1";
            this.TERMS1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.TERMS1.ParentStyleUsing.UseBackColor = false;
            this.TERMS1.ParentStyleUsing.UseBorderColor = false;
            this.TERMS1.ParentStyleUsing.UseBorders = false;
            this.TERMS1.ParentStyleUsing.UseBorderWidth = false;
            this.TERMS1.ParentStyleUsing.UseFont = false;
            this.TERMS1.ParentStyleUsing.UseForeColor = false;
            this.TERMS1.Size = new System.Drawing.Size(88, 12);
            // 
            // Text35
            // 
            this.Text35.BackColor = System.Drawing.Color.White;
            this.Text35.BorderColor = System.Drawing.Color.Black;
            this.Text35.CanGrow = false;
            this.Text35.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text35.ForeColor = System.Drawing.Color.Black;
            this.Text35.Location = new System.Drawing.Point(0, 287);
            this.Text35.Name = "Text35";
            this.Text35.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text35.ParentStyleUsing.UseBackColor = false;
            this.Text35.ParentStyleUsing.UseBorderColor = false;
            this.Text35.ParentStyleUsing.UseBorders = false;
            this.Text35.ParentStyleUsing.UseBorderWidth = false;
            this.Text35.ParentStyleUsing.UseFont = false;
            this.Text35.ParentStyleUsing.UseForeColor = false;
            this.Text35.Size = new System.Drawing.Size(125, 12);
            this.Text35.Text = "CREDIT LIMIT :";
            // 
            // ACREDIT1
            // 
            this.ACREDIT1.BackColor = System.Drawing.Color.White;
            this.ACREDIT1.BorderColor = System.Drawing.Color.Black;
            this.ACREDIT1.CanGrow = false;
            this.ACREDIT1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.ACREDIT1.ForeColor = System.Drawing.Color.Black;
            this.ACREDIT1.Location = new System.Drawing.Point(125, 287);
            this.ACREDIT1.Name = "ACREDIT1";
            this.ACREDIT1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.ACREDIT1.ParentStyleUsing.UseBackColor = false;
            this.ACREDIT1.ParentStyleUsing.UseBorderColor = false;
            this.ACREDIT1.ParentStyleUsing.UseBorders = false;
            this.ACREDIT1.ParentStyleUsing.UseBorderWidth = false;
            this.ACREDIT1.ParentStyleUsing.UseFont = false;
            this.ACREDIT1.ParentStyleUsing.UseForeColor = false;
            this.ACREDIT1.Size = new System.Drawing.Size(87, 12);
            // 
            // Text34
            // 
            this.Text34.BackColor = System.Drawing.Color.White;
            this.Text34.BorderColor = System.Drawing.Color.Black;
            this.Text34.CanGrow = false;
            this.Text34.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text34.ForeColor = System.Drawing.Color.Black;
            this.Text34.Location = new System.Drawing.Point(0, 213);
            this.Text34.Name = "Text34";
            this.Text34.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text34.ParentStyleUsing.UseBackColor = false;
            this.Text34.ParentStyleUsing.UseBorderColor = false;
            this.Text34.ParentStyleUsing.UseBorders = false;
            this.Text34.ParentStyleUsing.UseBorderWidth = false;
            this.Text34.ParentStyleUsing.UseFont = false;
            this.Text34.ParentStyleUsing.UseForeColor = false;
            this.Text34.Size = new System.Drawing.Size(125, 12);
            this.Text34.Text = "PAGER  :";
            // 
            // Text33
            // 
            this.Text33.BackColor = System.Drawing.Color.White;
            this.Text33.BorderColor = System.Drawing.Color.Black;
            this.Text33.CanGrow = false;
            this.Text33.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text33.ForeColor = System.Drawing.Color.Black;
            this.Text33.Location = new System.Drawing.Point(383, 75);
            this.Text33.Name = "Text33";
            this.Text33.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text33.ParentStyleUsing.UseBackColor = false;
            this.Text33.ParentStyleUsing.UseBorderColor = false;
            this.Text33.ParentStyleUsing.UseBorders = false;
            this.Text33.ParentStyleUsing.UseBorderWidth = false;
            this.Text33.ParentStyleUsing.UseFont = false;
            this.Text33.ParentStyleUsing.UseForeColor = false;
            this.Text33.Size = new System.Drawing.Size(133, 12);
            this.Text33.Text = "NATIONALITY :";
            // 
            // NATION1
            // 
            this.NATION1.BackColor = System.Drawing.Color.White;
            this.NATION1.BorderColor = System.Drawing.Color.Black;
            this.NATION1.CanGrow = false;
            this.NATION1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.NATION1.ForeColor = System.Drawing.Color.Black;
            this.NATION1.Location = new System.Drawing.Point(516, 75);
            this.NATION1.Name = "NATION1";
            this.NATION1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.NATION1.ParentStyleUsing.UseBackColor = false;
            this.NATION1.ParentStyleUsing.UseBorderColor = false;
            this.NATION1.ParentStyleUsing.UseBorders = false;
            this.NATION1.ParentStyleUsing.UseBorderWidth = false;
            this.NATION1.ParentStyleUsing.UseFont = false;
            this.NATION1.ParentStyleUsing.UseForeColor = false;
            this.NATION1.Size = new System.Drawing.Size(237, 12);
            // 
            // Text32
            // 
            this.Text32.BackColor = System.Drawing.Color.White;
            this.Text32.BorderColor = System.Drawing.Color.Black;
            this.Text32.CanGrow = false;
            this.Text32.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text32.ForeColor = System.Drawing.Color.Black;
            this.Text32.Location = new System.Drawing.Point(0, 241);
            this.Text32.Name = "Text32";
            this.Text32.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text32.ParentStyleUsing.UseBackColor = false;
            this.Text32.ParentStyleUsing.UseBorderColor = false;
            this.Text32.ParentStyleUsing.UseBorders = false;
            this.Text32.ParentStyleUsing.UseBorderWidth = false;
            this.Text32.ParentStyleUsing.UseFont = false;
            this.Text32.ParentStyleUsing.UseForeColor = false;
            this.Text32.Size = new System.Drawing.Size(125, 12);
            this.Text32.Text = "REMARKS :";
            // 
            // REMARKS1
            // 
            this.REMARKS1.BackColor = System.Drawing.Color.White;
            this.REMARKS1.BorderColor = System.Drawing.Color.Black;
            this.REMARKS1.CanGrow = false;
            this.REMARKS1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.REMARKS1.ForeColor = System.Drawing.Color.Black;
            this.REMARKS1.Location = new System.Drawing.Point(125, 241);
            this.REMARKS1.Name = "REMARKS1";
            this.REMARKS1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.REMARKS1.ParentStyleUsing.UseBackColor = false;
            this.REMARKS1.ParentStyleUsing.UseBorderColor = false;
            this.REMARKS1.ParentStyleUsing.UseBorders = false;
            this.REMARKS1.ParentStyleUsing.UseBorderWidth = false;
            this.REMARKS1.ParentStyleUsing.UseFont = false;
            this.REMARKS1.ParentStyleUsing.UseForeColor = false;
            this.REMARKS1.Size = new System.Drawing.Size(258, 12);
            // 
            // Text31
            // 
            this.Text31.BackColor = System.Drawing.Color.White;
            this.Text31.BorderColor = System.Drawing.Color.Black;
            this.Text31.CanGrow = false;
            this.Text31.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text31.ForeColor = System.Drawing.Color.Black;
            this.Text31.Location = new System.Drawing.Point(383, 159);
            this.Text31.Name = "Text31";
            this.Text31.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text31.ParentStyleUsing.UseBackColor = false;
            this.Text31.ParentStyleUsing.UseBorderColor = false;
            this.Text31.ParentStyleUsing.UseBorders = false;
            this.Text31.ParentStyleUsing.UseBorderWidth = false;
            this.Text31.ParentStyleUsing.UseFont = false;
            this.Text31.ParentStyleUsing.UseForeColor = false;
            this.Text31.Size = new System.Drawing.Size(133, 12);
            this.Text31.Text = "DATE OF REGISTER :";
            // 
            // DATEREGIS1
            // 
            this.DATEREGIS1.BackColor = System.Drawing.Color.White;
            this.DATEREGIS1.BorderColor = System.Drawing.Color.Black;
            this.DATEREGIS1.CanGrow = false;
            this.DATEREGIS1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.DATEREGIS1.ForeColor = System.Drawing.Color.Black;
            this.DATEREGIS1.Location = new System.Drawing.Point(516, 159);
            this.DATEREGIS1.Name = "DATEREGIS1";
            this.DATEREGIS1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.DATEREGIS1.ParentStyleUsing.UseBackColor = false;
            this.DATEREGIS1.ParentStyleUsing.UseBorderColor = false;
            this.DATEREGIS1.ParentStyleUsing.UseBorders = false;
            this.DATEREGIS1.ParentStyleUsing.UseBorderWidth = false;
            this.DATEREGIS1.ParentStyleUsing.UseFont = false;
            this.DATEREGIS1.ParentStyleUsing.UseForeColor = false;
            this.DATEREGIS1.Size = new System.Drawing.Size(116, 12);
            // 
            // Text30
            // 
            this.Text30.BackColor = System.Drawing.Color.White;
            this.Text30.BorderColor = System.Drawing.Color.Black;
            this.Text30.CanGrow = false;
            this.Text30.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text30.ForeColor = System.Drawing.Color.Black;
            this.Text30.Location = new System.Drawing.Point(383, 144);
            this.Text30.Name = "Text30";
            this.Text30.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text30.ParentStyleUsing.UseBackColor = false;
            this.Text30.ParentStyleUsing.UseBorderColor = false;
            this.Text30.ParentStyleUsing.UseBorders = false;
            this.Text30.ParentStyleUsing.UseBorderWidth = false;
            this.Text30.ParentStyleUsing.UseFont = false;
            this.Text30.ParentStyleUsing.UseForeColor = false;
            this.Text30.Size = new System.Drawing.Size(133, 12);
            this.Text30.Text = "DATE OF BIRTH :";
            // 
            // DATEBIRTH1
            // 
            this.DATEBIRTH1.BackColor = System.Drawing.Color.White;
            this.DATEBIRTH1.BorderColor = System.Drawing.Color.Black;
            this.DATEBIRTH1.CanGrow = false;
            this.DATEBIRTH1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.DATEBIRTH1.ForeColor = System.Drawing.Color.Black;
            this.DATEBIRTH1.Location = new System.Drawing.Point(516, 144);
            this.DATEBIRTH1.Name = "DATEBIRTH1";
            this.DATEBIRTH1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.DATEBIRTH1.ParentStyleUsing.UseBackColor = false;
            this.DATEBIRTH1.ParentStyleUsing.UseBorderColor = false;
            this.DATEBIRTH1.ParentStyleUsing.UseBorders = false;
            this.DATEBIRTH1.ParentStyleUsing.UseBorderWidth = false;
            this.DATEBIRTH1.ParentStyleUsing.UseFont = false;
            this.DATEBIRTH1.ParentStyleUsing.UseForeColor = false;
            this.DATEBIRTH1.Size = new System.Drawing.Size(116, 12);
            // 
            // Text29
            // 
            this.Text29.BackColor = System.Drawing.Color.White;
            this.Text29.BorderColor = System.Drawing.Color.Black;
            this.Text29.CanGrow = false;
            this.Text29.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text29.ForeColor = System.Drawing.Color.Black;
            this.Text29.Location = new System.Drawing.Point(383, 175);
            this.Text29.Name = "Text29";
            this.Text29.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text29.ParentStyleUsing.UseBackColor = false;
            this.Text29.ParentStyleUsing.UseBorderColor = false;
            this.Text29.ParentStyleUsing.UseBorders = false;
            this.Text29.ParentStyleUsing.UseBorderWidth = false;
            this.Text29.ParentStyleUsing.UseFont = false;
            this.Text29.ParentStyleUsing.UseForeColor = false;
            this.Text29.Size = new System.Drawing.Size(133, 12);
            this.Text29.Text = "COMMENCEMENT DATE :";
            // 
            // Text28
            // 
            this.Text28.BackColor = System.Drawing.Color.White;
            this.Text28.BorderColor = System.Drawing.Color.Black;
            this.Text28.CanGrow = false;
            this.Text28.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text28.ForeColor = System.Drawing.Color.Black;
            this.Text28.Location = new System.Drawing.Point(383, 190);
            this.Text28.Name = "Text28";
            this.Text28.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text28.ParentStyleUsing.UseBackColor = false;
            this.Text28.ParentStyleUsing.UseBorderColor = false;
            this.Text28.ParentStyleUsing.UseBorders = false;
            this.Text28.ParentStyleUsing.UseBorderWidth = false;
            this.Text28.ParentStyleUsing.UseFont = false;
            this.Text28.ParentStyleUsing.UseForeColor = false;
            this.Text28.Size = new System.Drawing.Size(133, 12);
            this.Text28.Text = "MIGRATION DATE :";
            // 
            // DATEMIGRATE1
            // 
            this.DATEMIGRATE1.BackColor = System.Drawing.Color.White;
            this.DATEMIGRATE1.BorderColor = System.Drawing.Color.Black;
            this.DATEMIGRATE1.CanGrow = false;
            this.DATEMIGRATE1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.DATEMIGRATE1.ForeColor = System.Drawing.Color.Black;
            this.DATEMIGRATE1.Location = new System.Drawing.Point(516, 190);
            this.DATEMIGRATE1.Name = "DATEMIGRATE1";
            this.DATEMIGRATE1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.DATEMIGRATE1.ParentStyleUsing.UseBackColor = false;
            this.DATEMIGRATE1.ParentStyleUsing.UseBorderColor = false;
            this.DATEMIGRATE1.ParentStyleUsing.UseBorders = false;
            this.DATEMIGRATE1.ParentStyleUsing.UseBorderWidth = false;
            this.DATEMIGRATE1.ParentStyleUsing.UseFont = false;
            this.DATEMIGRATE1.ParentStyleUsing.UseForeColor = false;
            this.DATEMIGRATE1.Size = new System.Drawing.Size(116, 12);
            // 
            // DATECOMM1
            // 
            this.DATECOMM1.BackColor = System.Drawing.Color.White;
            this.DATECOMM1.BorderColor = System.Drawing.Color.Black;
            this.DATECOMM1.CanGrow = false;
            this.DATECOMM1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.DATECOMM1.ForeColor = System.Drawing.Color.Black;
            this.DATECOMM1.Location = new System.Drawing.Point(516, 175);
            this.DATECOMM1.Name = "DATECOMM1";
            this.DATECOMM1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.DATECOMM1.ParentStyleUsing.UseBackColor = false;
            this.DATECOMM1.ParentStyleUsing.UseBorderColor = false;
            this.DATECOMM1.ParentStyleUsing.UseBorders = false;
            this.DATECOMM1.ParentStyleUsing.UseBorderWidth = false;
            this.DATECOMM1.ParentStyleUsing.UseFont = false;
            this.DATECOMM1.ParentStyleUsing.UseForeColor = false;
            this.DATECOMM1.Size = new System.Drawing.Size(116, 12);
            // 
            // Text27
            // 
            this.Text27.BackColor = System.Drawing.Color.White;
            this.Text27.BorderColor = System.Drawing.Color.Black;
            this.Text27.CanGrow = false;
            this.Text27.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text27.ForeColor = System.Drawing.Color.Black;
            this.Text27.Location = new System.Drawing.Point(383, 287);
            this.Text27.Name = "Text27";
            this.Text27.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text27.ParentStyleUsing.UseBackColor = false;
            this.Text27.ParentStyleUsing.UseBorderColor = false;
            this.Text27.ParentStyleUsing.UseBorders = false;
            this.Text27.ParentStyleUsing.UseBorderWidth = false;
            this.Text27.ParentStyleUsing.UseFont = false;
            this.Text27.ParentStyleUsing.UseForeColor = false;
            this.Text27.Size = new System.Drawing.Size(133, 12);
            this.Text27.Text = "CARD ACTIVE :";
            // 
            // CARDACTIVE1
            // 
            this.CARDACTIVE1.BackColor = System.Drawing.Color.White;
            this.CARDACTIVE1.BorderColor = System.Drawing.Color.Black;
            this.CARDACTIVE1.CanGrow = false;
            this.CARDACTIVE1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.CARDACTIVE1.ForeColor = System.Drawing.Color.Black;
            this.CARDACTIVE1.Location = new System.Drawing.Point(516, 287);
            this.CARDACTIVE1.Name = "CARDACTIVE1";
            this.CARDACTIVE1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.CARDACTIVE1.ParentStyleUsing.UseBackColor = false;
            this.CARDACTIVE1.ParentStyleUsing.UseBorderColor = false;
            this.CARDACTIVE1.ParentStyleUsing.UseBorders = false;
            this.CARDACTIVE1.ParentStyleUsing.UseBorderWidth = false;
            this.CARDACTIVE1.ParentStyleUsing.UseFont = false;
            this.CARDACTIVE1.ParentStyleUsing.UseForeColor = false;
            this.CARDACTIVE1.Size = new System.Drawing.Size(116, 12);
            // 
            // Text26
            // 
            this.Text26.BackColor = System.Drawing.Color.White;
            this.Text26.BorderColor = System.Drawing.Color.Black;
            this.Text26.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text26.ForeColor = System.Drawing.Color.Black;
            this.Text26.Location = new System.Drawing.Point(383, 272);
            this.Text26.Name = "Text26";
            this.Text26.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text26.ParentStyleUsing.UseBackColor = false;
            this.Text26.ParentStyleUsing.UseBorderColor = false;
            this.Text26.ParentStyleUsing.UseBorders = false;
            this.Text26.ParentStyleUsing.UseBorderWidth = false;
            this.Text26.ParentStyleUsing.UseFont = false;
            this.Text26.ParentStyleUsing.UseForeColor = false;
            this.Text26.Size = new System.Drawing.Size(133, 12);
            this.Text26.Text = "CARD RECEIVE :";
            // 
            // CARDRECEIVE1
            // 
            this.CARDRECEIVE1.BackColor = System.Drawing.Color.White;
            this.CARDRECEIVE1.BorderColor = System.Drawing.Color.Black;
            this.CARDRECEIVE1.CanGrow = false;
            this.CARDRECEIVE1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.CARDRECEIVE1.ForeColor = System.Drawing.Color.Black;
            this.CARDRECEIVE1.Location = new System.Drawing.Point(516, 272);
            this.CARDRECEIVE1.Name = "CARDRECEIVE1";
            this.CARDRECEIVE1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.CARDRECEIVE1.ParentStyleUsing.UseBackColor = false;
            this.CARDRECEIVE1.ParentStyleUsing.UseBorderColor = false;
            this.CARDRECEIVE1.ParentStyleUsing.UseBorders = false;
            this.CARDRECEIVE1.ParentStyleUsing.UseBorderWidth = false;
            this.CARDRECEIVE1.ParentStyleUsing.UseFont = false;
            this.CARDRECEIVE1.ParentStyleUsing.UseForeColor = false;
            this.CARDRECEIVE1.Size = new System.Drawing.Size(116, 12);
            // 
            // Text25
            // 
            this.Text25.BackColor = System.Drawing.Color.White;
            this.Text25.BorderColor = System.Drawing.Color.Black;
            this.Text25.CanGrow = false;
            this.Text25.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text25.ForeColor = System.Drawing.Color.Black;
            this.Text25.Location = new System.Drawing.Point(383, 227);
            this.Text25.Name = "Text25";
            this.Text25.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text25.ParentStyleUsing.UseBackColor = false;
            this.Text25.ParentStyleUsing.UseBorderColor = false;
            this.Text25.ParentStyleUsing.UseBorders = false;
            this.Text25.ParentStyleUsing.UseBorderWidth = false;
            this.Text25.ParentStyleUsing.UseFont = false;
            this.Text25.ParentStyleUsing.UseForeColor = false;
            this.Text25.Size = new System.Drawing.Size(133, 12);
            this.Text25.Text = "CARD NAME :";
            // 
            // CARDNAME1
            // 
            this.CARDNAME1.BackColor = System.Drawing.Color.White;
            this.CARDNAME1.BorderColor = System.Drawing.Color.Black;
            this.CARDNAME1.CanGrow = false;
            this.CARDNAME1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.CARDNAME1.ForeColor = System.Drawing.Color.Black;
            this.CARDNAME1.Location = new System.Drawing.Point(516, 227);
            this.CARDNAME1.Name = "CARDNAME1";
            this.CARDNAME1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.CARDNAME1.ParentStyleUsing.UseBackColor = false;
            this.CARDNAME1.ParentStyleUsing.UseBorderColor = false;
            this.CARDNAME1.ParentStyleUsing.UseBorders = false;
            this.CARDNAME1.ParentStyleUsing.UseBorderWidth = false;
            this.CARDNAME1.ParentStyleUsing.UseFont = false;
            this.CARDNAME1.ParentStyleUsing.UseForeColor = false;
            this.CARDNAME1.Size = new System.Drawing.Size(250, 12);
            // 
            // Text24
            // 
            this.Text24.BackColor = System.Drawing.Color.White;
            this.Text24.BorderColor = System.Drawing.Color.Black;
            this.Text24.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text24.ForeColor = System.Drawing.Color.Black;
            this.Text24.Location = new System.Drawing.Point(383, 257);
            this.Text24.Name = "Text24";
            this.Text24.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text24.ParentStyleUsing.UseBackColor = false;
            this.Text24.ParentStyleUsing.UseBorderColor = false;
            this.Text24.ParentStyleUsing.UseBorders = false;
            this.Text24.ParentStyleUsing.UseBorderWidth = false;
            this.Text24.ParentStyleUsing.UseFont = false;
            this.Text24.ParentStyleUsing.UseForeColor = false;
            this.Text24.Size = new System.Drawing.Size(133, 12);
            this.Text24.Text = "CARD EXPIRE DATE :";
            // 
            // CARDEXPIRE1
            // 
            this.CARDEXPIRE1.BackColor = System.Drawing.Color.White;
            this.CARDEXPIRE1.BorderColor = System.Drawing.Color.Black;
            this.CARDEXPIRE1.CanGrow = false;
            this.CARDEXPIRE1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.CARDEXPIRE1.ForeColor = System.Drawing.Color.Black;
            this.CARDEXPIRE1.Location = new System.Drawing.Point(516, 257);
            this.CARDEXPIRE1.Name = "CARDEXPIRE1";
            this.CARDEXPIRE1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.CARDEXPIRE1.ParentStyleUsing.UseBackColor = false;
            this.CARDEXPIRE1.ParentStyleUsing.UseBorderColor = false;
            this.CARDEXPIRE1.ParentStyleUsing.UseBorders = false;
            this.CARDEXPIRE1.ParentStyleUsing.UseBorderWidth = false;
            this.CARDEXPIRE1.ParentStyleUsing.UseFont = false;
            this.CARDEXPIRE1.ParentStyleUsing.UseForeColor = false;
            this.CARDEXPIRE1.Size = new System.Drawing.Size(116, 12);
            // 
            // Text23
            // 
            this.Text23.BackColor = System.Drawing.Color.White;
            this.Text23.BorderColor = System.Drawing.Color.Black;
            this.Text23.CanGrow = false;
            this.Text23.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text23.ForeColor = System.Drawing.Color.Black;
            this.Text23.Location = new System.Drawing.Point(383, 242);
            this.Text23.Name = "Text23";
            this.Text23.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text23.ParentStyleUsing.UseBackColor = false;
            this.Text23.ParentStyleUsing.UseBorderColor = false;
            this.Text23.ParentStyleUsing.UseBorders = false;
            this.Text23.ParentStyleUsing.UseBorderWidth = false;
            this.Text23.ParentStyleUsing.UseFont = false;
            this.Text23.ParentStyleUsing.UseForeColor = false;
            this.Text23.Size = new System.Drawing.Size(133, 12);
            this.Text23.Text = "CARD ISSUE DATE :";
            // 
            // CARDISSUE1
            // 
            this.CARDISSUE1.BackColor = System.Drawing.Color.White;
            this.CARDISSUE1.BorderColor = System.Drawing.Color.Black;
            this.CARDISSUE1.CanGrow = false;
            this.CARDISSUE1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.CARDISSUE1.ForeColor = System.Drawing.Color.Black;
            this.CARDISSUE1.Location = new System.Drawing.Point(516, 242);
            this.CARDISSUE1.Name = "CARDISSUE1";
            this.CARDISSUE1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.CARDISSUE1.ParentStyleUsing.UseBackColor = false;
            this.CARDISSUE1.ParentStyleUsing.UseBorderColor = false;
            this.CARDISSUE1.ParentStyleUsing.UseBorders = false;
            this.CARDISSUE1.ParentStyleUsing.UseBorderWidth = false;
            this.CARDISSUE1.ParentStyleUsing.UseFont = false;
            this.CARDISSUE1.ParentStyleUsing.UseForeColor = false;
            this.CARDISSUE1.Size = new System.Drawing.Size(116, 12);
            // 
            // SEX1
            // 
            this.SEX1.BackColor = System.Drawing.Color.White;
            this.SEX1.BorderColor = System.Drawing.Color.Black;
            this.SEX1.CanGrow = false;
            this.SEX1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.SEX1.ForeColor = System.Drawing.Color.Black;
            this.SEX1.Location = new System.Drawing.Point(516, 48);
            this.SEX1.Name = "SEX1";
            this.SEX1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.SEX1.ParentStyleUsing.UseBackColor = false;
            this.SEX1.ParentStyleUsing.UseBorderColor = false;
            this.SEX1.ParentStyleUsing.UseBorders = false;
            this.SEX1.ParentStyleUsing.UseBorderWidth = false;
            this.SEX1.ParentStyleUsing.UseFont = false;
            this.SEX1.ParentStyleUsing.UseForeColor = false;
            this.SEX1.Size = new System.Drawing.Size(18, 12);
            // 
            // Text21
            // 
            this.Text21.BackColor = System.Drawing.Color.White;
            this.Text21.BorderColor = System.Drawing.Color.Black;
            this.Text21.CanGrow = false;
            this.Text21.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text21.ForeColor = System.Drawing.Color.Black;
            this.Text21.Location = new System.Drawing.Point(383, 61);
            this.Text21.Name = "Text21";
            this.Text21.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text21.ParentStyleUsing.UseBackColor = false;
            this.Text21.ParentStyleUsing.UseBorderColor = false;
            this.Text21.ParentStyleUsing.UseBorders = false;
            this.Text21.ParentStyleUsing.UseBorderWidth = false;
            this.Text21.ParentStyleUsing.UseFont = false;
            this.Text21.ParentStyleUsing.UseForeColor = false;
            this.Text21.Size = new System.Drawing.Size(133, 12);
            this.Text21.Text = "HKID NO :";
            // 
            // IDNO1
            // 
            this.IDNO1.BackColor = System.Drawing.Color.White;
            this.IDNO1.BorderColor = System.Drawing.Color.Black;
            this.IDNO1.CanGrow = false;
            this.IDNO1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.IDNO1.ForeColor = System.Drawing.Color.Black;
            this.IDNO1.Location = new System.Drawing.Point(516, 61);
            this.IDNO1.Name = "IDNO1";
            this.IDNO1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.IDNO1.ParentStyleUsing.UseBackColor = false;
            this.IDNO1.ParentStyleUsing.UseBorderColor = false;
            this.IDNO1.ParentStyleUsing.UseBorders = false;
            this.IDNO1.ParentStyleUsing.UseBorderWidth = false;
            this.IDNO1.ParentStyleUsing.UseFont = false;
            this.IDNO1.ParentStyleUsing.UseForeColor = false;
            this.IDNO1.Size = new System.Drawing.Size(237, 11);
            // 
            // EMAIL1
            // 
            this.EMAIL1.BackColor = System.Drawing.Color.White;
            this.EMAIL1.BorderColor = System.Drawing.Color.Black;
            this.EMAIL1.CanGrow = false;
            this.EMAIL1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.EMAIL1.ForeColor = System.Drawing.Color.Black;
            this.EMAIL1.Location = new System.Drawing.Point(125, 170);
            this.EMAIL1.Name = "EMAIL1";
            this.EMAIL1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.EMAIL1.ParentStyleUsing.UseBackColor = false;
            this.EMAIL1.ParentStyleUsing.UseBorderColor = false;
            this.EMAIL1.ParentStyleUsing.UseBorders = false;
            this.EMAIL1.ParentStyleUsing.UseBorderWidth = false;
            this.EMAIL1.ParentStyleUsing.UseFont = false;
            this.EMAIL1.ParentStyleUsing.UseForeColor = false;
            this.EMAIL1.Size = new System.Drawing.Size(258, 12);
            // 
            // Text19
            // 
            this.Text19.BackColor = System.Drawing.Color.White;
            this.Text19.BorderColor = System.Drawing.Color.Black;
            this.Text19.CanGrow = false;
            this.Text19.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text19.ForeColor = System.Drawing.Color.Black;
            this.Text19.Location = new System.Drawing.Point(0, 88);
            this.Text19.Name = "Text19";
            this.Text19.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text19.ParentStyleUsing.UseBackColor = false;
            this.Text19.ParentStyleUsing.UseBorderColor = false;
            this.Text19.ParentStyleUsing.UseBorders = false;
            this.Text19.ParentStyleUsing.UseBorderWidth = false;
            this.Text19.ParentStyleUsing.UseFont = false;
            this.Text19.ParentStyleUsing.UseForeColor = false;
            this.Text19.Size = new System.Drawing.Size(125, 12);
            this.Text19.Text = "LAST NAME :";
            // 
            // Text18
            // 
            this.Text18.BackColor = System.Drawing.Color.White;
            this.Text18.BorderColor = System.Drawing.Color.Black;
            this.Text18.CanGrow = false;
            this.Text18.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text18.ForeColor = System.Drawing.Color.Black;
            this.Text18.Location = new System.Drawing.Point(0, 75);
            this.Text18.Name = "Text18";
            this.Text18.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text18.ParentStyleUsing.UseBackColor = false;
            this.Text18.ParentStyleUsing.UseBorderColor = false;
            this.Text18.ParentStyleUsing.UseBorders = false;
            this.Text18.ParentStyleUsing.UseBorderWidth = false;
            this.Text18.ParentStyleUsing.UseFont = false;
            this.Text18.ParentStyleUsing.UseForeColor = false;
            this.Text18.Size = new System.Drawing.Size(125, 12);
            this.Text18.Text = "FIRST NAME :";
            // 
            // Text17
            // 
            this.Text17.BackColor = System.Drawing.Color.White;
            this.Text17.BorderColor = System.Drawing.Color.Black;
            this.Text17.CanGrow = false;
            this.Text17.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text17.ForeColor = System.Drawing.Color.Black;
            this.Text17.Location = new System.Drawing.Point(0, 47);
            this.Text17.Name = "Text17";
            this.Text17.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text17.ParentStyleUsing.UseBackColor = false;
            this.Text17.ParentStyleUsing.UseBorderColor = false;
            this.Text17.ParentStyleUsing.UseBorders = false;
            this.Text17.ParentStyleUsing.UseBorderWidth = false;
            this.Text17.ParentStyleUsing.UseFont = false;
            this.Text17.ParentStyleUsing.UseForeColor = false;
            this.Text17.Size = new System.Drawing.Size(125, 12);
            this.Text17.Text = "SALUTE :";
            // 
            // Text15
            // 
            this.Text15.BackColor = System.Drawing.Color.White;
            this.Text15.BorderColor = System.Drawing.Color.Black;
            this.Text15.CanGrow = false;
            this.Text15.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text15.ForeColor = System.Drawing.Color.Black;
            this.Text15.Location = new System.Drawing.Point(0, 61);
            this.Text15.Name = "Text15";
            this.Text15.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text15.ParentStyleUsing.UseBackColor = false;
            this.Text15.ParentStyleUsing.UseBorderColor = false;
            this.Text15.ParentStyleUsing.UseBorders = false;
            this.Text15.ParentStyleUsing.UseBorderWidth = false;
            this.Text15.ParentStyleUsing.UseFont = false;
            this.Text15.ParentStyleUsing.UseForeColor = false;
            this.Text15.Size = new System.Drawing.Size(125, 12);
            this.Text15.Text = "NICK NAME :";
            // 
            // USERLCHG1
            // 
            this.USERLCHG1.BackColor = System.Drawing.Color.White;
            this.USERLCHG1.BorderColor = System.Drawing.Color.Black;
            this.USERLCHG1.CanGrow = false;
            this.USERLCHG1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.USERLCHG1.ForeColor = System.Drawing.Color.Black;
            this.USERLCHG1.Location = new System.Drawing.Point(125, 351);
            this.USERLCHG1.Name = "USERLCHG1";
            this.USERLCHG1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.USERLCHG1.ParentStyleUsing.UseBackColor = false;
            this.USERLCHG1.ParentStyleUsing.UseBorderColor = false;
            this.USERLCHG1.ParentStyleUsing.UseBorders = false;
            this.USERLCHG1.ParentStyleUsing.UseBorderWidth = false;
            this.USERLCHG1.ParentStyleUsing.UseFont = false;
            this.USERLCHG1.ParentStyleUsing.UseForeColor = false;
            this.USERLCHG1.Size = new System.Drawing.Size(91, 12);
            // 
            // Text14
            // 
            this.Text14.BackColor = System.Drawing.Color.White;
            this.Text14.BorderColor = System.Drawing.Color.Black;
            this.Text14.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text14.ForeColor = System.Drawing.Color.Black;
            this.Text14.Location = new System.Drawing.Point(0, 338);
            this.Text14.Name = "Text14";
            this.Text14.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text14.ParentStyleUsing.UseBackColor = false;
            this.Text14.ParentStyleUsing.UseBorderColor = false;
            this.Text14.ParentStyleUsing.UseBorders = false;
            this.Text14.ParentStyleUsing.UseBorderWidth = false;
            this.Text14.ParentStyleUsing.UseFont = false;
            this.Text14.ParentStyleUsing.UseForeColor = false;
            this.Text14.Size = new System.Drawing.Size(125, 12);
            this.Text14.Text = "DATE LAST CHANGE :";
            // 
            // Text13
            // 
            this.Text13.BackColor = System.Drawing.Color.White;
            this.Text13.BorderColor = System.Drawing.Color.Black;
            this.Text13.CanGrow = false;
            this.Text13.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text13.ForeColor = System.Drawing.Color.Black;
            this.Text13.Location = new System.Drawing.Point(0, 351);
            this.Text13.Name = "Text13";
            this.Text13.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text13.ParentStyleUsing.UseBackColor = false;
            this.Text13.ParentStyleUsing.UseBorderColor = false;
            this.Text13.ParentStyleUsing.UseBorders = false;
            this.Text13.ParentStyleUsing.UseBorderWidth = false;
            this.Text13.ParentStyleUsing.UseFont = false;
            this.Text13.ParentStyleUsing.UseForeColor = false;
            this.Text13.Size = new System.Drawing.Size(125, 12);
            this.Text13.Text = "USER LAST CHANGE :";
            // 
            // Text12
            // 
            this.Text12.BackColor = System.Drawing.Color.White;
            this.Text12.BorderColor = System.Drawing.Color.Black;
            this.Text12.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text12.ForeColor = System.Drawing.Color.Black;
            this.Text12.Location = new System.Drawing.Point(0, 325);
            this.Text12.Name = "Text12";
            this.Text12.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text12.ParentStyleUsing.UseBackColor = false;
            this.Text12.ParentStyleUsing.UseBorderColor = false;
            this.Text12.ParentStyleUsing.UseBorders = false;
            this.Text12.ParentStyleUsing.UseBorderWidth = false;
            this.Text12.ParentStyleUsing.UseFont = false;
            this.Text12.ParentStyleUsing.UseForeColor = false;
            this.Text12.Size = new System.Drawing.Size(125, 12);
            this.Text12.Text = "DATE CREATE :";
            // 
            // DATELCHG1
            // 
            this.DATELCHG1.BackColor = System.Drawing.Color.White;
            this.DATELCHG1.BorderColor = System.Drawing.Color.Black;
            this.DATELCHG1.CanGrow = false;
            this.DATELCHG1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.DATELCHG1.ForeColor = System.Drawing.Color.Black;
            this.DATELCHG1.Location = new System.Drawing.Point(125, 338);
            this.DATELCHG1.Name = "DATELCHG1";
            this.DATELCHG1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.DATELCHG1.ParentStyleUsing.UseBackColor = false;
            this.DATELCHG1.ParentStyleUsing.UseBorderColor = false;
            this.DATELCHG1.ParentStyleUsing.UseBorders = false;
            this.DATELCHG1.ParentStyleUsing.UseBorderWidth = false;
            this.DATELCHG1.ParentStyleUsing.UseFont = false;
            this.DATELCHG1.ParentStyleUsing.UseForeColor = false;
            this.DATELCHG1.Size = new System.Drawing.Size(91, 12);
            // 
            // DATECREATE1
            // 
            this.DATECREATE1.BackColor = System.Drawing.Color.White;
            this.DATECREATE1.BorderColor = System.Drawing.Color.Black;
            this.DATECREATE1.CanGrow = false;
            this.DATECREATE1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.DATECREATE1.ForeColor = System.Drawing.Color.Black;
            this.DATECREATE1.Location = new System.Drawing.Point(125, 325);
            this.DATECREATE1.Name = "DATECREATE1";
            this.DATECREATE1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.DATECREATE1.ParentStyleUsing.UseBackColor = false;
            this.DATECREATE1.ParentStyleUsing.UseBorderColor = false;
            this.DATECREATE1.ParentStyleUsing.UseBorders = false;
            this.DATECREATE1.ParentStyleUsing.UseBorderWidth = false;
            this.DATECREATE1.ParentStyleUsing.UseFont = false;
            this.DATECREATE1.ParentStyleUsing.UseForeColor = false;
            this.DATECREATE1.Size = new System.Drawing.Size(91, 12);
            // 
            // TELP1
            // 
            this.TELP1.BackColor = System.Drawing.Color.White;
            this.TELP1.BorderColor = System.Drawing.Color.Black;
            this.TELP1.CanGrow = false;
            this.TELP1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.TELP1.ForeColor = System.Drawing.Color.Black;
            this.TELP1.Location = new System.Drawing.Point(125, 213);
            this.TELP1.Name = "TELP1";
            this.TELP1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.TELP1.ParentStyleUsing.UseBackColor = false;
            this.TELP1.ParentStyleUsing.UseBorderColor = false;
            this.TELP1.ParentStyleUsing.UseBorders = false;
            this.TELP1.ParentStyleUsing.UseBorderWidth = false;
            this.TELP1.ParentStyleUsing.UseFont = false;
            this.TELP1.ParentStyleUsing.UseForeColor = false;
            this.TELP1.Size = new System.Drawing.Size(257, 12);
            // 
            // Text11
            // 
            this.Text11.BackColor = System.Drawing.Color.White;
            this.Text11.BorderColor = System.Drawing.Color.Black;
            this.Text11.CanGrow = false;
            this.Text11.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text11.ForeColor = System.Drawing.Color.Black;
            this.Text11.Location = new System.Drawing.Point(0, 170);
            this.Text11.Name = "Text11";
            this.Text11.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text11.ParentStyleUsing.UseBackColor = false;
            this.Text11.ParentStyleUsing.UseBorderColor = false;
            this.Text11.ParentStyleUsing.UseBorders = false;
            this.Text11.ParentStyleUsing.UseBorderWidth = false;
            this.Text11.ParentStyleUsing.UseFont = false;
            this.Text11.ParentStyleUsing.UseForeColor = false;
            this.Text11.Size = new System.Drawing.Size(125, 12);
            this.Text11.Text = "E-MAIL ADDRESS :";
            // 
            // Text10
            // 
            this.Text10.BackColor = System.Drawing.Color.White;
            this.Text10.BorderColor = System.Drawing.Color.Black;
            this.Text10.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text10.ForeColor = System.Drawing.Color.Black;
            this.Text10.Location = new System.Drawing.Point(0, 184);
            this.Text10.Name = "Text10";
            this.Text10.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text10.ParentStyleUsing.UseBackColor = false;
            this.Text10.ParentStyleUsing.UseBorderColor = false;
            this.Text10.ParentStyleUsing.UseBorders = false;
            this.Text10.ParentStyleUsing.UseBorderWidth = false;
            this.Text10.ParentStyleUsing.UseFont = false;
            this.Text10.ParentStyleUsing.UseForeColor = false;
            this.Text10.Size = new System.Drawing.Size(125, 13);
            this.Text10.Text = "TEL (HOME) :";
            // 
            // TELH1
            // 
            this.TELH1.BackColor = System.Drawing.Color.White;
            this.TELH1.BorderColor = System.Drawing.Color.Black;
            this.TELH1.CanGrow = false;
            this.TELH1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.TELH1.ForeColor = System.Drawing.Color.Black;
            this.TELH1.Location = new System.Drawing.Point(125, 184);
            this.TELH1.Name = "TELH1";
            this.TELH1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.TELH1.ParentStyleUsing.UseBackColor = false;
            this.TELH1.ParentStyleUsing.UseBorderColor = false;
            this.TELH1.ParentStyleUsing.UseBorders = false;
            this.TELH1.ParentStyleUsing.UseBorderWidth = false;
            this.TELH1.ParentStyleUsing.UseFont = false;
            this.TELH1.ParentStyleUsing.UseForeColor = false;
            this.TELH1.Size = new System.Drawing.Size(258, 13);
            // 
            // FAX1
            // 
            this.FAX1.BackColor = System.Drawing.Color.White;
            this.FAX1.BorderColor = System.Drawing.Color.Black;
            this.FAX1.CanGrow = false;
            this.FAX1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.FAX1.ForeColor = System.Drawing.Color.Black;
            this.FAX1.Location = new System.Drawing.Point(125, 227);
            this.FAX1.Name = "FAX1";
            this.FAX1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.FAX1.ParentStyleUsing.UseBackColor = false;
            this.FAX1.ParentStyleUsing.UseBorderColor = false;
            this.FAX1.ParentStyleUsing.UseBorders = false;
            this.FAX1.ParentStyleUsing.UseBorderWidth = false;
            this.FAX1.ParentStyleUsing.UseFont = false;
            this.FAX1.ParentStyleUsing.UseForeColor = false;
            this.FAX1.Size = new System.Drawing.Size(258, 12);
            // 
            // Text9
            // 
            this.Text9.BackColor = System.Drawing.Color.White;
            this.Text9.BorderColor = System.Drawing.Color.Black;
            this.Text9.CanGrow = false;
            this.Text9.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text9.ForeColor = System.Drawing.Color.Black;
            this.Text9.Location = new System.Drawing.Point(0, 227);
            this.Text9.Name = "Text9";
            this.Text9.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text9.ParentStyleUsing.UseBackColor = false;
            this.Text9.ParentStyleUsing.UseBorderColor = false;
            this.Text9.ParentStyleUsing.UseBorders = false;
            this.Text9.ParentStyleUsing.UseBorderWidth = false;
            this.Text9.ParentStyleUsing.UseFont = false;
            this.Text9.ParentStyleUsing.UseForeColor = false;
            this.Text9.Size = new System.Drawing.Size(125, 12);
            this.Text9.Text = "FAX  :";
            // 
            // Text8
            // 
            this.Text8.BackColor = System.Drawing.Color.White;
            this.Text8.BorderColor = System.Drawing.Color.Black;
            this.Text8.CanGrow = false;
            this.Text8.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text8.ForeColor = System.Drawing.Color.Black;
            this.Text8.Location = new System.Drawing.Point(0, 199);
            this.Text8.Name = "Text8";
            this.Text8.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text8.ParentStyleUsing.UseBackColor = false;
            this.Text8.ParentStyleUsing.UseBorderColor = false;
            this.Text8.ParentStyleUsing.UseBorders = false;
            this.Text8.ParentStyleUsing.UseBorderWidth = false;
            this.Text8.ParentStyleUsing.UseFont = false;
            this.Text8.ParentStyleUsing.UseForeColor = false;
            this.Text8.Size = new System.Drawing.Size(125, 12);
            this.Text8.Text = "TEL (OFFICE) :";
            // 
            // TELW1
            // 
            this.TELW1.BackColor = System.Drawing.Color.White;
            this.TELW1.BorderColor = System.Drawing.Color.Black;
            this.TELW1.CanGrow = false;
            this.TELW1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.TELW1.ForeColor = System.Drawing.Color.Black;
            this.TELW1.Location = new System.Drawing.Point(125, 199);
            this.TELW1.Name = "TELW1";
            this.TELW1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.TELW1.ParentStyleUsing.UseBackColor = false;
            this.TELW1.ParentStyleUsing.UseBorderColor = false;
            this.TELW1.ParentStyleUsing.UseBorders = false;
            this.TELW1.ParentStyleUsing.UseBorderWidth = false;
            this.TELW1.ParentStyleUsing.UseFont = false;
            this.TELW1.ParentStyleUsing.UseForeColor = false;
            this.TELW1.Size = new System.Drawing.Size(258, 12);
            // 
            // Text7
            // 
            this.Text7.BackColor = System.Drawing.Color.White;
            this.Text7.BorderColor = System.Drawing.Color.Black;
            this.Text7.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text7.ForeColor = System.Drawing.Color.Black;
            this.Text7.Location = new System.Drawing.Point(0, 101);
            this.Text7.Name = "Text7";
            this.Text7.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text7.ParentStyleUsing.UseBackColor = false;
            this.Text7.ParentStyleUsing.UseBorderColor = false;
            this.Text7.ParentStyleUsing.UseBorders = false;
            this.Text7.ParentStyleUsing.UseBorderWidth = false;
            this.Text7.ParentStyleUsing.UseFont = false;
            this.Text7.ParentStyleUsing.UseForeColor = false;
            this.Text7.Size = new System.Drawing.Size(125, 13);
            this.Text7.Text = "ADDRESS :";
            // 
            // NNAME1
            // 
            this.NNAME1.BackColor = System.Drawing.Color.White;
            this.NNAME1.BorderColor = System.Drawing.Color.Black;
            this.NNAME1.CanGrow = false;
            this.NNAME1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.NNAME1.ForeColor = System.Drawing.Color.Black;
            this.NNAME1.Location = new System.Drawing.Point(125, 61);
            this.NNAME1.Name = "NNAME1";
            this.NNAME1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.NNAME1.ParentStyleUsing.UseBackColor = false;
            this.NNAME1.ParentStyleUsing.UseBorderColor = false;
            this.NNAME1.ParentStyleUsing.UseBorders = false;
            this.NNAME1.ParentStyleUsing.UseBorderWidth = false;
            this.NNAME1.ParentStyleUsing.UseFont = false;
            this.NNAME1.ParentStyleUsing.UseForeColor = false;
            this.NNAME1.Size = new System.Drawing.Size(258, 12);
            // 
            // FNAME1
            // 
            this.FNAME1.BackColor = System.Drawing.Color.White;
            this.FNAME1.BorderColor = System.Drawing.Color.Black;
            this.FNAME1.CanGrow = false;
            this.FNAME1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.FNAME1.ForeColor = System.Drawing.Color.Black;
            this.FNAME1.Location = new System.Drawing.Point(125, 75);
            this.FNAME1.Name = "FNAME1";
            this.FNAME1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.FNAME1.ParentStyleUsing.UseBackColor = false;
            this.FNAME1.ParentStyleUsing.UseBorderColor = false;
            this.FNAME1.ParentStyleUsing.UseBorders = false;
            this.FNAME1.ParentStyleUsing.UseBorderWidth = false;
            this.FNAME1.ParentStyleUsing.UseFont = false;
            this.FNAME1.ParentStyleUsing.UseForeColor = false;
            this.FNAME1.Size = new System.Drawing.Size(258, 12);
            // 
            // LNAME1
            // 
            this.LNAME1.BackColor = System.Drawing.Color.White;
            this.LNAME1.BorderColor = System.Drawing.Color.Black;
            this.LNAME1.CanGrow = false;
            this.LNAME1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.LNAME1.ForeColor = System.Drawing.Color.Black;
            this.LNAME1.Location = new System.Drawing.Point(125, 88);
            this.LNAME1.Name = "LNAME1";
            this.LNAME1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.LNAME1.ParentStyleUsing.UseBackColor = false;
            this.LNAME1.ParentStyleUsing.UseBorderColor = false;
            this.LNAME1.ParentStyleUsing.UseBorders = false;
            this.LNAME1.ParentStyleUsing.UseBorderWidth = false;
            this.LNAME1.ParentStyleUsing.UseFont = false;
            this.LNAME1.ParentStyleUsing.UseForeColor = false;
            this.LNAME1.Size = new System.Drawing.Size(258, 12);
            // 
            // SALUTE1
            // 
            this.SALUTE1.BackColor = System.Drawing.Color.White;
            this.SALUTE1.BorderColor = System.Drawing.Color.Black;
            this.SALUTE1.CanGrow = false;
            this.SALUTE1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.SALUTE1.ForeColor = System.Drawing.Color.Black;
            this.SALUTE1.Location = new System.Drawing.Point(125, 47);
            this.SALUTE1.Name = "SALUTE1";
            this.SALUTE1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.SALUTE1.ParentStyleUsing.UseBackColor = false;
            this.SALUTE1.ParentStyleUsing.UseBorderColor = false;
            this.SALUTE1.ParentStyleUsing.UseBorders = false;
            this.SALUTE1.ParentStyleUsing.UseBorderWidth = false;
            this.SALUTE1.ParentStyleUsing.UseFont = false;
            this.SALUTE1.ParentStyleUsing.UseForeColor = false;
            this.SALUTE1.Size = new System.Drawing.Size(66, 12);
            // 
            // PageHeader
            // 
            this.PageHeader.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrPageInfo1,
            this.hdrCompName1,
            this.hdrTo1,
            this.Text5,
            this.hdrFm1,
            this.Text4,
            this.Text3,
            this.Text2,
            this.lblCaption,
            this.PrintDate1});
            this.PageHeader.Height = 92;
            this.PageHeader.Name = "PageHeader";
            // 
            // xrPageInfo1
            // 
            this.xrPageInfo1.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.xrPageInfo1.Location = new System.Drawing.Point(692, 33);
            this.xrPageInfo1.Name = "xrPageInfo1";
            this.xrPageInfo1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrPageInfo1.ParentStyleUsing.UseFont = false;
            this.xrPageInfo1.Size = new System.Drawing.Size(67, 17);
            // 
            // hdrCompName1
            // 
            this.hdrCompName1.BackColor = System.Drawing.Color.White;
            this.hdrCompName1.BorderColor = System.Drawing.Color.Black;
            this.hdrCompName1.CanGrow = false;
            this.hdrCompName1.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Bold);
            this.hdrCompName1.ForeColor = System.Drawing.Color.Black;
            this.hdrCompName1.Location = new System.Drawing.Point(0, 0);
            this.hdrCompName1.Name = "hdrCompName1";
            this.hdrCompName1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.hdrCompName1.ParentStyleUsing.UseBackColor = false;
            this.hdrCompName1.ParentStyleUsing.UseBorderColor = false;
            this.hdrCompName1.ParentStyleUsing.UseBorders = false;
            this.hdrCompName1.ParentStyleUsing.UseBorderWidth = false;
            this.hdrCompName1.ParentStyleUsing.UseFont = false;
            this.hdrCompName1.ParentStyleUsing.UseForeColor = false;
            this.hdrCompName1.Size = new System.Drawing.Size(614, 21);
            // 
            // hdrTo1
            // 
            this.hdrTo1.BackColor = System.Drawing.Color.White;
            this.hdrTo1.BorderColor = System.Drawing.Color.Black;
            this.hdrTo1.CanGrow = false;
            this.hdrTo1.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.hdrTo1.ForeColor = System.Drawing.Color.Black;
            this.hdrTo1.Location = new System.Drawing.Point(62, 58);
            this.hdrTo1.Name = "hdrTo1";
            this.hdrTo1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.hdrTo1.ParentStyleUsing.UseBackColor = false;
            this.hdrTo1.ParentStyleUsing.UseBorderColor = false;
            this.hdrTo1.ParentStyleUsing.UseBorders = false;
            this.hdrTo1.ParentStyleUsing.UseBorderWidth = false;
            this.hdrTo1.ParentStyleUsing.UseFont = false;
            this.hdrTo1.ParentStyleUsing.UseForeColor = false;
            this.hdrTo1.Size = new System.Drawing.Size(273, 12);
            // 
            // Text5
            // 
            this.Text5.BackColor = System.Drawing.Color.White;
            this.Text5.BorderColor = System.Drawing.Color.Black;
            this.Text5.CanGrow = false;
            this.Text5.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text5.ForeColor = System.Drawing.Color.Black;
            this.Text5.Location = new System.Drawing.Point(0, 58);
            this.Text5.Name = "Text5";
            this.Text5.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text5.ParentStyleUsing.UseBackColor = false;
            this.Text5.ParentStyleUsing.UseBorderColor = false;
            this.Text5.ParentStyleUsing.UseBorders = false;
            this.Text5.ParentStyleUsing.UseBorderWidth = false;
            this.Text5.ParentStyleUsing.UseFont = false;
            this.Text5.ParentStyleUsing.UseForeColor = false;
            this.Text5.Size = new System.Drawing.Size(33, 12);
            this.Text5.Text = "TO :";
            // 
            // hdrFm1
            // 
            this.hdrFm1.BackColor = System.Drawing.Color.White;
            this.hdrFm1.BorderColor = System.Drawing.Color.Black;
            this.hdrFm1.CanGrow = false;
            this.hdrFm1.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.hdrFm1.ForeColor = System.Drawing.Color.Black;
            this.hdrFm1.Location = new System.Drawing.Point(62, 46);
            this.hdrFm1.Name = "hdrFm1";
            this.hdrFm1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.hdrFm1.ParentStyleUsing.UseBackColor = false;
            this.hdrFm1.ParentStyleUsing.UseBorderColor = false;
            this.hdrFm1.ParentStyleUsing.UseBorders = false;
            this.hdrFm1.ParentStyleUsing.UseBorderWidth = false;
            this.hdrFm1.ParentStyleUsing.UseFont = false;
            this.hdrFm1.ParentStyleUsing.UseForeColor = false;
            this.hdrFm1.Size = new System.Drawing.Size(273, 12);
            // 
            // Text4
            // 
            this.Text4.BackColor = System.Drawing.Color.White;
            this.Text4.BorderColor = System.Drawing.Color.Black;
            this.Text4.CanGrow = false;
            this.Text4.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text4.ForeColor = System.Drawing.Color.Black;
            this.Text4.Location = new System.Drawing.Point(0, 46);
            this.Text4.Name = "Text4";
            this.Text4.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text4.ParentStyleUsing.UseBackColor = false;
            this.Text4.ParentStyleUsing.UseBorderColor = false;
            this.Text4.ParentStyleUsing.UseBorders = false;
            this.Text4.ParentStyleUsing.UseBorderWidth = false;
            this.Text4.ParentStyleUsing.UseFont = false;
            this.Text4.ParentStyleUsing.UseForeColor = false;
            this.Text4.Size = new System.Drawing.Size(45, 12);
            this.Text4.Text = "FROM :";
            // 
            // Text3
            // 
            this.Text3.BackColor = System.Drawing.Color.White;
            this.Text3.BorderColor = System.Drawing.Color.Black;
            this.Text3.CanGrow = false;
            this.Text3.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text3.ForeColor = System.Drawing.Color.Black;
            this.Text3.Location = new System.Drawing.Point(616, 35);
            this.Text3.Name = "Text3";
            this.Text3.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text3.ParentStyleUsing.UseBackColor = false;
            this.Text3.ParentStyleUsing.UseBorderColor = false;
            this.Text3.ParentStyleUsing.UseBorders = false;
            this.Text3.ParentStyleUsing.UseBorderWidth = false;
            this.Text3.ParentStyleUsing.UseFont = false;
            this.Text3.ParentStyleUsing.UseForeColor = false;
            this.Text3.Size = new System.Drawing.Size(58, 12);
            this.Text3.Text = "Page :";
            this.Text3.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopRight;
            // 
            // Text2
            // 
            this.Text2.BackColor = System.Drawing.Color.White;
            this.Text2.BorderColor = System.Drawing.Color.Black;
            this.Text2.CanGrow = false;
            this.Text2.Font = new System.Drawing.Font("Arial Unicode MS", 7F, System.Drawing.FontStyle.Bold);
            this.Text2.ForeColor = System.Drawing.Color.Black;
            this.Text2.Location = new System.Drawing.Point(616, 17);
            this.Text2.Name = "Text2";
            this.Text2.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Text2.ParentStyleUsing.UseBackColor = false;
            this.Text2.ParentStyleUsing.UseBorderColor = false;
            this.Text2.ParentStyleUsing.UseBorders = false;
            this.Text2.ParentStyleUsing.UseBorderWidth = false;
            this.Text2.ParentStyleUsing.UseFont = false;
            this.Text2.ParentStyleUsing.UseForeColor = false;
            this.Text2.Size = new System.Drawing.Size(58, 12);
            this.Text2.Text = "Print At :";
            this.Text2.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopRight;
            // 
            // lblCaption
            // 
            this.lblCaption.BackColor = System.Drawing.Color.White;
            this.lblCaption.BorderColor = System.Drawing.Color.Black;
            this.lblCaption.CanGrow = false;
            this.lblCaption.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Bold);
            this.lblCaption.ForeColor = System.Drawing.Color.Black;
            this.lblCaption.Location = new System.Drawing.Point(0, 25);
            this.lblCaption.Name = "lblCaption";
            this.lblCaption.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.lblCaption.ParentStyleUsing.UseBackColor = false;
            this.lblCaption.ParentStyleUsing.UseBorderColor = false;
            this.lblCaption.ParentStyleUsing.UseBorders = false;
            this.lblCaption.ParentStyleUsing.UseBorderWidth = false;
            this.lblCaption.ParentStyleUsing.UseFont = false;
            this.lblCaption.ParentStyleUsing.UseForeColor = false;
            this.lblCaption.Size = new System.Drawing.Size(250, 16);
            this.lblCaption.Text = "VIP Code List";
            // 
            // PrintDate1
            // 
            this.PrintDate1.BackColor = System.Drawing.Color.White;
            this.PrintDate1.BorderColor = System.Drawing.Color.Black;
            this.PrintDate1.CanGrow = false;
            this.PrintDate1.Font = new System.Drawing.Font("Arial Unicode MS", 7F);
            this.PrintDate1.ForeColor = System.Drawing.Color.Black;
            this.PrintDate1.Location = new System.Drawing.Point(675, 17);
            this.PrintDate1.Name = "PrintDate1";
            this.PrintDate1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.PrintDate1.ParentStyleUsing.UseBackColor = false;
            this.PrintDate1.ParentStyleUsing.UseBorderColor = false;
            this.PrintDate1.ParentStyleUsing.UseBorders = false;
            this.PrintDate1.ParentStyleUsing.UseBorderWidth = false;
            this.PrintDate1.ParentStyleUsing.UseFont = false;
            this.PrintDate1.ParentStyleUsing.UseForeColor = false;
            this.PrintDate1.Size = new System.Drawing.Size(100, 12);
            // 
            // PageFooter
            // 
            this.PageFooter.Height = 0;
            this.PageFooter.Name = "PageFooter";
            // 
            // VipCodeListRpt_Pdf
            // 
            this.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.Detail,
            this.PageHeader,
            this.PageFooter});
            this.Margins = new System.Drawing.Printing.Margins(25, 25, 25, 0);
            this.PageHeight = 1169;
            this.PageWidth = 827;
            this.PaperKind = System.Drawing.Printing.PaperKind.A4;
            this.BeforePrint += new System.Drawing.Printing.PrintEventHandler(this.VipCodeListRpt_Pdf_BeforePrint);
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();

        }

        #endregion

        private DevExpress.XtraReports.UI.DetailBand Detail;
        private DevExpress.XtraReports.UI.XRLabel Text42;
        private DevExpress.XtraReports.UI.XRLabel Text41;
        private DevExpress.XtraReports.UI.XRLabel R31;
        private DevExpress.XtraReports.UI.XRLabel R21;
        private DevExpress.XtraReports.UI.XRLabel Text40;
        private DevExpress.XtraReports.UI.XRLabel R11;
        private DevExpress.XtraReports.UI.XRLabel Text39;
        private DevExpress.XtraReports.UI.XRLabel Text38;
        private DevExpress.XtraReports.UI.XRLabel Text37;
        private DevExpress.XtraReports.UI.XRLabel MEMO1;
        private DevExpress.XtraReports.UI.XRLabel PYDISC1;
        private DevExpress.XtraReports.UI.XRLabel Text36;
        private DevExpress.XtraReports.UI.XRLabel TERMS1;
        private DevExpress.XtraReports.UI.XRLabel Text35;
        private DevExpress.XtraReports.UI.XRLabel ACREDIT1;
        private DevExpress.XtraReports.UI.XRLabel Text34;
        private DevExpress.XtraReports.UI.XRLabel Text33;
        private DevExpress.XtraReports.UI.XRLabel NATION1;
        private DevExpress.XtraReports.UI.XRLabel Text32;
        private DevExpress.XtraReports.UI.XRLabel REMARKS1;
        private DevExpress.XtraReports.UI.XRLabel Text31;
        private DevExpress.XtraReports.UI.XRLabel DATEREGIS1;
        private DevExpress.XtraReports.UI.XRLabel Text30;
        private DevExpress.XtraReports.UI.XRLabel DATEBIRTH1;
        private DevExpress.XtraReports.UI.XRLabel Text29;
        private DevExpress.XtraReports.UI.XRLabel Text28;
        private DevExpress.XtraReports.UI.XRLabel DATEMIGRATE1;
        private DevExpress.XtraReports.UI.XRLabel DATECOMM1;
        private DevExpress.XtraReports.UI.XRLabel Text27;
        private DevExpress.XtraReports.UI.XRLabel CARDACTIVE1;
        private DevExpress.XtraReports.UI.XRLabel Text26;
        private DevExpress.XtraReports.UI.XRLabel CARDRECEIVE1;
        private DevExpress.XtraReports.UI.XRLabel Text25;
        private DevExpress.XtraReports.UI.XRLabel CARDNAME1;
        private DevExpress.XtraReports.UI.XRLabel Text24;
        private DevExpress.XtraReports.UI.XRLabel CARDEXPIRE1;
        private DevExpress.XtraReports.UI.XRLabel Text23;
        private DevExpress.XtraReports.UI.XRLabel CARDISSUE1;
        private DevExpress.XtraReports.UI.XRLabel SEX1;
        private DevExpress.XtraReports.UI.XRLabel Text21;
        private DevExpress.XtraReports.UI.XRLabel IDNO1;
        private DevExpress.XtraReports.UI.XRLabel EMAIL1;
        private DevExpress.XtraReports.UI.XRLabel Text19;
        private DevExpress.XtraReports.UI.XRLabel Text18;
        private DevExpress.XtraReports.UI.XRLabel Text17;
        private DevExpress.XtraReports.UI.XRLabel Text15;
        private DevExpress.XtraReports.UI.XRLabel USERLCHG1;
        private DevExpress.XtraReports.UI.XRLabel Text14;
        private DevExpress.XtraReports.UI.XRLabel Text13;
        private DevExpress.XtraReports.UI.XRLabel Text12;
        private DevExpress.XtraReports.UI.XRLabel DATELCHG1;
        private DevExpress.XtraReports.UI.XRLabel DATECREATE1;
        private DevExpress.XtraReports.UI.XRLabel TELP1;
        private DevExpress.XtraReports.UI.XRLabel Text11;
        private DevExpress.XtraReports.UI.XRLabel Text10;
        private DevExpress.XtraReports.UI.XRLabel TELH1;
        private DevExpress.XtraReports.UI.XRLabel FAX1;
        private DevExpress.XtraReports.UI.XRLabel Text9;
        private DevExpress.XtraReports.UI.XRLabel Text8;
        private DevExpress.XtraReports.UI.XRLabel TELW1;
        private DevExpress.XtraReports.UI.XRLabel Text7;
        private DevExpress.XtraReports.UI.XRLabel NNAME1;
        private DevExpress.XtraReports.UI.XRLabel FNAME1;
        private DevExpress.XtraReports.UI.XRLabel LNAME1;
        private DevExpress.XtraReports.UI.XRLabel SALUTE1;
        private DevExpress.XtraReports.UI.PageHeaderBand PageHeader;
        private DevExpress.XtraReports.UI.XRLabel hdrCompName1;
        private DevExpress.XtraReports.UI.XRLabel hdrTo1;
        private DevExpress.XtraReports.UI.XRLabel Text5;
        private DevExpress.XtraReports.UI.XRLabel hdrFm1;
        private DevExpress.XtraReports.UI.XRLabel Text4;
        private DevExpress.XtraReports.UI.XRLabel Text3;
        private DevExpress.XtraReports.UI.XRLabel Text2;
        private DevExpress.XtraReports.UI.XRLabel lblCaption;
        private DevExpress.XtraReports.UI.XRLabel PrintDate1;
        private DevExpress.XtraReports.UI.PageFooterBand PageFooter;
        private DevExpress.XtraReports.UI.XRPageInfo xrPageInfo1;
        private DevExpress.XtraReports.UI.XRLabel ADDRESS41;
        private DevExpress.XtraReports.UI.XRLabel ADDRESS31;
        private DevExpress.XtraReports.UI.XRLabel ADDRESS21;
        private DevExpress.XtraReports.UI.XRLabel ADDRESS11;
        private DevExpress.XtraReports.UI.XRLabel Text22;
        private DevExpress.XtraReports.UI.XRLabel GRADE1;
        private DevExpress.XtraReports.UI.XRLabel Text20;
        private DevExpress.XtraReports.UI.XRLabel Text16;
        private DevExpress.XtraReports.UI.XRLabel GROUP1;
        private DevExpress.XtraReports.UI.XRLabel VIPNO1;
        private DevExpress.XtraReports.UI.XRLine xrLine1;

    }
}
