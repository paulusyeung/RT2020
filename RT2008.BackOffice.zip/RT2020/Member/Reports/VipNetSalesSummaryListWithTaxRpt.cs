using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using DevExpress.XtraReports.UI;

namespace RT2008.Member.Reports
{
    public partial class VipNetSalesSummaryListWithTaxRpt : DevExpress.XtraReports.UI.XtraReport
    {
        public VipNetSalesSummaryListWithTaxRpt()
        {
            InitializeComponent();
        }

    }
}
