namespace RT2008.Member
{
    partial class MemberWizard_MarketingInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Visual WebGui UserControl Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMostVisitedMalls = new Gizmox.WebGUI.Forms.Label();
            this.lblMostBoughtBrands = new Gizmox.WebGUI.Forms.Label();
            this.lblMostReadMagazine = new Gizmox.WebGUI.Forms.Label();
            this.lblMostUsedCreditCards = new Gizmox.WebGUI.Forms.Label();
            this.lblMostVisitedMalls1 = new Gizmox.WebGUI.Forms.Label();
            this.lblMostVisitedMalls2 = new Gizmox.WebGUI.Forms.Label();
            this.lblMostVisitedMalls3 = new Gizmox.WebGUI.Forms.Label();
            this.txtMostVisitedMalls1 = new Gizmox.WebGUI.Forms.TextBox();
            this.txtMostVisitedMalls2 = new Gizmox.WebGUI.Forms.TextBox();
            this.txtMostVisitedMalls3 = new Gizmox.WebGUI.Forms.TextBox();
            this.txtMostBoughtBrands3 = new Gizmox.WebGUI.Forms.TextBox();
            this.txtMostBoughtBrands2 = new Gizmox.WebGUI.Forms.TextBox();
            this.txtMostBoughtBrands1 = new Gizmox.WebGUI.Forms.TextBox();
            this.lblMostBoughtBrands3 = new Gizmox.WebGUI.Forms.Label();
            this.lblMostBoughtBrands2 = new Gizmox.WebGUI.Forms.Label();
            this.lblMostBoughtBrands1 = new Gizmox.WebGUI.Forms.Label();
            this.lblMostReadMagazine1 = new Gizmox.WebGUI.Forms.Label();
            this.lblMostReadMagazine2 = new Gizmox.WebGUI.Forms.Label();
            this.lblMostReadMagazine3 = new Gizmox.WebGUI.Forms.Label();
            this.txtMostReadMagazine1 = new Gizmox.WebGUI.Forms.TextBox();
            this.txtMostReadMagazine2 = new Gizmox.WebGUI.Forms.TextBox();
            this.txtMostReadMagazine3 = new Gizmox.WebGUI.Forms.TextBox();
            this.lblMostUsedCreditCards1 = new Gizmox.WebGUI.Forms.Label();
            this.lblMostUsedCreditCards2 = new Gizmox.WebGUI.Forms.Label();
            this.lblMostUsedCreditCards3 = new Gizmox.WebGUI.Forms.Label();
            this.txtMostUsedCreditCards1 = new Gizmox.WebGUI.Forms.TextBox();
            this.txtMostUsedCreditCards2 = new Gizmox.WebGUI.Forms.TextBox();
            this.txtMostUsedCreditCards3 = new Gizmox.WebGUI.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblMostVisitedMalls
            // 
            this.lblMostVisitedMalls.DragTargets = new Gizmox.WebGUI.Forms.Component[0];
            this.lblMostVisitedMalls.Location = new System.Drawing.Point(16, 18);
            this.lblMostVisitedMalls.Name = "lblMostVisitedMalls";
            this.lblMostVisitedMalls.Size = new System.Drawing.Size(154, 23);
            this.lblMostVisitedMalls.TabIndex = 0;
            this.lblMostVisitedMalls.TabStop = false;
            this.lblMostVisitedMalls.Text = "Most Frequently Visited Malls";
            // 
            // lblMostBoughtBrands
            // 
            this.lblMostBoughtBrands.DragTargets = new Gizmox.WebGUI.Forms.Component[0];
            this.lblMostBoughtBrands.Location = new System.Drawing.Point(372, 18);
            this.lblMostBoughtBrands.Name = "lblMostBoughtBrands";
            this.lblMostBoughtBrands.Size = new System.Drawing.Size(169, 23);
            this.lblMostBoughtBrands.TabIndex = 0;
            this.lblMostBoughtBrands.TabStop = false;
            this.lblMostBoughtBrands.Text = "Most Frequently bought Brands";
            // 
            // lblMostReadMagazine
            // 
            this.lblMostReadMagazine.DragTargets = new Gizmox.WebGUI.Forms.Component[0];
            this.lblMostReadMagazine.Location = new System.Drawing.Point(16, 180);
            this.lblMostReadMagazine.Name = "lblMostReadMagazine";
            this.lblMostReadMagazine.Size = new System.Drawing.Size(185, 23);
            this.lblMostReadMagazine.TabIndex = 0;
            this.lblMostReadMagazine.TabStop = false;
            this.lblMostReadMagazine.Text = "Most Frequently Read Magazines";
            // 
            // lblMostUsedCreditCards
            // 
            this.lblMostUsedCreditCards.DragTargets = new Gizmox.WebGUI.Forms.Component[0];
            this.lblMostUsedCreditCards.Location = new System.Drawing.Point(372, 180);
            this.lblMostUsedCreditCards.Name = "lblMostUsedCreditCards";
            this.lblMostUsedCreditCards.Size = new System.Drawing.Size(188, 23);
            this.lblMostUsedCreditCards.TabIndex = 0;
            this.lblMostUsedCreditCards.TabStop = false;
            this.lblMostUsedCreditCards.Text = "Most Frequently Used Credit Cards";
            // 
            // lblMostVisitedMalls1
            // 
            this.lblMostVisitedMalls1.DragTargets = new Gizmox.WebGUI.Forms.Component[0];
            this.lblMostVisitedMalls1.Location = new System.Drawing.Point(16, 52);
            this.lblMostVisitedMalls1.Name = "lblMostVisitedMalls1";
            this.lblMostVisitedMalls1.Size = new System.Drawing.Size(35, 23);
            this.lblMostVisitedMalls1.TabIndex = 0;
            this.lblMostVisitedMalls1.TabStop = false;
            this.lblMostVisitedMalls1.Text = "#1";
            // 
            // lblMostVisitedMalls2
            // 
            this.lblMostVisitedMalls2.DragTargets = new Gizmox.WebGUI.Forms.Component[0];
            this.lblMostVisitedMalls2.Location = new System.Drawing.Point(16, 75);
            this.lblMostVisitedMalls2.Name = "lblMostVisitedMalls2";
            this.lblMostVisitedMalls2.Size = new System.Drawing.Size(35, 23);
            this.lblMostVisitedMalls2.TabIndex = 0;
            this.lblMostVisitedMalls2.TabStop = false;
            this.lblMostVisitedMalls2.Text = "#2";
            // 
            // lblMostVisitedMalls3
            // 
            this.lblMostVisitedMalls3.DragTargets = new Gizmox.WebGUI.Forms.Component[0];
            this.lblMostVisitedMalls3.Location = new System.Drawing.Point(16, 98);
            this.lblMostVisitedMalls3.Name = "lblMostVisitedMalls3";
            this.lblMostVisitedMalls3.Size = new System.Drawing.Size(35, 23);
            this.lblMostVisitedMalls3.TabIndex = 0;
            this.lblMostVisitedMalls3.TabStop = false;
            this.lblMostVisitedMalls3.Text = "#3";
            // 
            // txtMostVisitedMalls1
            // 
            this.txtMostVisitedMalls1.DragTargets = new Gizmox.WebGUI.Forms.Component[0];
            this.txtMostVisitedMalls1.Location = new System.Drawing.Point(57, 49);
            this.txtMostVisitedMalls1.Name = "txtMostVisitedMalls1";
            this.txtMostVisitedMalls1.Size = new System.Drawing.Size(235, 20);
            this.txtMostVisitedMalls1.TabIndex = 3;
            // 
            // txtMostVisitedMalls2
            // 
            this.txtMostVisitedMalls2.DragTargets = new Gizmox.WebGUI.Forms.Component[0];
            this.txtMostVisitedMalls2.Location = new System.Drawing.Point(57, 72);
            this.txtMostVisitedMalls2.Name = "txtMostVisitedMalls2";
            this.txtMostVisitedMalls2.Size = new System.Drawing.Size(235, 20);
            this.txtMostVisitedMalls2.TabIndex = 4;
            // 
            // txtMostVisitedMalls3
            // 
            this.txtMostVisitedMalls3.DragTargets = new Gizmox.WebGUI.Forms.Component[0];
            this.txtMostVisitedMalls3.Location = new System.Drawing.Point(57, 95);
            this.txtMostVisitedMalls3.Name = "txtMostVisitedMalls3";
            this.txtMostVisitedMalls3.Size = new System.Drawing.Size(235, 20);
            this.txtMostVisitedMalls3.TabIndex = 5;
            // 
            // txtMostBoughtBrands3
            // 
            this.txtMostBoughtBrands3.DragTargets = new Gizmox.WebGUI.Forms.Component[0];
            this.txtMostBoughtBrands3.Location = new System.Drawing.Point(413, 95);
            this.txtMostBoughtBrands3.Name = "txtMostBoughtBrands3";
            this.txtMostBoughtBrands3.Size = new System.Drawing.Size(235, 20);
            this.txtMostBoughtBrands3.TabIndex = 11;
            // 
            // txtMostBoughtBrands2
            // 
            this.txtMostBoughtBrands2.DragTargets = new Gizmox.WebGUI.Forms.Component[0];
            this.txtMostBoughtBrands2.Location = new System.Drawing.Point(413, 72);
            this.txtMostBoughtBrands2.Name = "txtMostBoughtBrands2";
            this.txtMostBoughtBrands2.Size = new System.Drawing.Size(235, 20);
            this.txtMostBoughtBrands2.TabIndex = 10;
            // 
            // txtMostBoughtBrands1
            // 
            this.txtMostBoughtBrands1.DragTargets = new Gizmox.WebGUI.Forms.Component[0];
            this.txtMostBoughtBrands1.Location = new System.Drawing.Point(413, 49);
            this.txtMostBoughtBrands1.Name = "txtMostBoughtBrands1";
            this.txtMostBoughtBrands1.Size = new System.Drawing.Size(235, 20);
            this.txtMostBoughtBrands1.TabIndex = 9;
            // 
            // lblMostBoughtBrands3
            // 
            this.lblMostBoughtBrands3.DragTargets = new Gizmox.WebGUI.Forms.Component[0];
            this.lblMostBoughtBrands3.Location = new System.Drawing.Point(372, 98);
            this.lblMostBoughtBrands3.Name = "lblMostBoughtBrands3";
            this.lblMostBoughtBrands3.Size = new System.Drawing.Size(35, 23);
            this.lblMostBoughtBrands3.TabIndex = 0;
            this.lblMostBoughtBrands3.TabStop = false;
            this.lblMostBoughtBrands3.Text = "#3";
            // 
            // lblMostBoughtBrands2
            // 
            this.lblMostBoughtBrands2.DragTargets = new Gizmox.WebGUI.Forms.Component[0];
            this.lblMostBoughtBrands2.Location = new System.Drawing.Point(372, 75);
            this.lblMostBoughtBrands2.Name = "lblMostBoughtBrands2";
            this.lblMostBoughtBrands2.Size = new System.Drawing.Size(35, 23);
            this.lblMostBoughtBrands2.TabIndex = 0;
            this.lblMostBoughtBrands2.TabStop = false;
            this.lblMostBoughtBrands2.Text = "#2";
            // 
            // lblMostBoughtBrands1
            // 
            this.lblMostBoughtBrands1.DragTargets = new Gizmox.WebGUI.Forms.Component[0];
            this.lblMostBoughtBrands1.Location = new System.Drawing.Point(372, 52);
            this.lblMostBoughtBrands1.Name = "lblMostBoughtBrands1";
            this.lblMostBoughtBrands1.Size = new System.Drawing.Size(35, 23);
            this.lblMostBoughtBrands1.TabIndex = 0;
            this.lblMostBoughtBrands1.TabStop = false;
            this.lblMostBoughtBrands1.Text = "#1";
            // 
            // lblMostReadMagazine1
            // 
            this.lblMostReadMagazine1.DragTargets = new Gizmox.WebGUI.Forms.Component[0];
            this.lblMostReadMagazine1.Location = new System.Drawing.Point(16, 213);
            this.lblMostReadMagazine1.Name = "lblMostReadMagazine1";
            this.lblMostReadMagazine1.Size = new System.Drawing.Size(35, 23);
            this.lblMostReadMagazine1.TabIndex = 0;
            this.lblMostReadMagazine1.TabStop = false;
            this.lblMostReadMagazine1.Text = "#1";
            // 
            // lblMostReadMagazine2
            // 
            this.lblMostReadMagazine2.DragTargets = new Gizmox.WebGUI.Forms.Component[0];
            this.lblMostReadMagazine2.Location = new System.Drawing.Point(16, 236);
            this.lblMostReadMagazine2.Name = "lblMostReadMagazine2";
            this.lblMostReadMagazine2.Size = new System.Drawing.Size(35, 23);
            this.lblMostReadMagazine2.TabIndex = 0;
            this.lblMostReadMagazine2.TabStop = false;
            this.lblMostReadMagazine2.Text = "#2";
            // 
            // lblMostReadMagazine3
            // 
            this.lblMostReadMagazine3.DragTargets = new Gizmox.WebGUI.Forms.Component[0];
            this.lblMostReadMagazine3.Location = new System.Drawing.Point(16, 259);
            this.lblMostReadMagazine3.Name = "lblMostReadMagazine3";
            this.lblMostReadMagazine3.Size = new System.Drawing.Size(35, 23);
            this.lblMostReadMagazine3.TabIndex = 0;
            this.lblMostReadMagazine3.TabStop = false;
            this.lblMostReadMagazine3.Text = "#3";
            // 
            // txtMostReadMagazine1
            // 
            this.txtMostReadMagazine1.DragTargets = new Gizmox.WebGUI.Forms.Component[0];
            this.txtMostReadMagazine1.Location = new System.Drawing.Point(57, 210);
            this.txtMostReadMagazine1.Name = "txtMostReadMagazine1";
            this.txtMostReadMagazine1.Size = new System.Drawing.Size(235, 20);
            this.txtMostReadMagazine1.TabIndex = 6;
            // 
            // txtMostReadMagazine2
            // 
            this.txtMostReadMagazine2.DragTargets = new Gizmox.WebGUI.Forms.Component[0];
            this.txtMostReadMagazine2.Location = new System.Drawing.Point(57, 233);
            this.txtMostReadMagazine2.Name = "txtMostReadMagazine2";
            this.txtMostReadMagazine2.Size = new System.Drawing.Size(235, 20);
            this.txtMostReadMagazine2.TabIndex = 7;
            // 
            // txtMostReadMagazine3
            // 
            this.txtMostReadMagazine3.DragTargets = new Gizmox.WebGUI.Forms.Component[0];
            this.txtMostReadMagazine3.Location = new System.Drawing.Point(57, 256);
            this.txtMostReadMagazine3.Name = "txtMostReadMagazine3";
            this.txtMostReadMagazine3.Size = new System.Drawing.Size(235, 20);
            this.txtMostReadMagazine3.TabIndex = 8;
            // 
            // lblMostUsedCreditCards1
            // 
            this.lblMostUsedCreditCards1.DragTargets = new Gizmox.WebGUI.Forms.Component[0];
            this.lblMostUsedCreditCards1.Location = new System.Drawing.Point(372, 213);
            this.lblMostUsedCreditCards1.Name = "lblMostUsedCreditCards1";
            this.lblMostUsedCreditCards1.Size = new System.Drawing.Size(35, 23);
            this.lblMostUsedCreditCards1.TabIndex = 0;
            this.lblMostUsedCreditCards1.TabStop = false;
            this.lblMostUsedCreditCards1.Text = "#1";
            // 
            // lblMostUsedCreditCards2
            // 
            this.lblMostUsedCreditCards2.DragTargets = new Gizmox.WebGUI.Forms.Component[0];
            this.lblMostUsedCreditCards2.Location = new System.Drawing.Point(372, 236);
            this.lblMostUsedCreditCards2.Name = "lblMostUsedCreditCards2";
            this.lblMostUsedCreditCards2.Size = new System.Drawing.Size(35, 23);
            this.lblMostUsedCreditCards2.TabIndex = 0;
            this.lblMostUsedCreditCards2.TabStop = false;
            this.lblMostUsedCreditCards2.Text = "#2";
            // 
            // lblMostUsedCreditCards3
            // 
            this.lblMostUsedCreditCards3.DragTargets = new Gizmox.WebGUI.Forms.Component[0];
            this.lblMostUsedCreditCards3.Location = new System.Drawing.Point(372, 259);
            this.lblMostUsedCreditCards3.Name = "lblMostUsedCreditCards3";
            this.lblMostUsedCreditCards3.Size = new System.Drawing.Size(35, 23);
            this.lblMostUsedCreditCards3.TabIndex = 0;
            this.lblMostUsedCreditCards3.TabStop = false;
            this.lblMostUsedCreditCards3.Text = "#3";
            // 
            // txtMostUsedCreditCards1
            // 
            this.txtMostUsedCreditCards1.DragTargets = new Gizmox.WebGUI.Forms.Component[0];
            this.txtMostUsedCreditCards1.Location = new System.Drawing.Point(413, 210);
            this.txtMostUsedCreditCards1.Name = "txtMostUsedCreditCards1";
            this.txtMostUsedCreditCards1.Size = new System.Drawing.Size(235, 20);
            this.txtMostUsedCreditCards1.TabIndex = 12;
            // 
            // txtMostUsedCreditCards2
            // 
            this.txtMostUsedCreditCards2.DragTargets = new Gizmox.WebGUI.Forms.Component[0];
            this.txtMostUsedCreditCards2.Location = new System.Drawing.Point(413, 233);
            this.txtMostUsedCreditCards2.Name = "txtMostUsedCreditCards2";
            this.txtMostUsedCreditCards2.Size = new System.Drawing.Size(235, 20);
            this.txtMostUsedCreditCards2.TabIndex = 13;
            // 
            // txtMostUsedCreditCards3
            // 
            this.txtMostUsedCreditCards3.DragTargets = new Gizmox.WebGUI.Forms.Component[0];
            this.txtMostUsedCreditCards3.Location = new System.Drawing.Point(413, 256);
            this.txtMostUsedCreditCards3.Name = "txtMostUsedCreditCards3";
            this.txtMostUsedCreditCards3.Size = new System.Drawing.Size(235, 20);
            this.txtMostUsedCreditCards3.TabIndex = 14;
            // 
            // MemberWizard_MarketingInfo
            // 
            this.Controls.Add(this.txtMostUsedCreditCards3);
            this.Controls.Add(this.txtMostUsedCreditCards2);
            this.Controls.Add(this.txtMostUsedCreditCards1);
            this.Controls.Add(this.lblMostUsedCreditCards3);
            this.Controls.Add(this.lblMostUsedCreditCards2);
            this.Controls.Add(this.lblMostUsedCreditCards1);
            this.Controls.Add(this.txtMostReadMagazine3);
            this.Controls.Add(this.txtMostReadMagazine2);
            this.Controls.Add(this.txtMostReadMagazine1);
            this.Controls.Add(this.lblMostReadMagazine3);
            this.Controls.Add(this.lblMostReadMagazine2);
            this.Controls.Add(this.lblMostReadMagazine1);
            this.Controls.Add(this.lblMostBoughtBrands1);
            this.Controls.Add(this.lblMostBoughtBrands2);
            this.Controls.Add(this.lblMostBoughtBrands3);
            this.Controls.Add(this.txtMostBoughtBrands1);
            this.Controls.Add(this.txtMostBoughtBrands2);
            this.Controls.Add(this.txtMostBoughtBrands3);
            this.Controls.Add(this.txtMostVisitedMalls3);
            this.Controls.Add(this.txtMostVisitedMalls2);
            this.Controls.Add(this.txtMostVisitedMalls1);
            this.Controls.Add(this.lblMostVisitedMalls3);
            this.Controls.Add(this.lblMostVisitedMalls2);
            this.Controls.Add(this.lblMostVisitedMalls1);
            this.Controls.Add(this.lblMostUsedCreditCards);
            this.Controls.Add(this.lblMostReadMagazine);
            this.Controls.Add(this.lblMostBoughtBrands);
            this.Controls.Add(this.lblMostVisitedMalls);
            this.Size = new System.Drawing.Size(766, 379);
            this.Text = "MemberWizard_MarketingInfo";
            this.ResumeLayout(false);

        }

        #endregion

        private Gizmox.WebGUI.Forms.Label lblMostVisitedMalls;
        private Gizmox.WebGUI.Forms.Label lblMostBoughtBrands;
        private Gizmox.WebGUI.Forms.Label lblMostReadMagazine;
        private Gizmox.WebGUI.Forms.Label lblMostUsedCreditCards;
        private Gizmox.WebGUI.Forms.Label lblMostVisitedMalls1;
        private Gizmox.WebGUI.Forms.Label lblMostVisitedMalls2;
        private Gizmox.WebGUI.Forms.Label lblMostVisitedMalls3;
        private Gizmox.WebGUI.Forms.Label lblMostBoughtBrands3;
        private Gizmox.WebGUI.Forms.Label lblMostBoughtBrands2;
        private Gizmox.WebGUI.Forms.Label lblMostBoughtBrands1;
        private Gizmox.WebGUI.Forms.Label lblMostReadMagazine1;
        private Gizmox.WebGUI.Forms.Label lblMostReadMagazine2;
        private Gizmox.WebGUI.Forms.Label lblMostReadMagazine3;
        private Gizmox.WebGUI.Forms.Label lblMostUsedCreditCards1;
        private Gizmox.WebGUI.Forms.Label lblMostUsedCreditCards2;
        private Gizmox.WebGUI.Forms.Label lblMostUsedCreditCards3;
        public Gizmox.WebGUI.Forms.TextBox txtMostVisitedMalls1;
        public Gizmox.WebGUI.Forms.TextBox txtMostVisitedMalls2;
        public Gizmox.WebGUI.Forms.TextBox txtMostVisitedMalls3;
        public Gizmox.WebGUI.Forms.TextBox txtMostBoughtBrands3;
        public Gizmox.WebGUI.Forms.TextBox txtMostBoughtBrands2;
        public Gizmox.WebGUI.Forms.TextBox txtMostBoughtBrands1;
        public Gizmox.WebGUI.Forms.TextBox txtMostReadMagazine1;
        public Gizmox.WebGUI.Forms.TextBox txtMostReadMagazine2;
        public Gizmox.WebGUI.Forms.TextBox txtMostReadMagazine3;
        public Gizmox.WebGUI.Forms.TextBox txtMostUsedCreditCards1;
        public Gizmox.WebGUI.Forms.TextBox txtMostUsedCreditCards2;
        public Gizmox.WebGUI.Forms.TextBox txtMostUsedCreditCards3;


    }
}