namespace RT2008.Member
{
    partial class MemberWizard_MainInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Visual WebGui UserControl Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Gizmox.WebGUI.Common.Resources.IconResourceHandle iconResourceHandle1 = new Gizmox.WebGUI.Common.Resources.IconResourceHandle();
            Gizmox.WebGUI.Common.Resources.IconResourceHandle iconResourceHandle2 = new Gizmox.WebGUI.Common.Resources.IconResourceHandle();
            Gizmox.WebGUI.Common.Resources.IconResourceHandle iconResourceHandle3 = new Gizmox.WebGUI.Common.Resources.IconResourceHandle();
            Gizmox.WebGUI.Common.Resources.IconResourceHandle iconResourceHandle4 = new Gizmox.WebGUI.Common.Resources.IconResourceHandle();
            this.lblSalutation = new Gizmox.WebGUI.Forms.Label();
            this.cboSalutation = new Gizmox.WebGUI.Forms.ComboBox();
            this.lblSmartTag10 = new Gizmox.WebGUI.Forms.Label();
            this.txtSmartTag10 = new Gizmox.WebGUI.Forms.TextBox();
            this.btnFindHKID = new Gizmox.WebGUI.Forms.Button();
            this.lblNickName = new Gizmox.WebGUI.Forms.Label();
            this.txtNickName = new Gizmox.WebGUI.Forms.TextBox();
            this.lblFirstName = new Gizmox.WebGUI.Forms.Label();
            this.txtFirstName = new Gizmox.WebGUI.Forms.TextBox();
            this.lblLastName = new Gizmox.WebGUI.Forms.Label();
            this.txtLastName = new Gizmox.WebGUI.Forms.TextBox();
            this.lblChineseName = new Gizmox.WebGUI.Forms.Label();
            this.txtChineseName = new Gizmox.WebGUI.Forms.TextBox();
            this.lblJobTitle = new Gizmox.WebGUI.Forms.Label();
            this.lblSmartTag13 = new Gizmox.WebGUI.Forms.Label();
            this.txtSmartTag13 = new Gizmox.WebGUI.Forms.TextBox();
            this.lblSmartTag14 = new Gizmox.WebGUI.Forms.Label();
            this.txtSmartTag14 = new Gizmox.WebGUI.Forms.TextBox();
            this.lblSmartTag11 = new Gizmox.WebGUI.Forms.Label();
            this.cboSmartTag11 = new Gizmox.WebGUI.Forms.ComboBox();
            this.lblRemarks = new Gizmox.WebGUI.Forms.Label();
            this.txtRemarks = new Gizmox.WebGUI.Forms.TextBox();
            this.btnFindNickName = new Gizmox.WebGUI.Forms.Button();
            this.btnFindFirstName = new Gizmox.WebGUI.Forms.Button();
            this.btnFindLastName = new Gizmox.WebGUI.Forms.Button();
            this.lblGroup = new Gizmox.WebGUI.Forms.Label();
            this.lblSmartTag1 = new Gizmox.WebGUI.Forms.Label();
            this.lblSmartTag2 = new Gizmox.WebGUI.Forms.Label();
            this.lblSmartTag3 = new Gizmox.WebGUI.Forms.Label();
            this.lblSmartTag4 = new Gizmox.WebGUI.Forms.Label();
            this.txtSmartTag1 = new Gizmox.WebGUI.Forms.TextBox();
            this.lblSmartTag5 = new Gizmox.WebGUI.Forms.Label();
            this.lblSmartTag6 = new Gizmox.WebGUI.Forms.Label();
            this.lblSmartTag7 = new Gizmox.WebGUI.Forms.Label();
            this.lblSmartTag8 = new Gizmox.WebGUI.Forms.Label();
            this.lblSmartTag9 = new Gizmox.WebGUI.Forms.Label();
            this.txtSmartTag5 = new Gizmox.WebGUI.Forms.TextBox();
            this.txtSmartTag6 = new Gizmox.WebGUI.Forms.TextBox();
            this.txtSmartTag7 = new Gizmox.WebGUI.Forms.TextBox();
            this.lblPhoneBook = new Gizmox.WebGUI.Forms.Label();
            this.cboPhoneBook = new Gizmox.WebGUI.Forms.ComboBox();
            this.lblLastUpdated = new Gizmox.WebGUI.Forms.Label();
            this.txtLastUpdatedOn = new Gizmox.WebGUI.Forms.TextBox();
            this.txtLastUpdatedBy = new Gizmox.WebGUI.Forms.TextBox();
            this.lblCreatedOn = new Gizmox.WebGUI.Forms.Label();
            this.txtCreatedOn = new Gizmox.WebGUI.Forms.TextBox();
            this.lblStatus = new Gizmox.WebGUI.Forms.Label();
            this.txtStatus = new Gizmox.WebGUI.Forms.TextBox();
            this.cboSmartTag3 = new Gizmox.WebGUI.Forms.ComboBox();
            this.cboSmartTag2 = new Gizmox.WebGUI.Forms.ComboBox();
            this.cboGroup = new Gizmox.WebGUI.Forms.ComboBox();
            this.cboSmartTag4 = new Gizmox.WebGUI.Forms.ComboBox();
            this.cboJobTitle = new Gizmox.WebGUI.Forms.ComboBox();
            this.txtSmartTag12 = new Gizmox.WebGUI.Forms.TextBox();
            this.lblSmartTag12 = new Gizmox.WebGUI.Forms.Label();
            this.dtpSmartTag8 = new Gizmox.WebGUI.Forms.DateTimePicker();
            this.dtpSmartTag9 = new Gizmox.WebGUI.Forms.DateTimePicker();
            this.cboWorkplace = new Gizmox.WebGUI.Forms.ComboBox();
            this.lblWorkplace = new Gizmox.WebGUI.Forms.Label();
            this.SuspendLayout();
            // 
            // lblSalutation
            // 
            this.lblSalutation.Location = new System.Drawing.Point(16, 18);
            this.lblSalutation.Name = "lblSalutation";
            this.lblSalutation.Size = new System.Drawing.Size(100, 23);
            this.lblSalutation.TabIndex = 0;
            this.lblSalutation.TabStop = false;
            this.lblSalutation.Text = "Salutation:";
            // 
            // cboSalutation
            // 
            this.cboSalutation.DropDownWidth = 121;
            this.cboSalutation.Location = new System.Drawing.Point(122, 15);
            this.cboSalutation.Name = "cboSalutation";
            this.cboSalutation.Size = new System.Drawing.Size(121, 21);
            this.cboSalutation.TabIndex = 1;
            // 
            // lblSmartTag10
            // 
            this.lblSmartTag10.Location = new System.Drawing.Point(258, 18);
            this.lblSmartTag10.Name = "lblSmartTag10";
            this.lblSmartTag10.Size = new System.Drawing.Size(80, 23);
            this.lblSmartTag10.TabIndex = 2;
            this.lblSmartTag10.TabStop = false;
            this.lblSmartTag10.Text = "SmartTag 10:";
            this.lblSmartTag10.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // txtSmartTag10
            // 
            this.txtSmartTag10.Location = new System.Drawing.Point(344, 15);
            this.txtSmartTag10.Name = "txtSmartTag10";
            this.txtSmartTag10.Size = new System.Drawing.Size(100, 20);
            this.txtSmartTag10.TabIndex = 3;
            // 
            // btnFindHKID
            // 
            iconResourceHandle1.File = "16x16.16_find.gif";
            this.btnFindHKID.Image = iconResourceHandle1;
            this.btnFindHKID.Location = new System.Drawing.Point(450, 13);
            this.btnFindHKID.Name = "btnFindHKID";
            this.btnFindHKID.Size = new System.Drawing.Size(29, 23);
            this.btnFindHKID.TabIndex = 4;
            this.btnFindHKID.TextImageRelation = Gizmox.WebGUI.Forms.TextImageRelation.ImageAboveText;
            this.btnFindHKID.Visible = false;
            // 
            // lblNickName
            // 
            this.lblNickName.Location = new System.Drawing.Point(16, 41);
            this.lblNickName.Name = "lblNickName";
            this.lblNickName.Size = new System.Drawing.Size(100, 23);
            this.lblNickName.TabIndex = 5;
            this.lblNickName.TabStop = false;
            this.lblNickName.Text = "Nick Name:";
            // 
            // txtNickName
            // 
            this.txtNickName.Location = new System.Drawing.Point(122, 38);
            this.txtNickName.Name = "txtNickName";
            this.txtNickName.Size = new System.Drawing.Size(322, 20);
            this.txtNickName.TabIndex = 6;
            // 
            // lblFirstName
            // 
            this.lblFirstName.Location = new System.Drawing.Point(16, 64);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(100, 23);
            this.lblFirstName.TabIndex = 8;
            this.lblFirstName.TabStop = false;
            this.lblFirstName.Text = "First Name:";
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(122, 61);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(322, 20);
            this.txtFirstName.TabIndex = 9;
            // 
            // lblLastName
            // 
            this.lblLastName.Location = new System.Drawing.Point(16, 87);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(100, 23);
            this.lblLastName.TabIndex = 11;
            this.lblLastName.TabStop = false;
            this.lblLastName.Text = "Last Name:";
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(122, 84);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(322, 20);
            this.txtLastName.TabIndex = 12;
            // 
            // lblChineseName
            // 
            this.lblChineseName.Location = new System.Drawing.Point(16, 110);
            this.lblChineseName.Name = "lblChineseName";
            this.lblChineseName.Size = new System.Drawing.Size(100, 23);
            this.lblChineseName.TabIndex = 14;
            this.lblChineseName.TabStop = false;
            this.lblChineseName.Text = "Chinese Name:";
            // 
            // txtChineseName
            // 
            this.txtChineseName.Location = new System.Drawing.Point(122, 107);
            this.txtChineseName.Name = "txtChineseName";
            this.txtChineseName.Size = new System.Drawing.Size(322, 20);
            this.txtChineseName.TabIndex = 15;
            // 
            // lblJobTitle
            // 
            this.lblJobTitle.Location = new System.Drawing.Point(16, 133);
            this.lblJobTitle.Name = "lblJobTitle";
            this.lblJobTitle.Size = new System.Drawing.Size(100, 23);
            this.lblJobTitle.TabIndex = 16;
            this.lblJobTitle.TabStop = false;
            this.lblJobTitle.Text = "Title:";
            // 
            // lblSmartTag13
            // 
            this.lblSmartTag13.Location = new System.Drawing.Point(16, 156);
            this.lblSmartTag13.Name = "lblSmartTag13";
            this.lblSmartTag13.Size = new System.Drawing.Size(100, 23);
            this.lblSmartTag13.TabIndex = 18;
            this.lblSmartTag13.TabStop = false;
            this.lblSmartTag13.Text = "SmartTag13:";
            // 
            // txtSmartTag13
            // 
            this.txtSmartTag13.Location = new System.Drawing.Point(122, 153);
            this.txtSmartTag13.Name = "txtSmartTag13";
            this.txtSmartTag13.Size = new System.Drawing.Size(322, 20);
            this.txtSmartTag13.TabIndex = 19;
            // 
            // lblSmartTag14
            // 
            this.lblSmartTag14.Location = new System.Drawing.Point(16, 179);
            this.lblSmartTag14.Name = "lblSmartTag14";
            this.lblSmartTag14.Size = new System.Drawing.Size(100, 23);
            this.lblSmartTag14.TabIndex = 20;
            this.lblSmartTag14.TabStop = false;
            this.lblSmartTag14.Text = "SmartTag 14:";
            // 
            // txtSmartTag14
            // 
            this.txtSmartTag14.Location = new System.Drawing.Point(122, 176);
            this.txtSmartTag14.Name = "txtSmartTag14";
            this.txtSmartTag14.Size = new System.Drawing.Size(322, 20);
            this.txtSmartTag14.TabIndex = 21;
            // 
            // lblSmartTag11
            // 
            this.lblSmartTag11.Location = new System.Drawing.Point(16, 202);
            this.lblSmartTag11.Name = "lblSmartTag11";
            this.lblSmartTag11.Size = new System.Drawing.Size(100, 23);
            this.lblSmartTag11.TabIndex = 22;
            this.lblSmartTag11.TabStop = false;
            this.lblSmartTag11.Text = "SmartTag 11:";
            // 
            // cboSmartTag11
            // 
            this.cboSmartTag11.DropDownWidth = 322;
            this.cboSmartTag11.Items.AddRange(new object[] {
            "Asian",
            "China",
            "Euro/US",
            "Japan",
            "Local",
            "Taiwan"});
            this.cboSmartTag11.Location = new System.Drawing.Point(122, 199);
            this.cboSmartTag11.Name = "cboSmartTag11";
            this.cboSmartTag11.Size = new System.Drawing.Size(322, 21);
            this.cboSmartTag11.TabIndex = 23;
            // 
            // lblRemarks
            // 
            this.lblRemarks.Location = new System.Drawing.Point(16, 248);
            this.lblRemarks.Name = "lblRemarks";
            this.lblRemarks.Size = new System.Drawing.Size(100, 23);
            this.lblRemarks.TabIndex = 26;
            this.lblRemarks.TabStop = false;
            this.lblRemarks.Text = "Remarks:";
            // 
            // txtRemarks
            // 
            this.txtRemarks.Location = new System.Drawing.Point(122, 245);
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.Size = new System.Drawing.Size(322, 20);
            this.txtRemarks.TabIndex = 27;
            // 
            // btnFindNickName
            // 
            iconResourceHandle2.File = "16x16.16_find.gif";
            this.btnFindNickName.Image = iconResourceHandle2;
            this.btnFindNickName.Location = new System.Drawing.Point(450, 36);
            this.btnFindNickName.Name = "btnFindNickName";
            this.btnFindNickName.Size = new System.Drawing.Size(29, 23);
            this.btnFindNickName.TabIndex = 7;
            this.btnFindNickName.TextImageRelation = Gizmox.WebGUI.Forms.TextImageRelation.ImageAboveText;
            this.btnFindNickName.Visible = false;
            // 
            // btnFindFirstName
            // 
            iconResourceHandle3.File = "16x16.16_find.gif";
            this.btnFindFirstName.Image = iconResourceHandle3;
            this.btnFindFirstName.Location = new System.Drawing.Point(450, 59);
            this.btnFindFirstName.Name = "btnFindFirstName";
            this.btnFindFirstName.Size = new System.Drawing.Size(29, 23);
            this.btnFindFirstName.TabIndex = 10;
            this.btnFindFirstName.TextImageRelation = Gizmox.WebGUI.Forms.TextImageRelation.ImageAboveText;
            this.btnFindFirstName.Visible = false;
            // 
            // btnFindLastName
            // 
            iconResourceHandle4.File = "16x16.16_find.gif";
            this.btnFindLastName.Image = iconResourceHandle4;
            this.btnFindLastName.Location = new System.Drawing.Point(450, 82);
            this.btnFindLastName.Name = "btnFindLastName";
            this.btnFindLastName.Size = new System.Drawing.Size(29, 23);
            this.btnFindLastName.TabIndex = 13;
            this.btnFindLastName.TextImageRelation = Gizmox.WebGUI.Forms.TextImageRelation.ImageAboveText;
            this.btnFindLastName.Visible = false;
            // 
            // lblGroup
            // 
            this.lblGroup.Location = new System.Drawing.Point(460, 270);
            this.lblGroup.Name = "lblGroup";
            this.lblGroup.Size = new System.Drawing.Size(100, 23);
            this.lblGroup.TabIndex = 57;
            this.lblGroup.TabStop = false;
            this.lblGroup.Text = "Group:";
            this.lblGroup.Visible = false;
            // 
            // lblSmartTag1
            // 
            this.lblSmartTag1.Location = new System.Drawing.Point(16, 294);
            this.lblSmartTag1.Name = "lblSmartTag1";
            this.lblSmartTag1.Size = new System.Drawing.Size(100, 23);
            this.lblSmartTag1.TabIndex = 30;
            this.lblSmartTag1.TabStop = false;
            this.lblSmartTag1.Text = "SmartTag 1:";
            // 
            // lblSmartTag2
            // 
            this.lblSmartTag2.Location = new System.Drawing.Point(16, 317);
            this.lblSmartTag2.Name = "lblSmartTag2";
            this.lblSmartTag2.Size = new System.Drawing.Size(100, 23);
            this.lblSmartTag2.TabIndex = 32;
            this.lblSmartTag2.TabStop = false;
            this.lblSmartTag2.Text = "SmartTag 2:";
            // 
            // lblSmartTag3
            // 
            this.lblSmartTag3.Location = new System.Drawing.Point(16, 340);
            this.lblSmartTag3.Name = "lblSmartTag3";
            this.lblSmartTag3.Size = new System.Drawing.Size(100, 23);
            this.lblSmartTag3.TabIndex = 34;
            this.lblSmartTag3.TabStop = false;
            this.lblSmartTag3.Text = "SmartTag 3:";
            // 
            // lblSmartTag4
            // 
            this.lblSmartTag4.Location = new System.Drawing.Point(16, 363);
            this.lblSmartTag4.Name = "lblSmartTag4";
            this.lblSmartTag4.Size = new System.Drawing.Size(100, 23);
            this.lblSmartTag4.TabIndex = 36;
            this.lblSmartTag4.TabStop = false;
            this.lblSmartTag4.Text = "SmartTag 4:";
            // 
            // txtSmartTag1
            // 
            this.txtSmartTag1.Location = new System.Drawing.Point(122, 291);
            this.txtSmartTag1.Name = "txtSmartTag1";
            this.txtSmartTag1.Size = new System.Drawing.Size(100, 20);
            this.txtSmartTag1.TabIndex = 31;
            // 
            // lblSmartTag5
            // 
            this.lblSmartTag5.Location = new System.Drawing.Point(228, 271);
            this.lblSmartTag5.Name = "lblSmartTag5";
            this.lblSmartTag5.Size = new System.Drawing.Size(100, 23);
            this.lblSmartTag5.TabIndex = 38;
            this.lblSmartTag5.TabStop = false;
            this.lblSmartTag5.Text = "SmartTag 5:";
            this.lblSmartTag5.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblSmartTag6
            // 
            this.lblSmartTag6.Location = new System.Drawing.Point(228, 294);
            this.lblSmartTag6.Name = "lblSmartTag6";
            this.lblSmartTag6.Size = new System.Drawing.Size(100, 23);
            this.lblSmartTag6.TabIndex = 40;
            this.lblSmartTag6.TabStop = false;
            this.lblSmartTag6.Text = "SmartTag 6:";
            this.lblSmartTag6.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblSmartTag7
            // 
            this.lblSmartTag7.Location = new System.Drawing.Point(228, 317);
            this.lblSmartTag7.Name = "lblSmartTag7";
            this.lblSmartTag7.Size = new System.Drawing.Size(100, 23);
            this.lblSmartTag7.TabIndex = 42;
            this.lblSmartTag7.TabStop = false;
            this.lblSmartTag7.Text = "SmartTag 7:";
            this.lblSmartTag7.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblSmartTag8
            // 
            this.lblSmartTag8.Location = new System.Drawing.Point(228, 340);
            this.lblSmartTag8.Name = "lblSmartTag8";
            this.lblSmartTag8.Size = new System.Drawing.Size(100, 23);
            this.lblSmartTag8.TabIndex = 44;
            this.lblSmartTag8.TabStop = false;
            this.lblSmartTag8.Text = "SmartTag 8:";
            this.lblSmartTag8.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblSmartTag9
            // 
            this.lblSmartTag9.Location = new System.Drawing.Point(228, 363);
            this.lblSmartTag9.Name = "lblSmartTag9";
            this.lblSmartTag9.Size = new System.Drawing.Size(100, 23);
            this.lblSmartTag9.TabIndex = 46;
            this.lblSmartTag9.TabStop = false;
            this.lblSmartTag9.Text = "SmartTag 9:";
            this.lblSmartTag9.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // txtSmartTag5
            // 
            this.txtSmartTag5.Location = new System.Drawing.Point(344, 268);
            this.txtSmartTag5.Name = "txtSmartTag5";
            this.txtSmartTag5.Size = new System.Drawing.Size(100, 20);
            this.txtSmartTag5.TabIndex = 39;
            // 
            // txtSmartTag6
            // 
            this.txtSmartTag6.Location = new System.Drawing.Point(344, 291);
            this.txtSmartTag6.Name = "txtSmartTag6";
            this.txtSmartTag6.Size = new System.Drawing.Size(100, 20);
            this.txtSmartTag6.TabIndex = 41;
            // 
            // txtSmartTag7
            // 
            this.txtSmartTag7.Location = new System.Drawing.Point(344, 314);
            this.txtSmartTag7.Name = "txtSmartTag7";
            this.txtSmartTag7.Size = new System.Drawing.Size(100, 20);
            this.txtSmartTag7.TabIndex = 43;
            // 
            // lblPhoneBook
            // 
            this.lblPhoneBook.Location = new System.Drawing.Point(502, 18);
            this.lblPhoneBook.Name = "lblPhoneBook";
            this.lblPhoneBook.Size = new System.Drawing.Size(100, 23);
            this.lblPhoneBook.TabIndex = 48;
            this.lblPhoneBook.TabStop = false;
            this.lblPhoneBook.Text = "Phone Book:";
            // 
            // cboPhoneBook
            // 
            this.cboPhoneBook.DropDownWidth = 130;
            this.cboPhoneBook.Location = new System.Drawing.Point(505, 38);
            this.cboPhoneBook.Name = "cboPhoneBook";
            this.cboPhoneBook.Size = new System.Drawing.Size(130, 21);
            this.cboPhoneBook.TabIndex = 49;
            this.cboPhoneBook.LostFocus += new System.EventHandler(this.cboPhoneBook_LostFocus);
            // 
            // lblLastUpdated
            // 
            this.lblLastUpdated.Location = new System.Drawing.Point(502, 64);
            this.lblLastUpdated.Name = "lblLastUpdated";
            this.lblLastUpdated.Size = new System.Drawing.Size(100, 23);
            this.lblLastUpdated.TabIndex = 50;
            this.lblLastUpdated.TabStop = false;
            this.lblLastUpdated.Text = "Last Updated";
            // 
            // txtLastUpdatedOn
            // 
            this.txtLastUpdatedOn.BackColor = System.Drawing.Color.LightYellow;
            this.txtLastUpdatedOn.Location = new System.Drawing.Point(505, 84);
            this.txtLastUpdatedOn.Name = "txtLastUpdatedOn";
            this.txtLastUpdatedOn.ReadOnly = true;
            this.txtLastUpdatedOn.Size = new System.Drawing.Size(70, 20);
            this.txtLastUpdatedOn.TabIndex = 51;
            this.txtLastUpdatedOn.TabStop = false;
            // 
            // txtLastUpdatedBy
            // 
            this.txtLastUpdatedBy.BackColor = System.Drawing.Color.LightYellow;
            this.txtLastUpdatedBy.Location = new System.Drawing.Point(581, 84);
            this.txtLastUpdatedBy.Name = "txtLastUpdatedBy";
            this.txtLastUpdatedBy.ReadOnly = true;
            this.txtLastUpdatedBy.Size = new System.Drawing.Size(54, 20);
            this.txtLastUpdatedBy.TabIndex = 52;
            this.txtLastUpdatedBy.TabStop = false;
            // 
            // lblCreatedOn
            // 
            this.lblCreatedOn.Location = new System.Drawing.Point(502, 110);
            this.lblCreatedOn.Name = "lblCreatedOn";
            this.lblCreatedOn.Size = new System.Drawing.Size(100, 23);
            this.lblCreatedOn.TabIndex = 53;
            this.lblCreatedOn.TabStop = false;
            this.lblCreatedOn.Text = "Creation Date";
            // 
            // txtCreatedOn
            // 
            this.txtCreatedOn.BackColor = System.Drawing.Color.LightYellow;
            this.txtCreatedOn.Location = new System.Drawing.Point(505, 130);
            this.txtCreatedOn.Name = "txtCreatedOn";
            this.txtCreatedOn.ReadOnly = true;
            this.txtCreatedOn.Size = new System.Drawing.Size(70, 20);
            this.txtCreatedOn.TabIndex = 54;
            this.txtCreatedOn.TabStop = false;
            // 
            // lblStatus
            // 
            this.lblStatus.Location = new System.Drawing.Point(502, 156);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(100, 23);
            this.lblStatus.TabIndex = 55;
            this.lblStatus.TabStop = false;
            this.lblStatus.Text = "Status";
            // 
            // txtStatus
            // 
            this.txtStatus.BackColor = System.Drawing.Color.LightYellow;
            this.txtStatus.Location = new System.Drawing.Point(505, 176);
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.ReadOnly = true;
            this.txtStatus.Size = new System.Drawing.Size(70, 20);
            this.txtStatus.TabIndex = 56;
            this.txtStatus.TabStop = false;
            // 
            // cboSmartTag3
            // 
            this.cboSmartTag3.DropDownWidth = 100;
            this.cboSmartTag3.Items.AddRange(new object[] {
            "A - Asian",
            "E - European",
            "J - Japanese",
            "L - Local People",
            "O - Others",
            "U - American",
            "T - Taiwanese",
            "1 - Mainland Chinese Eastern",
            "2 - Mainland Chinese Southern",
            "3 - Mainland Chinese Western",
            "4 - Mainland Chinese Northern",
            "5 - Mainland Chinese Central",
            "6 - Mainland Chinese Others"});
            this.cboSmartTag3.Location = new System.Drawing.Point(122, 337);
            this.cboSmartTag3.Name = "cboSmartTag3";
            this.cboSmartTag3.Size = new System.Drawing.Size(100, 21);
            this.cboSmartTag3.TabIndex = 35;
            // 
            // cboSmartTag2
            // 
            this.cboSmartTag2.DropDownWidth = 100;
            this.cboSmartTag2.Items.AddRange(new object[] {
            "Female",
            "Male"});
            this.cboSmartTag2.Location = new System.Drawing.Point(122, 314);
            this.cboSmartTag2.Name = "cboSmartTag2";
            this.cboSmartTag2.Size = new System.Drawing.Size(100, 21);
            this.cboSmartTag2.TabIndex = 33;
            // 
            // cboGroup
            // 
            this.cboGroup.DropDownWidth = 100;
            this.cboGroup.Location = new System.Drawing.Point(566, 267);
            this.cboGroup.Name = "cboGroup";
            this.cboGroup.Size = new System.Drawing.Size(100, 21);
            this.cboGroup.TabIndex = 58;
            this.cboGroup.Visible = false;
            // 
            // cboSmartTag4
            // 
            this.cboSmartTag4.DropDownWidth = 100;
            this.cboSmartTag4.Items.AddRange(new object[] {
            "00-19",
            "20-29",
            "30-39",
            "40-49",
            "50-59",
            "60-99"});
            this.cboSmartTag4.Location = new System.Drawing.Point(122, 360);
            this.cboSmartTag4.Name = "cboSmartTag4";
            this.cboSmartTag4.Size = new System.Drawing.Size(100, 21);
            this.cboSmartTag4.TabIndex = 37;
            // 
            // cboJobTitle
            // 
            this.cboJobTitle.DropDownWidth = 322;
            this.cboJobTitle.Location = new System.Drawing.Point(122, 130);
            this.cboJobTitle.Name = "cboJobTitle";
            this.cboJobTitle.Size = new System.Drawing.Size(322, 21);
            this.cboJobTitle.TabIndex = 17;
            // 
            // txtSmartTag12
            // 
            this.txtSmartTag12.Location = new System.Drawing.Point(122, 222);
            this.txtSmartTag12.Name = "txtSmartTag12";
            this.txtSmartTag12.Size = new System.Drawing.Size(322, 20);
            this.txtSmartTag12.TabIndex = 25;
            // 
            // lblSmartTag12
            // 
            this.lblSmartTag12.Location = new System.Drawing.Point(16, 225);
            this.lblSmartTag12.Name = "lblSmartTag12";
            this.lblSmartTag12.Size = new System.Drawing.Size(100, 23);
            this.lblSmartTag12.TabIndex = 24;
            this.lblSmartTag12.TabStop = false;
            this.lblSmartTag12.Text = "SmartTag 12:";
            // 
            // dtpSmartTag8
            // 
            this.dtpSmartTag8.CalendarFirstDayOfWeek = Gizmox.WebGUI.Forms.Day.Default;
            this.dtpSmartTag8.CustomFormat = "dd/MM/yyyy";
            this.dtpSmartTag8.Format = Gizmox.WebGUI.Forms.DateTimePickerFormat.Custom;
            this.dtpSmartTag8.Location = new System.Drawing.Point(344, 337);
            this.dtpSmartTag8.MinDate = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.dtpSmartTag8.Name = "dtpSmartTag8";
            this.dtpSmartTag8.ShowCheckBox = true;
            this.dtpSmartTag8.Size = new System.Drawing.Size(100, 20);
            this.dtpSmartTag8.TabIndex = 45;
            // 
            // dtpSmartTag9
            // 
            this.dtpSmartTag9.CalendarFirstDayOfWeek = Gizmox.WebGUI.Forms.Day.Default;
            this.dtpSmartTag9.CustomFormat = "dd/MM/yyyy";
            this.dtpSmartTag9.Format = Gizmox.WebGUI.Forms.DateTimePickerFormat.Custom;
            this.dtpSmartTag9.Location = new System.Drawing.Point(344, 360);
            this.dtpSmartTag9.MinDate = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.dtpSmartTag9.Name = "dtpSmartTag9";
            this.dtpSmartTag9.Size = new System.Drawing.Size(100, 20);
            this.dtpSmartTag9.TabIndex = 47;
            // 
            // cboWorkplace
            // 
            this.cboWorkplace.DropDownWidth = 100;
            this.cboWorkplace.Location = new System.Drawing.Point(122, 267);
            this.cboWorkplace.Name = "cboWorkplace";
            this.cboWorkplace.Size = new System.Drawing.Size(100, 21);
            this.cboWorkplace.TabIndex = 29;
            // 
            // lblWorkplace
            // 
            this.lblWorkplace.Location = new System.Drawing.Point(16, 270);
            this.lblWorkplace.Name = "lblWorkplace";
            this.lblWorkplace.Size = new System.Drawing.Size(100, 23);
            this.lblWorkplace.TabIndex = 28;
            this.lblWorkplace.TabStop = false;
            this.lblWorkplace.Text = "Shop:";
            // 
            // MemberWizard_MainInfo
            // 
            this.Controls.Add(this.lblWorkplace);
            this.Controls.Add(this.cboWorkplace);
            this.Controls.Add(this.dtpSmartTag9);
            this.Controls.Add(this.dtpSmartTag8);
            this.Controls.Add(this.lblSmartTag12);
            this.Controls.Add(this.txtSmartTag12);
            this.Controls.Add(this.cboJobTitle);
            this.Controls.Add(this.cboSmartTag4);
            this.Controls.Add(this.cboGroup);
            this.Controls.Add(this.cboSmartTag2);
            this.Controls.Add(this.cboSmartTag3);
            this.Controls.Add(this.txtStatus);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.txtCreatedOn);
            this.Controls.Add(this.lblCreatedOn);
            this.Controls.Add(this.txtLastUpdatedBy);
            this.Controls.Add(this.txtLastUpdatedOn);
            this.Controls.Add(this.lblLastUpdated);
            this.Controls.Add(this.cboPhoneBook);
            this.Controls.Add(this.lblPhoneBook);
            this.Controls.Add(this.txtSmartTag7);
            this.Controls.Add(this.txtSmartTag6);
            this.Controls.Add(this.txtSmartTag5);
            this.Controls.Add(this.lblSmartTag9);
            this.Controls.Add(this.lblSmartTag8);
            this.Controls.Add(this.lblSmartTag7);
            this.Controls.Add(this.lblSmartTag6);
            this.Controls.Add(this.lblSmartTag5);
            this.Controls.Add(this.txtSmartTag1);
            this.Controls.Add(this.lblSmartTag4);
            this.Controls.Add(this.lblSmartTag3);
            this.Controls.Add(this.lblSmartTag2);
            this.Controls.Add(this.lblSmartTag1);
            this.Controls.Add(this.lblGroup);
            this.Controls.Add(this.btnFindLastName);
            this.Controls.Add(this.btnFindFirstName);
            this.Controls.Add(this.btnFindNickName);
            this.Controls.Add(this.txtRemarks);
            this.Controls.Add(this.lblRemarks);
            this.Controls.Add(this.cboSmartTag11);
            this.Controls.Add(this.lblSmartTag11);
            this.Controls.Add(this.txtSmartTag14);
            this.Controls.Add(this.lblSmartTag14);
            this.Controls.Add(this.txtSmartTag13);
            this.Controls.Add(this.lblSmartTag13);
            this.Controls.Add(this.lblJobTitle);
            this.Controls.Add(this.txtChineseName);
            this.Controls.Add(this.lblChineseName);
            this.Controls.Add(this.txtLastName);
            this.Controls.Add(this.lblLastName);
            this.Controls.Add(this.txtFirstName);
            this.Controls.Add(this.lblFirstName);
            this.Controls.Add(this.txtNickName);
            this.Controls.Add(this.lblNickName);
            this.Controls.Add(this.btnFindHKID);
            this.Controls.Add(this.txtSmartTag10);
            this.Controls.Add(this.lblSmartTag10);
            this.Controls.Add(this.cboSalutation);
            this.Controls.Add(this.lblSalutation);
            this.Size = new System.Drawing.Size(766, 384);
            this.Text = "MemberWizard_MainInfo";
            this.ResumeLayout(false);

        }

        #endregion

        private Gizmox.WebGUI.Forms.Label lblSalutation;
        private Gizmox.WebGUI.Forms.Label lblSmartTag10;
        private Gizmox.WebGUI.Forms.Button btnFindHKID;
        private Gizmox.WebGUI.Forms.Label lblNickName;
        private Gizmox.WebGUI.Forms.Label lblFirstName;
        private Gizmox.WebGUI.Forms.Label lblLastName;
        private Gizmox.WebGUI.Forms.Label lblChineseName;
        private Gizmox.WebGUI.Forms.Label lblJobTitle;
        private Gizmox.WebGUI.Forms.Label lblSmartTag13;
        private Gizmox.WebGUI.Forms.Label lblSmartTag14;
        private Gizmox.WebGUI.Forms.Label lblSmartTag11;
        private Gizmox.WebGUI.Forms.Label lblRemarks;
        private Gizmox.WebGUI.Forms.Button btnFindNickName;
        private Gizmox.WebGUI.Forms.Button btnFindFirstName;
        private Gizmox.WebGUI.Forms.Button btnFindLastName;
        private Gizmox.WebGUI.Forms.Label lblGroup;
        private Gizmox.WebGUI.Forms.Label lblSmartTag1;
        private Gizmox.WebGUI.Forms.Label lblSmartTag2;
        private Gizmox.WebGUI.Forms.Label lblSmartTag3;
        private Gizmox.WebGUI.Forms.Label lblSmartTag4;
        private Gizmox.WebGUI.Forms.Label lblSmartTag5;
        private Gizmox.WebGUI.Forms.Label lblSmartTag6;
        private Gizmox.WebGUI.Forms.Label lblSmartTag7;
        private Gizmox.WebGUI.Forms.Label lblSmartTag8;
        private Gizmox.WebGUI.Forms.Label lblSmartTag9;
        private Gizmox.WebGUI.Forms.Label lblPhoneBook;
        private Gizmox.WebGUI.Forms.Label lblLastUpdated;
        private Gizmox.WebGUI.Forms.Label lblCreatedOn;
        private Gizmox.WebGUI.Forms.Label lblStatus;
        public Gizmox.WebGUI.Forms.ComboBox cboSalutation;
        public Gizmox.WebGUI.Forms.TextBox txtSmartTag10;
        public Gizmox.WebGUI.Forms.TextBox txtNickName;
        public Gizmox.WebGUI.Forms.TextBox txtFirstName;
        public Gizmox.WebGUI.Forms.TextBox txtLastName;
        public Gizmox.WebGUI.Forms.TextBox txtChineseName;
        public Gizmox.WebGUI.Forms.TextBox txtSmartTag13;
        public Gizmox.WebGUI.Forms.TextBox txtSmartTag14;
        public Gizmox.WebGUI.Forms.ComboBox cboSmartTag11;
        public Gizmox.WebGUI.Forms.TextBox txtRemarks;
        public Gizmox.WebGUI.Forms.TextBox txtSmartTag1;
        public Gizmox.WebGUI.Forms.TextBox txtSmartTag5;
        public Gizmox.WebGUI.Forms.TextBox txtSmartTag6;
        public Gizmox.WebGUI.Forms.TextBox txtSmartTag7;
        public Gizmox.WebGUI.Forms.ComboBox cboPhoneBook;
        public Gizmox.WebGUI.Forms.TextBox txtLastUpdatedOn;
        public Gizmox.WebGUI.Forms.TextBox txtLastUpdatedBy;
        public Gizmox.WebGUI.Forms.TextBox txtCreatedOn;
        public Gizmox.WebGUI.Forms.TextBox txtStatus;
        public Gizmox.WebGUI.Forms.ComboBox cboSmartTag3;
        public Gizmox.WebGUI.Forms.ComboBox cboSmartTag2;
        public Gizmox.WebGUI.Forms.ComboBox cboGroup;
        public Gizmox.WebGUI.Forms.ComboBox cboSmartTag4;
        public Gizmox.WebGUI.Forms.ComboBox cboJobTitle;
        public Gizmox.WebGUI.Forms.TextBox txtSmartTag12;
        private Gizmox.WebGUI.Forms.Label lblSmartTag12;
        public Gizmox.WebGUI.Forms.DateTimePicker dtpSmartTag8;
        public Gizmox.WebGUI.Forms.DateTimePicker dtpSmartTag9;
        public Gizmox.WebGUI.Forms.ComboBox cboWorkplace;
        private Gizmox.WebGUI.Forms.Label lblWorkplace;


    }
}